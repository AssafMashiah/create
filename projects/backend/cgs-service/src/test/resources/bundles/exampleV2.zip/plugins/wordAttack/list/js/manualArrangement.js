define(['text!plugins/wordAttack/list/templates/imageEditor.html',
		'text!plugins/wordAttack/list/templates/helper.html',
		'plugins/wordAttack/main/js/wordSoundUtil'],
	function (imageEditorTemplate, helperTemplate, wordSoundUtil) {
		var manualArrangement = function(  ){

			var self = this;

			/**
			* function init
			* Initialize the manualArrangement object
			* @param CGS the CGS api
			*/
			this.init = function(api){
				self.CGS = api;
				appendOverlay();
				self.padding = 21;
				self.stageDroppable = ".image-wrapper";
				self.includeNumbers = self.CGS.model.record.data.item_numbering;
				self.soundInWords   = false;
				self.displayType   = "word";
			}

			this.setSoundInWords = function(soundInWords) {
				self.soundInWords = soundInWords;
			}

			this.setDisplayType = function(type) {
				self.displayType = type;
			}

			/**
			* function render
			* render the  manualArrangement template
			*/
			this.render = function(){
				var templateData = {"items":getListItems(),
									"includeNumbers":self.includeNumbers};
				addBackgroundImageToTemplateData(templateData);
				var template = self.CGS.RenderTemplate.render(imageEditorTemplate, templateData);
				self.$overlay.html(template);
			}

			/**
			* function showManualMenu
			*  Case the orientation is manual show the manualMenu section on page
			*/
			this.showManualMenu = function(){
				if(self.CGS.model.record.data.orientation == 'manual'){
					self.$el.show();
					self.showValidOnButton();
					self.showValidTipOnList();
				}
				else{
					self.$el.hide();
					self.showValidTipOnList(true);
				}
			};

			this.initElement = function(){
				self.$el = $('#manualMenu');
				self.$el.find('.btn-editor-editManual').on("click", openImageEditor);
				self.showValidOnButton();
			};


			var bindEvents = function(){
				self.$overlay.find('.edit-btn').on("click",hideOverlay);
			};

			var openImageEditor = function(){
				self.$overlay.removeClass("hidden");
				self.$overlay.removeClass("display-type-word").removeClass("display-type-letter");
				self.$overlay.addClass("display-type-" + self.displayType);
				self.render();
				handleDrag();
				setEnableOkButton();
				bindEvents();
			};

			var addBackgroundImageToTemplateData = function(templateData){
				var assets = self.CGS.model.getItem({id:self.CGS.model.record.id}).data.assets;
				if(assets && assets.backgroundImage){
					templateData.backgroundImage = self.CGS.externalApi.getAssetAbsolutePath(assets.backgroundImage);
				}
			};

			var handleDrag = function(){
				//self.render();
				_.each(getListItems(), function(item){
					item.position ? setDragOnImage(item) : setDragOnWordsList(item.id);
				});

				$(self.stageDroppable).droppable();
			};

			/**
			* function setDragOnImage
			* Case the item is already on the image
			* @param item (listItem)
			*/
			var setDragOnImage = function(item){
				$("#"+item.id).draggable({
					containment: self.stageDroppable
				});
			};

			/**
			* function setDragOnWordsList
			* Case the item is not placed
			* @param id the listItem is
			*/
			var setDragOnWordsList = function(id){
				var wordsList = $(".words-list");
				var wordsListPosition =  wordsList.position();
				var wordsListWidth = wordsList.width();
				//var $wordsList = self.$overlay.find(".words");
				$("[data-id='"+id+"'").draggable({
					helper: function(event, ui){
						var $target = $(event.target);
						var palce =  $target.index() +1;
						var helperData = {"id":$target.attr("data-id"),
										  "index": $target.index(),
										  "value": $target.find(".text").html(),
										  "place": palce,
										  "includeNumbers":self.includeNumbers
										}
						var html = self.CGS.RenderTemplate.render(helperTemplate, helperData);
						return html;

					},
					revert: 'invalid',
					revertDuration: 350,
					containment:".image-editor-container",
					stop:function(event, ui){
						var helperLeft =  ui.helper.position().left;
						var helperTop =  ui.helper.position().top;
						var helperWidth = $(ui.helper).width()
						if(helperLeft > wordsListWidth + self.padding){
							$(this).draggable("disable");
							$(ui.helper).css('left', helperLeft - (wordsListWidth + self.padding));
							$(ui.helper).css('top', helperTop - self.padding);
							var newDiv = $(ui.helper).clone(false);
							newDiv.removeClass("ui-draggable-dragging");
							$('.image-wrapper').append(newDiv);
							setEnableOkButton(true);
							$(newDiv).draggable({
								containment: self.stageDroppable
							});
						}
					},
					opacity: 0.8
				});
			};

			/**
			* function saveData
			* Save the data the positions of the items
			* this method uses the createPath method
			*/
			var saveData = function(){
				var maxPosition = {};
				maxPosition.left = 0;
				maxPosition.top = 0;
				_.each($(".draggable-word.on-image"), function(element){
					var idx = Number($(element).attr("data-idx"));
					var position = $(element).position();
					maxPosition.left = Math.max(maxPosition.left, position.left + $(element).width());
					maxPosition.top = Math.max(maxPosition.top, position.top + $(element).height());
					var path = createPath(idx, position);
					self.CGS.externalApi.activate(path);

				});
				var imageSize = {width: $('#imageBackground').width(), height:$('#imageBackground').height()};
				saveBackgroundSize(imageSize, maxPosition);

			};


			var createPath = function(idx, position){
				return   [
				{
					action :"child",
					args : {
						type : "example:wordAttack:listItem",
						index : idx
					}
				},
				{
					action : "setRecordProperty",
					args	:
					{
						name : "data.position",
						value : position
					}
				}];
			};

			var saveBackgroundSize = function(imageSize, maxPosition){
				var backgroundSize = {};
				backgroundSize.width = 800;
				backgroundSize.height = Math.max(imageSize.height, maxPosition.top);
				self.CGS.model.saveProp({"propName" : "imageSize" ,"value": imageSize });
				self.CGS.model.saveProp({"propName" : "backgroundSize" ,"value": backgroundSize });
			};

			/**
			* function getListItems
			* Creates the necessary  params for the template
			* @return items ( array ) list items objects
			*/
			var getListItems = function(){
                var items =[];
              _.each(self.CGS.model.record.children,function(child, index){
                    var item = {};
                    var listItem = self.CGS.model.getItem({id : child});
                    var elementItem = self.CGS.model.getItem({id : listItem.children[0]});
                    var html = elementItem.data.title;
                    var value = $(html).text();

                    if(self.soundInWords) {
                    	value = wordSoundUtil.concatAllSounds(value);
                    }

					if(elementItem.type == "imageViewer") {
					  html = "<img src='" + self.CGS.externalApi.getAssetAbsolutePath(elementItem.data.image) + "'>";
					  value = html;
					}

                    item["id"] = listItem.children[0];
                    item["index"] = index;
                    item["value"] = value;
                    item["position"] = listItem.data.position;
                    item["place"] = index + 1;
                    items.push(item);
                });
              return items;
            };

			var appendOverlay = function(){
				if($('body').find('.image-editor-overlay').length == 0){
					$('body').append("<div class='image-editor-overlay hidden'></div>");
				}
				self.$overlay = $('body').find('.image-editor-overlay');
			};

			var hideOverlay = function(e){
				if($(e.target).hasClass("ok")){
					saveData();
				}
				self.$overlay.addClass("hidden");
				self.showValidOnButton();
				self.showValidTipOnList();
			};

			var setEnableOkButton = function(inEdit){
				var allSet =  self.isAllListSet(inEdit)
				$('.image-editor-overlay').find(".edit-btn.ok").attr("disabled", !allSet);
			};

			/**
			* function isAllListSet
			* Checking if all list items are placed
			* @return ( bool )
			*/
			this.isAllListSet = function(inEdit){
				if(inEdit){
					var itemsOnImage = $(".image-wrapper").find(".on-image").length + 1;
					var itemsOnWordsList = $(".words-list").find(".draggable-word").length;
					return (itemsOnImage == itemsOnWordsList);
				}
				else{
					var itemOnWordsList = _.find(self.CGS.model.getItem({id:self.CGS.model.record.id}).children, function(id){
						return !self.CGS.model.getItem({id:id}).data.position;
					});
					return itemOnWordsList ? false: true;
				}
			};

			this.showValidOnButton = function(){
				if(self.isAllListSet()){
					$('#validManualSign').hide();
				}
				else{
					$('#validManualSign').css("display","-webkit-box");
				}
			}

			this.showValidTipOnList = function(hide){
				if(self.isAllListSet() || hide){
					$("[data-elementid='"+self.CGS.model.record.id+"'").find(".list-indication").hide();
				}
				else{
					$("[data-elementid='"+self.CGS.model.record.id+"'").find(".list-indication").show();
				}
			};

			this.showNumbers = function(show) {
				self.includeNumbers = show;
			};
	};

	return manualArrangement;
});