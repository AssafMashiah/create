define([],function(){
var GrowingList  = {

		api : undefined,

		list : {},

		nameCounter : 1,

        correctionText:{
			"default":'Model the correct response.Lead the response with students (if needed).Test the student response.Repeat the task again.',
            "CxWordSpellB":'<div class="cgs normal" style="min-width: 28px; min-height: 28px; margin: 0px 10px 0px 0px; padding: 0px; outline: none; white-space: pre-wrap; clear: both; -webkit-user-select: none;" contenteditable="false" customstyle="normal"><ul type="insertOrderedList" class="orderedList" id="1418547929491_169"><li contenteditable="false" class="listItem">That word is ______. Everybody, what word? (Signal.) _____.</li><li contenteditable="false" class="listItem"><span style="white-space: pre-wrap;">Spell _____. Get ready. (Signal for each letter.) … .</span></li><li contenteditable="false" class="listItem"><span style="white-space: pre-wrap;">What word did you spell? (Signal.) _____.</span></li><li contenteditable="false" class="listItem"><span style="white-space: pre-wrap;">Back to word 1.</span><br></li></ul></div>',
            "CxSound":'<div class="cgs normal" style="min-width: 28px; min-height: 28px; margin: 0px 10px 0px 0px; padding: 0px; outline: none; white-space: pre-wrap; clear: both; -webkit-user-select: none;" contenteditable="false" customstyle="normal"><ul type="insertOrderedList" class="orderedList" id="1418562541940_1540"><li contenteditable="false" class="listItem">That sound is  _____. Everybody, what sound? (Signal.)  _____.</li><li contenteditable="false" class="listItem"><span style="white-space: pre-wrap;">(Repeat step.)</span><br></li></ul></div>',
            "CxSRSoundOut":'<div class="cgs normal" style="min-width: 28px; min-height: 28px; margin: 0px 10px 0px 0px; padding: 0px; outline: none; white-space: pre-wrap; clear: both; -webkit-user-select: none;" contenteditable="false" customstyle="normal"><ul type="insertOrderedList" class="orderedList" id="1418562568268_1966"><li contenteditable="false" class="listItem">That word is ______. Everybody, what word? (Signal.) _______.</li><li contenteditable="false" class="listItem"><span style="white-space: pre-wrap;">Touch and say the sounds. (Signal for each sound.) … . What word? (Signal.) _______.</span></li><li contenteditable="false" class="listItem"><span style="white-space: pre-wrap;">Return to the beginning of most recent sentence.)</span><br></li></ul></div>',
            "CxLetter":'<div class="cgs normal" style="min-width: 28px; min-height: 28px; margin: 0px 10px 0px 0px; padding: 0px; outline: none; white-space: pre-wrap; clear: both; -webkit-user-select: none;" contenteditable="false" customstyle="normal"><ul type="insertOrderedList" class="orderedList" id="1418562621571_229"><li contenteditable="false" class="listItem">That letter is  _____. Everybody, what letter? (Signal.)  _____.</li><li contenteditable="false" class="listItem"><span style="white-space: pre-wrap;">(Repeat step.)</span><br></li></ul></div>',
			"Reading":'<div class="cgs normal" style="min-width: 28px; min-height: 28px; margin: 0px 10px 0px 0px; padding: 0px; outline: none; white-space: pre-wrap; clear: both; -webkit-user-select: none;" contenteditable="false" customstyle="normal">a. That word is _____.	</div><div class="cgs normal" style="min-width: 28px; min-height: 28px; margin: 0px 10px 0px 0px; padding: 0px; outline: none; white-space: pre-wrap; clear: both; -webkit-user-select: none;" contenteditable="false" customstyle="normal">b. What word?</div><div class="cgs normal" style="min-width: 28px; min-height: 28px; margin: 0px 10px 0px 0px; padding: 0px; outline: none; white-space: pre-wrap; clear: both; -webkit-user-select: none;" contenteditable="false" customstyle="normal">c. Please reread that sentence.</div>'
        },

		template : "<div class='growing-list'></div>",

		rowsTemplate : "<div class='growing-list-rows' >{{#items}}{{> row}}{{/items}}</div>",

		rowTemplate :  "<div class='growing-list-row'  data-item-index='{{index}}' data-item-id='{{id}}'><input type='text' class='growing-list-input' value='{{name}}' {{#isReadOnly}}disabled{{/isReadOnly}}></input>{{^isReadOnly}}<button class='growing-list-edit'><span class='base-icon icon-cog'></span></button>{{#index}}<button class='growing-list-delete '><span class='base-icon icon-trash'></span></button>{{/index}}{{/isReadOnly}}</div>",

		buttonTemplate : "{{^isReadOnly}}<div><button class='growing-list-add'><span class='base-icon icon-plus'></span></button></div>{{/isReadOnly}}",

		init : function(api,list,readOnly,notifyFunction,nameCounter) {
			if(!api){
				throw new Error('Missing api');
			}
			if(nameCounter){
				this.nameCounter = nameCounter;
			}
			this.isReadOnly = readOnly;
			this.api = api;
			this.notify = notifyFunction;

			this.setList(list);
			if(!this.list || !this.list.length){
				//get this data from somewhere
				var defaultCorrectionScripts = this.api.model.record.data.defaultCorrectionScripts;
				for (var i = 0; i < defaultCorrectionScripts.length; i++) {
					var correctionScriptId = defaultCorrectionScripts[i];
					var isDefault = i == 0;

					this.createItem(correctionScriptId, this.correctionText[correctionScriptId], isDefault);
					// notify of new list on first item added
					if( i == 0){
						this.notify('new',this.list);
					} else {
						this.notify('append',this.list);
					}

				}

			}
		},

		bindEvents : function () {
			$(".growing-list")
				.on('click','.growing-list-add',this.addItem.bind(this))
				.on('mouseover','.growing-list-row',this.toggleControlButtons.bind(this))
				.on('mouseout','.growing-list-row',this.toggleControlButtons.bind(this))
				.on('change','.growing-list-row input',this.editItem.bind(this))
				.on('click','.growing-list-delete',this.removeItemDialog.bind(this))
				.on('click','.growing-list-edit',this.addValue.bind(this));

		},

		unbindEvents : function (){
			$(".growing-list").off('click','.growing-list-add')
			.off('mouseover','.growing-list-row')
			.off('mouseout','.growing-list-row')
			.off('change','.growing-list-row input')
			.off('click','.growing-list-delete')
			.off('click','.growing-list-edit');

		},

		addItem : function (e,name,value) {
            this.notify('append',this.list);
			$.when(this.createItem("","",false)).then(function(e,result){

				this.addRowTemplate(e.target,result,this.list.length - 1);


			}.bind(this,e));
		},

		/**
		 * add cgs ability to  open modal pop up
		 * @param  {Function} callback [description]
		 * @return {[type]}            [description]
		 */
		addHiddenElement : function (value) {
			var dfd = new jQuery.Deferred();

			this.api.hidden.addHiddenChild({
				type: "plugin:example:core:simpleModalEditor",
				children :[
					 		{
								"type" : "sys:textViewer",
								"data" : {
									"mode":"custom",
									"settings" : {"groups" : ["styles","effects","font","paragraph"]},
									"deletable" : false,
									"width" : "418px",
									"title" : value,
                                    "showNarrationType" : false
								},
							"children" :[]
						}
				],
				data : {
					"menuTitle" : "Correction Script"
				}
			}, function (newItemId) {
				if(newItemId){
					dfd.resolve(newItemId);
				}else{
					dfd.reject('error');
				}
			}.bind(this));
			return dfd.promise();
		},

		addRowTemplate : function (element,row,index){
			//create the html template
				var $growingListRows = $(element).closest('.growing-list').find('.growing-list-rows'),
				 	template = this.api.RenderTemplate.render(this.rowTemplate,_.merge(
				 		{
				 			index : index
				 		},
				 		row
				 		));
				$(template).appendTo($growingListRows).focus();

		},

		addValue : function (e){
			//alert('to be implemented by cgs team');
			var rowElement = this.getRowElement(e),
				id = rowElement.data('item-id'),
				item = this.getRowItem(id);

			this.api.hidden.load(item.modalId);
		},

		createItem : function (name,value,isDefault){
			//for undo developer if isDefault is true then add flag ignore = true to the transaction
			var dfd = new jQuery.Deferred();

			$.when(this.addHiddenElement(value)).then(function(modalId){
				if(!name){
					name = 'New Script';
				}
				Array.prototype.push.call(this.list , {
					"id" : isDefault ? 'default_correction_script' : this.formatId(name),
					"name" : name,
					"isDefault" : isDefault,
					"modalId" : modalId
				});
				this.notify('create',this.list);
				dfd.resolve(this.list[this.list.length -1 ]);
				//return this.list[this.list.length -1 ];
			}.bind(this));
			return dfd.promise();
		},

		toggleControlButtons : function(e){
			var $row_element = this.getRowElement(e);
			if(e.type == 'mouseover'){
				$row_element.find('button').show();
			}else{
				$row_element.find('button').hide();
			}
		},

		editItem : function (e) {
			var rowElement = this.getRowElement(e),
				id = rowElement.data('item-id'),
				/*index = rowElement.data('item-index') - 1,*/
				name = e.target.value;

			if(name == ""){
				return;
			}
			if(this.getRowItem(id)){

				/*this.list[index] = _.merge({},this.list[index],{name : name});*/
                this.notify('append',this.list);
				this.getRowItem(id).name = name;
				this.notify('create',this.list);
			}

		},

		removeItemDialog : function (e) {
			this.api.dialogs.show({
				title : "Correction Script - Delete Item",
				content : "<span>Are you sure you want to delete this item?</span>",
				buttons : {
					"ok" : {
						label : "Delete"
					},
					"cancel" : {
						label : "Cancel"
					}

				}
			},function onResponseRecived(response){
				if(response !== "ok"){
					return;
				}
				this.removeItem(e);
			}.bind(this));

		},

		removeItem : function (e){
			var rowElement = this.getRowElement(e),
				index = rowElement.data('item-index');

				var parentElement = rowElement.parent();

				//need to notify all other objects
                this.api.externalApi.startTransaction();
                this.api.model.deleteItem({id:this.list[index].modalId});
				if(this.list[index]){
					Array.prototype.splice.call(this.list,index,1);
				}
				this.notify('delete',rowElement.data('item-id'));
                this.api.externalApi.endTransaction();
				rowElement.remove();


				this.rebuildIndexes(parentElement);
		},

		rebuildIndexes: function(parentElement) {
			var index = 0;
			$(".growing-list-row", parentElement).each(function() {
				$(this).data("item-index", index);
				index++;
			});
		},

		getRowItem : function (id){
			var result = false;
			if(id){
				result = _.first(_.compact(_.map(this.list,function(item){
						if(item.id == id){
							return item;
						}
						return false;
				})));
			}
			return result;
		},

		getData : function (){
			return _.merge({},this.list);
		},

		setList : function (list){
			if(list){
				this.list = _.merge({},list);
			}

		},

		render : function() {
			var $result = $(this.template),
				 items = _.map(this.getData(),function(item,index){ return _.merge({},item,{index:index})});
			$result.append(this.api.RenderTemplate.render(this.rowsTemplate,{items: items,isReadOnly : this.isReadOnly},{row: this.rowTemplate}));
			$result.append(this.api.RenderTemplate.render(this.buttonTemplate,{
				isReadOnly :this.isReadOnly
			}));
			return $result;
		},

		formatId : function (name) {
			var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    						var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
    						return v.toString(16);
						});
			return uuid;
		},

		getRowElement : function (e){
			if(e.target.classList.contains('growing-list-row')){
				$row_element =  $(e.target);
			}else{
				$row_element = $(e.target).closest('.growing-list-row');
			}
			return $row_element;
		}
	};

return GrowingList;

});
