define(['plugins/core/basePlugin/baseClass'],

	function (baseClass) {
		var BasePlugin = baseClass.extend({
			onInitialize : function(){
				console.log("onInitialize base");
			},
			onRenderComplete : function(){
				console.log("on render complete base");
			}

		});

		return BasePlugin;
	});