define([], 
    function () {
        var Utils = function() {
            this.mask = {
                setMask: function(elem) {

                    if (!elem) return;

                    this.clearMask();


                    this.elem = $(elem).eq(0);

                    this.leftDiv = $('<div class="di-mask-overlay">').appendTo($('body'));
                    this.topDiv = $('<div class="di-mask-overlay">').appendTo($('body'));
                    this.bottomDiv = $('<div class="di-mask-overlay">').appendTo($('body'));
                    this.rightDiv = $('<div class="di-mask-overlay">').appendTo($('body'));

                    this.updateMask();

                    this.elem.parents().bind('scroll', this.updateMask);

                    $(window).bind('resize', this.updateMask);
                },

                updateMask: function() {
                    var self = this;

                    if (!self.elem || !self.leftDiv) return;

                    self.leftDiv.css({
                        left: 0,
                        top: 0,
                        height: '100%',
                        width: self.elem.offset().left
                    });
                    self.topDiv.css({
                        left: self.elem.offset().left,
                        top: 0,
                        height: self.elem.offset().top,
                        width: self.elem.outerWidth()
                    });
                    self.bottomDiv.css({
                        left: self.elem.offset().left,
                        top: self.elem.offset().top + self.elem.outerHeight(),
                        height: $('body').height() - (self.elem.offset().top + self.elem.outerHeight()),
                        width: self.elem.outerWidth()
                    });
                    self.rightDiv.css({
                        left: self.elem.offset().left + self.elem.outerWidth(),
                        top: 0,
                        height: '100%',
                        width: $('body').width() - (self.elem.offset().left + self.elem.outerWidth())
                    });
                },

                clearMask: function() {
                    $('body .di-mask-overlay').remove();
                    $(window).unbind('resize', this.updateMask);
                    if (this.elem) {
                        this.elem.parents().unbind('scroll', this.updateMask);
                        this.elem = this.leftDiv = this.topDiv = this.bottomDiv = this.rightDiv = null;
                    }
                }
        };
			this.getMediaObject = function(cgs,assets,mediaType){

				var mediaSrc = (assets && assets[mediaType+"Content"]) ? assets[mediaType+"Content"] : null;
				var contentClass = "";
				var displayClass = "";
				var src = "";

				var mediaObject = {
					"hasMedia" : mediaSrc != null,
					"contentClass" : contentClass,
					"displayClass" : displayClass,
					"src" : src,
					"relativePath" : mediaSrc,
					"mediaType" : mediaType
				};

				if( !mediaType || mediaType == ""){
					return mediaObject;
				}

				if( mediaType == "image"){
					mediaObject.contentClass = "previewImage"
				} else {
					mediaObject.contentClass = (mediaType == "video") ? "video_icon" : "sound_icon";
				}
				if(!mediaSrc){
					switch(mediaType){
						case "image":
							mediaObject.displayClass = "noImage";
							break;
						case "video":
							mediaObject.contentClass = "video_icon";
							mediaObject.displayClass = "disabled";
							break;
						case "audio":
							mediaObject.contentClass = "sound_icon";
							mediaObject.displayClass = "disabled";
							break;
					}
				} else{
					mediaObject.src = cgs.externalApi.getAssetAbsolutePath(mediaSrc);
					if(mediaType !== "image"){
						var isPlaceholder = (mediaObject.src.indexOf("media/placeholder") != -1);
						mediaObject.displayClass = isPlaceholder ? "ordered" : "";
					}
				}



				return mediaObject;


			};
    };

    return new Utils();
});