define(['text!plugins/wordAttack/element/templates/properties.html',
            'text!plugins/wordAttack/element/templates/stage.html',
            'plugins/core/baseElement/index'],

        function (propertiesTemplate, stageTemplate, BaseElement) {
            var wordAttackElement = BaseElement.extend({
                type: "wordAttack",
                stageTemplate: stageTemplate,
                propertiesTemplate: propertiesTemplate,
                onPropertiesViewLoad: function ($props_el) {
                    //this.$props_el = $props_el;
                    this._super($props_el);
                    this.bindPropsEvents();
                },
                onStartEdit: function () {
                    this._super();


                    var teacherPath = [{
                     action: "child",
                        args: {
                            type: "example:wordAttack:element",
                            index: 0
                        }
                    },
                     {
                       action : "getRecordProperty",
                       args    : {
                          name : "data.activeScriptContainer"
                      }
                    }];
                    var activeScriptContainer =  this.CGS.externalApi.activate(teacherPath);
                    var path = [{
                        action: "child",
                        args: {
                            type: "example:wordAttack:teacher",
                            index: 0
                        }
                    },
                    {
                        action: "child",
                        args: {
                            type: "example:wordAttack:scriptContainer",
                            index: activeScriptContainer
                        }
                    }];
                    this.CGS.externalApi.activate(path, "scriptContainer.sectionConstraints");
                },
                bindPropsEvents: function () {
                    if(!this.$props_el){
                        return;
                    }
                    this.$props_el.find('.props_editor').on('change.prop', 'input[type=checkbox],select', function (e) {
                        this.propertyItemChange(e);
                    }.bind(this));
                },
                propertyItemChange: function (e) {
                    var name = e.target.dataset['recordValue'];
                    var value = e.target.type == 'checkbox' ? e.target.checked : e.target.value;
                    if(name == "isIndividualAutomatic"){
                        value = value == "automatic";
                    }
                    else if(name == "hasIndividualStage"){
                        var individualElem =  this.$props_el.find("#isIndividualAutomaticSelectList");
                        e.target.checked ? individualElem.removeClass("hidden") : individualElem.addClass("hidden");
                    }
                    this.CGS.externalApi.startTransaction();
                    this.CGS.model.saveProp({"propName": name, "value": value});
                    if(name == "hasIndividualStage" || name == "isIndividualAutomatic"){
                        var pathTeacher = [{
                            action :"child",
                            args : {
                                type : "example:wordAttack:teacher",
                                index: 0
                            }
                        }];
                        this.CGS.externalApi.activate( pathTeacher, "teacher.showHideIndividual");
                    }
                    this.CGS.externalApi.endTransaction();
                }
            });
            return wordAttackElement;
        });