//list
define(['plugins/wordAttack/list/js/manualArrangement',
        'plugins/wordAttack/main/js/wordSoundUtil',
        'plugins/core/main/imageUpload/imageUpload',
        'text!plugins/wordAttack/list/templates/properties.html',
		'text!plugins/wordAttack/list/templates/stage.html'],
	function (manualArrangement, wordSoundUtil, ImageUpload, propertiesTemplate, stageTemplate, imageUploadTemplate) {
		var ListEditor = function() {

			this.onInitialize = function (details) {
                this.CGS.externalApi.register('list.getListItemIndex', this.getListItemIndex);
                this.CGS.externalApi.register('list.getItemArray', this.getItemArray);
                this.CGS.externalApi.register('list.getListItemSoundsByItemId', this.getListItemSoundsByItemId);
                this.CGS.externalApi.register('list.toggleLetterType', this.toggleLetterType);
                this.CGS.externalApi.register('list.isSoundInWords', this.isSoundInWords);
                this.CGS.externalApi.register('list.isListItemChildValid', this.isListItemChildValid);


                this.imageUpload = new ImageUpload();
                // init the manualArrangement
                this.manualArgEditor = new manualArrangement();
                this.manualArgEditor.init(this.CGS);
                this.manualArgEditor.setDisplayType(this.CGS.model.record.data.listType);
                this.manualArgEditor.setSoundInWords(this.CGS.model.record.data.soundInWord);
                this.registerEvents();
			};

			this.onRenderComplete = function (cfg) {
				//console.log('onRenderComplete');
				this.$content = cfg.$content;
                // add class to list wrapper for styling
                this.$content.closest('.element_preview_wrapper').addClass('list-wrapper').addClass("list-type-" + this.CGS.model.record.data.listType);
                var templateView = this.CGS.RenderTemplate.render(stageTemplate,
                    _.merge({},
                        this.getViewModel(),
                        {"isEdit" : cfg.state === 'edit'}
                    )
                );
				cfg.state === 'edit' ?  this.$content.append(templateView) : this.$content.append(templateView);

                // place add list button only in edit mode
                if(cfg.state === 'edit' && !cfg.readOnly){
                    cfg.$after.append('<button class="btn-editor-plus btn-add-listItem di_icon-Plus"></button>');
                    // gui styling - consider moving to css if becomes complex
                    cfg.$after.css({'padding-top':'6px'});
                }
                cfg.$after.append('<hr class="wordattack-hr"/>');
                if(cfg.state !== 'edit') {
                    // hide overflow for editing preview mode
                    cfg.$after.css({'overflow':'hidden'});
                }
                this.bindEvents();
                this.imageUpload.cfg = cfg;

                var assets = this.CGS.model.getItem({id:this.CGS.model.record.id}).data.assets;
                if(assets && assets.backgroundImage){
                    var path =  this.CGS.externalApi.getAssetAbsolutePath(assets.backgroundImage);
                    this.imageUpload.addBackground(this.$content, path, true );
                }

                if(this.isManual()){
                    this.manualArgEditor.showValidOnButton();
                    this.manualArgEditor.showValidTipOnList();
                }
                this.$sideImage = this.$content.find(".additional-info-image-holder");
				//this.toggleEyesOnTheTeacherView(true);
			};


			this.registerEvents = function(){
                this.CGS.events.register('handleAdditionalInfoImage',this.handleAdditionalInfoImage,this);
            };

            this.unRegisterEvents = function(){
                this.CGS.events.unregister('handleAdditionalInfoImage');
            };

			this.isListItemChildValid = function(itemId) {
            	var listItem =  this.CGS.model.getItem({id: itemId});
            	var editItem = this.CGS.model.getItem({id: listItem.children[0]});
            	if(this.isListTypeWord() && this.isSoundInWords()) {
            		return wordSoundUtil.isWordSoundValid(editItem.data.title.replace(/<[^>]+>/gm, ''));
            	}
            	return true;
			};


			this.onPropertiesViewLoad = function ($el) {
				this.$props_el  = $el;
                this.$props_el.find('.props_editor').on('change.prop','input[type=text],select,input[type=checkbox]',function(e){
                    this.propertyItemChange(e);
                }.bind(this));

				this.imageUpload.init(this.CGS, $("#uploadImagePlaceHolder"));
				 // init manualArgEditor
                this.manualArgEditor.initElement();
				//console.log("onPropertiesViewLoad")
			};

			this.onStartEdit = function () {
				//console.log("onStartEdit")
			};

			this.onEndEdit = function () {
				//console.log("onEndEdit")
			};


			this.onDispose = function () {
				//console.log('onDispose');
                this.unbindEvents();
                this.unRegisterEvents();
                this.disposePropsEvents();
				this.$content = null;
				this.$props_el = null;
			};

            this.disposePropsEvents = function(){
                if(!this.$props_el){
                    return;
                }
                this.$props_el.find('.props_editor').off('change.prop');
            };

            /**
             * asks parent element for the name of this list
             * @returns string - name of the list
             */
			this.getListName = function(){
                var path = [{
                    action :"parent",
                    args : {
                        type : "example:wordAttack:student"
                    }
                }];
                var name = "Column";
                var index = this.CGS.externalApi.activate( path, "student.getListIndex",[this.CGS.model.record.id]);
                return name + " " + index.toString();

            };

            this.getItemArray = function(){
                var itemArray = [];
                for( var ind in this.CGS.model.record.children ){
                    var tmpChild = {
                        id : this.CGS.model.record.children[ind],
                        index : ind*1+1
                    };
                    itemArray.push(tmpChild);
                }

                return itemArray;
            };

            this.toggleLetterType = function(id, type) {
            	var index = this.getListItemIndex(id);

            	this.CGS.externalApi.startTransaction();

            	this.CGS.model.deleteItem({id: id});
            	this.addListItem(index-1, type, false);
            	this.CGS.render();

            	this.CGS.externalApi.endTransaction();
            }


            this.onChildDeleted = function(childId){
                this.CGS.externalApi.startTransaction({ appendToPrevious: true });
                if(this.CGS.model.record.children.length == 1){
                    // set first child to not be deletable now that it is the only one left
                    this.toggleFirstChildDeletable(false);

                }
                // fire list item deleted event
                try {
                    this.CGS.events.fire('wordAttack_script_deleteWordAttackListItem', childId);
                } catch (e){
                    //do nothing
                }

                if(this.CGS.model.record.children.length == 1){
                	//Re-render only in case when one item left, this way we will have NO trash on a single item
                	this.CGS.render();
                } else {
                	//since we dont want to render the list again, what will cause the student side to scroll to top
                	//we will update the item index manualy
                	this.updateChildrenIndex();
                }


                this.CGS.externalApi.endTransaction();

            };

            this.updateChildrenIndex = function() {
            	$(".list-item-numbering", this.$content).each(function(index) {
            		$(this).html((index+1) + ".&nbsp;");
            	});
            };

            /**
            * function handleAdditionalInfoImage
            * This function display the additional info section on the list
            * and showing the image form the relevant script
            * @param additionalImageData (object)
            * include id of the interestList
            * include imageUpload script object
            * include url of the script image url
            */
            this.handleAdditionalInfoImage = function(additionalImageData){
                this.$sideImage = this.$content.find(".additional-info-image-holder");
                if(additionalImageData.id == this.CGS.model.record.id){
                    additionalImageData.scriptImageUpload.setContent(this.$sideImage);
                    additionalImageData.scriptImageUpload.onImageChanged = _.bind(this.handleImageValidity,this);
                    this.$sideImage.show();
                    if(additionalImageData.url){
                        var path =  this.CGS.externalApi.getAssetAbsolutePath(additionalImageData.url);
                        additionalImageData.scriptImageUpload.addBackground( this.$sideImage, path, true);
                    }
                    else{
                         additionalImageData.scriptImageUpload.removeBackground(this.$sideImage);
                    }
                }
                else{
                     this.$sideImage.hide();
                 }

            };

            this.handleImageValidity = function(hasImage){
                if(hasImage){
                    this.$sideImage.removeClass("no-image");
                }
                else{
                    this.$sideImage.addClass("no-image");
                }
            };

            this.toggleFirstChildDeletable = function(isDeletable){
                this.CGS.externalApi.startTransaction({ appendToPrevious: true });

                var path = this.getChildPath(0);
                path.push({
                    action : "setRecordProperty",
                    args 	: {
                        name : "data.disableDelete",
                        value : !isDeletable
                    }
                });

                this.CGS.externalApi.activate(path);
                this.CGS.externalApi.endTransaction();

            };


            this.getChildPath = function(index) {
                var path = [
                            {
                            action :"child",
                            args : {
                                type : "example:wordAttack:listItem",
                                index : parseInt(index)
                                }
                            }
                        ];
                return path;
            };

            this.addListItem = function(insertAt, insertItemType, startEdit, value, position){

            	var listType = this.CGS.model.record.data.listType;

            	var item = undefined;

        		var maxChars = 25;
        		var width = "100%";
        		var autoWidth = true;
				var settings = {"groups" : ["effects","font","paragraph"]};
        		if(listType == "letter" ) {
        			maxChars = 1;
        			width = "36px";
        			autoWidth = false;
					settings.groups = ["font","paragraph"];
        		}

        		var title = value;
        		var image = value;
        		switch(insertItemType) {
	        		case "imageViewer" :
	        			title = undefined;
	        			insertItemType = "sys:imageViewer";
	        			break;

	        		case "textViewer":
	        			insertItemType = "sys:textViewer";
	        			break;

	        		default:
	        			insertItemType = "sys:textViewer";
        		}

                item = {
                    "data" : {
                        "type" : "plugin:example:wordAttack:listItem",
                        "data" : {
                            "deletable" : true
                        },
                        children : [{
                            "type" : insertItemType,
                            "data" : {
                            	"isValid": value != undefined ? true : false,
                                "mode":"custom",
                                "settings" : settings,
                                "deletable" : false,
                                "showNarrationType" : false,
                                "singleLineMode" : true,
                                "width" : width,
                                "autoWidth" : autoWidth,
                                "MaxChars" : maxChars,
                                "title": title,
                                "image": image
                            },
                            "children" :[]
                        }]
                    }
                };

                if(insertAt != undefined) {
                	item.data.insertAt = insertAt;
                }
                if(position != undefined) {
                	item.data.data.position = position;
                }


        		if(item) {
					 var listItemId = this.CGS.model.saveItem(item);

					 // set first child to be deletable now that there is more than one item
					var deletable = this.CGS.model.record.children.length > 1;
					 this.toggleFirstChildDeletable(deletable);
					 this.CGS.render();
					 if(startEdit === true && insertItemType == "sys:textViewer") {
						 this.CGS.startEditing(listItemId);
					 }
					 if(this.isManual()){
					     this.manualArgEditor.showValidOnButton();
					     this.manualArgEditor.showValidTipOnList();
					 }
        		}

            };

            /**
             * Returns the index(+1) of the list with the given id, 0 if does not exist
             * @param id
             * @returns number - index of list item
             */
            this.getListItemIndex = function(id) {
                return this.CGS.model.record.children.indexOf(id) + 1;
            };


            this.getListItemSoundsByItemId = function(id) {
            	var listItem =  this.CGS.model.getItem({id: id});
            	var editItem = this.CGS.model.getItem({id: listItem.children[0]});
            	var soundArray = wordSoundUtil.extractWordSounds(editItem.data.title.replace(/<[^>]+>/gm, ''));
            	return soundArray;
            };


            /**
             * Check if the orientation of this list is not set to horizontal (default is vertical)
             * @returns {boolean}
             */
            this.isVertical = function(){
                return this.CGS.model.record.data.orientation == 'vertical';
            };

            this.isHorizontal = function(){
                return this.CGS.model.record.data.orientation == 'horizontal';
            };

            this.isManual = function(){
               return this.CGS.model.record.data.orientation == 'manual';
            };

            this.isItemNumbering = function() {
            	return this.CGS.model.record.data.item_numbering;
            };

            this.isSoundInWords = function() {
            	if(this.isListTypeWord()) {
            		return this.CGS.model.record.data.soundInWord;
            	}
            	return false;
            };

            this.isListTypeWord = function() {
            	return this.CGS.model.record.data.listType == "word";
            };

            this.bindEvents = function(){
                this.$content.parent().on('click',"button.btn-add-listItem", function(e) {
                	//Make sure event e object is not transfered into addListItem method
                	this.addListItem.call(this, undefined, undefined, true);
                }.bind(this));

            };

            this.unbindEvents = function(){
                this.$content.off('click',"button.btn-add-listItem");

            };

			this.getPropertiesView = function () {
				//console.log("getPropertiesView");
                var template = this.CGS.RenderTemplate.render(propertiesTemplate, this.getViewModel());
				return template;
			};

            // Registering for mustache rendering
            this.getViewModel = function (){
                var self = this;
                return _.merge({},
                    this.CGS.model.record,
                    {
                        'getListName' : this.getListName(),
                        'isVertical' : this.isVertical(),
		    	        'isHorizontal': this.isHorizontal(),
                        'isManual' : this.isManual(),
                        'isItemNumbering': this.isItemNumbering(),
                        'isSoundInWords': this.isSoundInWords(),
                        'isListTypeWord': this.isListTypeWord(),
                        'typeSelected' : function(){
                            return function(text,render){
                                if(text == self.CGS.model.record.data.listType) {
                                    return 'selected';
                                }else{
                                    return '';
                                }
                            }
                        }
                    });
            };

            /**
             * Called when a property has been changed in the properties tab of the editor.
             * @param e - property change event on element.
             */
            this.propertyItemChange = function(e) {

            	var latestListType = this.CGS.model.record.data.listType;

            	this.CGS.externalApi.startTransaction();

                var name = e.target.dataset['recordValue'],
                value = e.target.type == 'checkbox' ? e.target.checked : e.target.value ;
                this.CGS.model.saveProp({"propName" : name ,"value": value });

                if(name == "orientation"){
                    // Case the orientation was changed
                    this.manualArgEditor.showManualMenu();
                } else if(name == "listType") {

                	this.manualArgEditor.setDisplayType(value);

//                	this.updateListCaching(latestListType, value);

					for( var index = this.CGS.model.record.children.length -1 ; index >= 0 ; index-- ){
						this.CGS.model.deleteItem({id: this.CGS.model.record.children[index]});
					}
       				var wrraper = this.$content.closest('.element_preview_wrapper');
       				wrraper.removeClass("list-type-word").removeClass("list-type-letter").removeClass("list-type-sound");
       				wrraper.addClass("list-type-" + this.CGS.model.record.data.listType);

       				this.addListItem(undefined, value, true);

                    try {
                        this.CGS.events.fire('wordAttack_script_resetScriptInterestArea', this.CGS.model.record.id);
                    } catch (e){
                        console.error(e);
                    }

                } else if(name == "item_numbering") {
                	for( var index in this.CGS.model.record.children ){
                        var path = this.getChildPath(index);
                        this.CGS.externalApi.activate(path, "listItem.enableNumbering", [value]);
                	}
                	this.manualArgEditor.showNumbers(value);
                } else if(name == "soundInWord") {
                	this.$props_el.find('properties-hint').toggleClass("hidden", !value);

                	//Validate children
                	for( var index in this.CGS.model.record.children ){
                        var path = this.getChildPath(index);
                        this.CGS.externalApi.activate(path, "listItem.validateChildField", []);
                	}

                    // fire list item deleted event
                    try {
                        this.CGS.events.fire('wordAttack_script_resetSoundInWordsByList', this.CGS.model.record.id);
                    } catch (e){
                        //do nothing
                    }

                    this.manualArgEditor.setSoundInWords(this.CGS.model.record.data.soundInWord);

                }

                this.CGS.externalApi.endTransaction();
            };


            this.updateListCaching = function(latestListType, currentListType) {
            	//Remove all and fetch from buffer or create new
            	//this.cachedTypeToItems
            	this.CGS.externalApi.startTransaction({ appendToPrevious: true });


            	var cachedTypeToItems = this.CGS.model.record.data.cachedTypeToItems;
            	if(!cachedTypeToItems) { cachedTypeToItems = {}; }

				 //Update local cache
            	cachedTypeToItems[latestListType] = [];
				 for( var index in this.CGS.model.record.children ){
					 var listItem =  this.CGS.model.getItem({id: this.CGS.model.record.children[index]});
					 var editItem = this.CGS.model.getItem({id: listItem.children[0]});

					 var itemValue = editItem.data.title;
					 if(editItem.type == "imageViewer") {
						 itemValue = editItem.data.image;
					 }

					 cachedTypeToItems[latestListType].push({
						 type : editItem.type,
						 value: itemValue,
						 position: listItem.data.position
					 });
				 }

				 //Delete all items
   				 for( var index = this.CGS.model.record.children.length -1 ; index >= 0 ; index-- ){
					 this.CGS.model.deleteItem({id: this.CGS.model.record.children[index]});
   				 }


   				 //After delete all items add new item by the current type
   				 if(cachedTypeToItems && cachedTypeToItems[currentListType] && cachedTypeToItems[currentListType].length > 0) {

   					 var editCell = false;
   					 for(i in cachedTypeToItems[currentListType]) {
   						 if(i == (cachedTypeToItems.length-1)) {
   							editCell = true;
   						 }
   						this.addListItem(undefined, cachedTypeToItems[currentListType][i].type, editCell, cachedTypeToItems[currentListType][i].value, cachedTypeToItems[currentListType][i].position);
   					 }

   				 } else {
   					this.addListItem(undefined, undefined, true);
   				 }

   				var wrraper = this.$content.closest('.element_preview_wrapper');
   				wrraper.removeClass("list-type-word").removeClass("list-type-letter").removeClass("list-type-sound");
   				wrraper.addClass("list-type-" + this.CGS.model.record.data.listType);

   				this.CGS.model.saveProp({"propName" : 'cachedTypeToItems' ,"value": cachedTypeToItems });

   				this.CGS.externalApi.endTransaction();

            }
		} ;

		return ListEditor;
});