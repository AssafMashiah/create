define(['plugins/core/main/js/utils',
		'text!plugins/core/main/mediaUpload/mediaUploadTemplate.html'],
	function (Utils, mediaUploadTemplate) {
		var MediaUpload = function(type) {
			this.cfg = null;
			this.mediaType = type;


			/**
			* function init
			* Initialize the MediaUpload object
			* @param CGS the CGS api
			* @param container ( jquery ) media section container
			*/
			this.init = function(CGS, container){
				this.CGS = CGS;
				this.$el = container;

				this.render();

			};

			this.setContent = function(content){
				this.cfg = {};
				this.cfg.$content = content;
			};

			/**
			* function render
			* Render the whole media section on properties
			* @param errorMessage ( String ) oprional
			*/
			this.render = function(errorMessage){
				var self = this;
				var assets = this.CGS.model.getItem({id:this.CGS.model.record.id}).data.assets;
				var mediaObject = Utils.getMediaObject(this.CGS, assets, this.mediaType);

				this.$el.html(this.CGS.RenderTemplate.render(mediaUploadTemplate,{
					"hasMediaContent":mediaObject.hasMedia,
					"hasImage" : mediaObject.hasMedia && this.mediaType == "image",
					"src" : mediaObject.src,
					"errorMessage":errorMessage,
					"mediaType": this.mediaType,
					"contentClass":mediaObject.contentClass,
					"displayClass":mediaObject.displayClass
				}));

				if( mediaObject.hasMedia){
					this.hasPreviewer = true;
					var params = {
						mediaType: this.mediaType,
						previewTargetSelector : "#mediaDisplay",
						src: mediaObject.relativePath

					};
					this.CGS.general.initMediaPreview(params);
				}

				this.bindEvents();
			};


			/**
			* function bindEvents
			* after rendering bind events to the relevant elements
			*/
			this.bindEvents = function(){
				var self = this;
				// additional options (fileMymType and allowFiles are required for ordering assets)
				var allowFiles;
				switch(this.mediaType){
					case "image":
						allowFiles = ['image/png', 'image/jpeg', 'image/gif'];
						break;
					case "video":
						allowFiles = ['video/mp4'];
						break;
					case "audio":
						allowFiles = ['audio/mp3'];
						break;
				}
				var options = {
					fileMymType: this.mediaType,
					allowFiles: allowFiles
				};
				this.mediaManager = this.CGS.externalApi.fileUpload({
					activator:'#uploadMedia', // can be selector string, native element or jQuery element
					recordId:self.CGS.model.record.id, // record id of plugin instance
					srcAttr:this.mediaType + "Content",// src property under the record data (assets - it's constant)
					enableAssetManager: true, // enable ordering for the asset
					callback:function(path, originalName, fileEntry){
						self.clear();
						self.render();
						self.fireSuccess();
					},// success calback
					errorCallback:function(errorMessage){
						self.clear();
						self.render(errorMessage.split("-")[0]);
					},// error callback
					options: options
				});
				this.$el.find("#deleteMedia").on("click",_.bind(this.deleteMedia,this));
			};



			this.clear = function(){
				if( this.hasPreviewer ){
					this.hasPreviewer = false;
					this.CGS.general.disposeMediaPreview("#mediaDisplay");
				}

				this.$el.find("#deleteMedia").off("click");
				this.$el.empty();
			};


			this.deleteMedia = function(){
				this.mediaManager.deleteAsset();
				this.clear();
				this.render();
			};

			this.fireSuccess = function(){
				var holder = this.CGS.model.record.data.path.replace(':','_');
				this.CGS.events.fire(holder+'_mediaUploadUpdated', this.CGS.model.record.id);
			};

		};

		return MediaUpload;
	});