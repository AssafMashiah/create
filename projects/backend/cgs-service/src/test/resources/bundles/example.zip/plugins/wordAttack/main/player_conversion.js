define(['plugins/wordAttack/main/BaseConverter', 'plugins/wordAttack/main/WordAttackConverter'], function (BaseConverter, WordAttackConverter) {
	return function (data) {
		console.log(data);

        var baseConverter = new BaseConverter(data);
        var wordAttackConverter = new WordAttackConverter(baseConverter);
        //wordAttackConverter.convert();
        return wordAttackConverter.convert();

	};
});