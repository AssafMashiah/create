//student
define(['text!plugins/wordAttack/student/templates/properties.html',
      'text!plugins/wordAttack/student/templates/stage.html',
      'plugins/core/baseStudent/index'],
   function (propertiesTemplate, stageTemplate, BaseStudent) {

      var wordAttackStudentEditor = BaseStudent.extend({
         propertiesTemplate:propertiesTemplate,
         stageTemplate:stageTemplate,

         onInitialize: function (details) {
            this.CGS.externalApi.register('student.getListIndex', this.getListIndex);
            this.CGS.externalApi.register('student.getListArray', this.getListArray);
         },
         onRenderComplete: function (config) {
            //console.log('onRenderComplete');
            this.$content = config.$content;
            var menu_height = 260,//document.querySelectorAll('.screen-header')[0].offsetHeight;
               height = document.body.offsetHeight - menu_height;

            var templateView = this.CGS.RenderTemplate.render(this.stageTemplate,
               _.merge({},
                  this.getViewModel(),
                  {"isEdit": config.state === 'edit'}
               )
            );
            config.state === 'edit' ? config.$content.append(templateView) : config.$content.append(templateView);

            // place add list button only in edit mode
            if (config.state === 'edit' && !config.readOnly) {
               config.$after.append('<button class="btn-editor-plus btn-add-list di_icon-Plus"></button>');
               // gui styling - consider moving to css if becomes complex
               config.$after.css({'padding': '6px 0px 0px 15px'})
            }

            if (config.state === 'edit') {
               this.$content.closest('.content-pane').css({
                  'height': height,
                  'min-height': height
               });
            }
            this.bindEvents();
            //this.toggleEyesOnTheTeacherView(true);
         },
         onPropertiesViewLoad: function (el) {
            this.$props_el = el;
            //console.log("onPropertiesViewLoad")
         },
         onChildDeleted: function (childId) {
            this.CGS.externalApi.startTransaction({ appendToPrevious: true });
            if (this.CGS.model.record.children.length == 1) {
               // set first child to not be deletable now that it is the only one left
               this.toggleFirstChildDeletable(false);

            }
            // fire list deleted event
            try {
               this.CGS.events.fire('wordAttack_script_deleteWordAttackList', childId);
            } catch (e) {
               //do nothing
            }

            if(this.CGS.model.record.children.length == 1){
            	//Re-render only in case when one item left, this way we will have NO trash on a single item
            	this.CGS.render();


            	//One list is remained, so we will show properties of element DINEW-1029
				var path = [{
							    action :"parent",
							    args : {
							        type : "example:wordAttack:element"
							    }
							}, {
								action : "getRecordProperty",
								args 	: {
									name : "id"
								}
							}];
				var elementId = this.CGS.externalApi.activate(path);
            	this.CGS.startEditing(elementId);
            } else {
            	//since we dont want to render the list again, what will cause the student side to scroll to top
            	//we will update the item index manualy
            	this.updateChildrenIndex();
            }
            this.CGS.externalApi.endTransaction()
         },

         updateChildrenIndex: function() {
         	$(".list-title", this.$content).each(function(index) {
         		$(this).html("Column " + (index+1));
         	});
         },

         onDispose: function () {
            //console.log('onDispose');
            this.unbindEvents();
            this.$content = null;
            this.$props_el = null;
         },
         toggleFirstChildDeletable: function (isDeletable) {
            var path = [
               {
                  action: "child",
                  args: {
                     type: "example:wordAttack:list",
                     index: 0
                  }
               },
               {
                  action: "setRecordProperty",
                  args: {
                     name: "data.disableDelete",
                     value: !isDeletable
                  }
               }];
            this.CGS.externalApi.activate(path);
         },
         /**
          * return an area of the editor lists
          */
         getListArray: function () {
            var listArray = [];
            for (var ind in this.CGS.model.record.children) {
               var tmpChild = {
                  id: this.CGS.model.record.children[ind],
                  index: ind * 1 + 1
               };
               listArray.push(tmpChild);
            }

            return listArray;
         },

         /**
          * Returns the index(+1) of the list with the given id, 0 if does not exist
          * @param id
          * @returns number - index of list
          */
         getListIndex: function (id) {
            return this.CGS.model.record.children.indexOf(id) + 1;
         },
         /**
          * Add a list to the editor - new list has one default item (non deletable)
          */
         addList: function () {
            var listId = this.CGS.model.saveItem({
               "data": {
                  "type": "plugin:example:wordAttack:list",
                  "data": {
                     "deletable": true,
                     "listType":"word",
                     "item_numbering": true,
                     "soundInWord": false,
                     "cachedTypeToItems": {}
                  },
                  children: [
                     {
                        "type": "plugin:example:wordAttack:listItem",
                        "data": {
                           "deletable": false
                        },
                        children: [
                           {
                              "type": "sys:textViewer",
                              "data": {
                                 "mode": "custom",
                                 "settings": {"groups": ["effects", "font", "paragraph"]},
                                 "deletable": false,
                                 "autoWidth": true,
                                  "showNarrationType" : false,
                                  "width" : "100%",
                                  "singleLineMode" : true,
                                  "MaxChars" : 25
                              },
                              "children": []
                           }
                        ]
                     }
                  ]
               }
            });
            this.CGS.externalApi.startTransaction({ appendToPrevious: true });

            // set first child to be deletable now that there is more than one item
            this.toggleFirstChildDeletable(true);

            this.CGS.render();
            this.CGS.externalApi.endTransaction();

            this.CGS.startEditing(listId);
         },
         bindEvents: function () {
            this.$content.parent().on('click', "button.btn-add-list", this.addList.bind(this));

         },
         unbindEvents: function () {
            this.$content.off('click', "button.btn-add-list");

         },
         // Registering for mustache rendering
         getViewModel: function () {
            return _.merge({},
               this.CGS.model.record,
               //mustache function calls
               {});
         }
         //,
         //this.getListType = function (){
         //   return this.CGS.externalApi.activate( path, "list.getListItemIndex",[this.CGS.model.record.type]);
         //}
      });

      return wordAttackStudentEditor;
   })
;