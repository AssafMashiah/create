define([], 
	function () {
	var ActivityResources = function() {
		/*this.onInitialize = function (details) {
			//console.log("Activity [BUNDLE_NAME] onInitialize");
		};

		this.onRenderComplete = function ($el, state) {
		
		};

		this.onPropertiesViewLoad = function ($el) {
		
		};

		this.onStartEdit = function () {
		
		};

		this.onEndEdit = function () {
		
		};

		this.onDispose = function () {
		
		};

		this.getContentStageView = function () {
		
		};

		this.getPropertiesView = function () {
		
		}*/
	} 

	return ActivityResources;
});