define(['text!plugins/core/main/imageUpload/imageUploadTemplate.html'],
	function (imageUploadTemplate) {
		var ImageUpload = function() {
			this.cfg = null;
			this.onImageChanged = function() {};

			/**
			* function init
			* Initialize the ImageUpload object
			* @param CGS the CGS api
			* @param container ( jquery ) image section container
			*/
			this.init = function(CGS, container, onImageChanged){
				this.CGS = CGS;
				this.$el = container;
				this.render();
				if(onImageChanged) {
					this.onImageChanged = onImageChanged;
				}
			};

			this.setContent = function(content){
				this.cfg = {};
				this.cfg.$content = content;
			};

			/**
			* function render
			* Render the whole image section on properties
			* @param errorMessage ( String ) oprional
			*/
			this.render = function(errorMessage){
				var self = this;
				var assets = this.CGS.model.getItem({id:this.CGS.model.record.id}).data.assets;
				var backgroundImagePath =  assets ? assets.backgroundImage : null;
				this.$el.html(this.CGS.RenderTemplate.render(imageUploadTemplate,{"hasBackgroung":backgroundImagePath, "errorMessage":errorMessage}));
				if(backgroundImagePath){
					var absPath = self.CGS.externalApi.getAssetAbsolutePath(backgroundImagePath);
					self.addBackground($("#imageDisplay"), absPath);
					if(self.cfg)
						self.addBackground(self.cfg.$content, absPath, true);
				}
				else{
					self.removeBackground($("#imageDisplay"));
					if(self.cfg)
						self.removeBackground(self.cfg.$content);
				}
				this.bindEvents();
			};

			/**
			* function bindEvents
			* after rendering bind events to the relevant elements
			*/
			this.bindEvents = function(){
				var self = this;
				this.imageManager = this.CGS.externalApi.fileUpload({
					activator:'#uploadBackgroundImage', // can be selector string, native element or jQuery element
					recordId:self.CGS.model.record.id, // record id of plugin instance
					srcAttr:"backgroundImage",// src property under the record data (assets - it's constant)
					enableAssetManager: true, // enable ordering for the asset
					callback:function(path, originalName, fileEntry){
						self.render();
					},// success calback
					errorCallback:function(errorMessage){
						self.render(errorMessage.split("-")[0]);
					},// error callback
					options:{// additional options (fileMymType and allowFiles are required for ordering assets)
						fileMymType: 'image',
						allowFiles: ['image/png', 'image/jpeg', 'image/gif']
					}
				});
				this.$el.find("#deleteImage").on("click",_.bind(this.deleteImage,this));
			};

			/**
			* function addBackground
			* adding background to the element param
			* @element ( jQuery ) the element that the img tag will be in
			* @path ( string ) the img url
			* @onList ( bool ) if the image is on the list
			*/
			this.addBackground = function(element, path, onList){
				this.removeBackground(element);
				var styleClass = onList ? "image-preview on-list" : "image-preview";
				var imageHtmlTag = "<img src='"+path+"' class='"+styleClass+"' alt='Background'>";
				element.prepend(imageHtmlTag);
				if(onList){
					this.cfg.$content.css("position","relative");
				}

				//RISE EVENT
				this.onImageChanged(imageHtmlTag);
			};

			/**
			* function removeBackground
			* removing background from the element param
			* @element ( jQuery ) the container of the img tag
			*/
			this.removeBackground = function(element){
				if(element){
					element.find("img.image-preview").remove();
				}
				else{
					self.cfg.$content.find("img.image-preview").remove();
				}


				//RISE EVENT
				this.onImageChanged(undefined);
			};

			this.deleteImage = function(){
				this.imageManager.deleteAsset();
				this.render();
			};

		}

		return ImageUpload;
	});