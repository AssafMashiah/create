define(['text!plugins/core/simpleModalEditor/templates/properties.html',
		'text!plugins/core/simpleModalEditor/templates/stage.html'],
	function (propertiesTemplate, stageTemplate) {
		var simpleMoadlEditor = function() {

		this.onInitialize = function (details) {
			//console.log("Activity [BUNDLE_NAME] onInitialize");

		};

		this.onRenderComplete = function (cfg, state) {
		};

		this.onPropertiesViewLoad = function ($el) {
			$el.html(propertiesTemplate);
		};

		this.onStartEdit = function () {
			this.initMenu();
		};

		this.onEndEdit = function () {

		};

		this.onDispose = function () {

		};

		this.getContentStageView = function () {

		};

		this.getPropertiesView = function () {

		}

		this.initMenu = function() {
				/*this.CGS.menu.loadMenu({
				'label' : '((Simple Editor))',
				'id':'menu-button-simple-editor',
				'type':'button',
				'icon':'',
				'canBeDisabled':false,
				subMenuItems:[
					{
						'id':'menu-button-simple-editor-text-viewer', // id in DOM
						'icon':'text-height',
						'type': 'btn-group-title',
						'label' : '((Simple Editor))',
						'canBeDisabled':true,
						'subMenuItems': [
							{
								'id':'menu-button-simple-editor-text-viewer2', // id in DOM
								'icon':'text-height',
								'label' : '((Text Editor))',
								'event': this.addEditor.bind(this,'text'),
								'canBeDisabled':true
							}
						]
					}]
				});*/
		}

		this.addEditor = function (type,menu_object){
				/*var elementId = this.CGS.model.saveItem({
						"data" : {
								"type" : "sys:textViewer",
								"data" : {
									"mode":"custom",
									"settings" : {"groups" : ["styles","effects","font","paragraph"]},
									"deletable" : false,
									"autoWidth" : true,
							},
							"children" :[]
						}
					});
				this.CGS.render();
				this.CGS.startEditing(elementId);*/
		}
		}

		return simpleMoadlEditor;

	});