//script
define(['plugins/core/main/imageUpload/imageUpload',
        'text!plugins/wordAttack/script/templates/properties.html',
		'text!plugins/wordAttack/script/templates/stage.html',
		'text!plugins/wordAttack/script/templates/propertiesSoundList.html',
        'text!plugins/wordAttack/script/templates/propertiesItemList.html',
        'text!plugins/wordAttack/script/templates/propertiesListArray.html',
        'text!plugins/wordAttack/script/templates/copyPropertiesButton.html'],

	function (ImageUpload, propertiesTemplate, stageTemplate, soundListTemplate, itemListTemplate, listArrayTemplate, copyPropsTemplate) {
		var WordAttackScriptElement = function() {

			this.onInitialize = function (details) {
				//console.log("WordAttackScriptElement onInitialize");
				this.CGS.events.register('soundInWordsChanged', this.soundInWordsChanged, this);
				this.CGS.events.register('resetSoundInWordsByList', this.resetSoundInWordsByList, this);
				this.CGS.events.register('resetScriptInterestArea', this.resetScriptInterestArea, this);

                this.CGS.externalApi.register('script.getInterestArea', this.getInterestArea);
				if(this.isPractice()){
					this.CGS.events.register('deleteCorrectionScriptElement',this.deleteCorrectionScriptElement,this);
				}
                // register to interest area changing events - removing lists / list items
                this.imageUpload = new ImageUpload();
                if( this.hasInterestArea() ){
                    this.registerListChangeEvents();
                }
			};

            /**
             * Called by the Host application when element rendering has been completed.
             * Config parameter sent by host is defined as follows:
             *
             * cfg.readOnly - Boolean. True if the view mode rendered is to be readOnly, else false.
             * cfg.state - String. The CGS stage state ("edit" when we are in large stage editor mode)
             * cfg.$content - jQuery object. The main html content for the editor, where the children editors will be rendered.
             * cfg.$before - jQuery object. A Div element preceding the main content (cfg.$content)
             * cfg.$after - jQuery object. A Div element following the main content (cfg.$content)
             *
             * @param cfg - object containing post-rendering data from host
             */
			this.onRenderComplete = function (cfg) {
				//console.log("WordAttackScriptElement onRenderComplete");
				this.$content = cfg.$content;
               /* this.$after = cfg.$after;*/
				this.$content.closest('.element_preview_wrapper').addClass('plugin-script');
                var  isIndividual = this.isScriptContainerIndividual();
				var templateView = this.CGS.RenderTemplate.render(stageTemplate,
					_.merge({},
						this.getViewModel(),
						{"isEdit" : cfg.state === 'edit',
                        "isIndividual" : this.$content.parents(".script-container").hasClass("individual")}
					)
					);

				cfg.state === 'edit' ?  this.$content.append(templateView) : this.$content.append(templateView);
                cfg.$after.addClass('script-after');
                // in edit mode, add picture button to additional info
                if(this.isAdditionalInfo() && cfg.state === 'edit' ){

                }

               // cfg.$after.addClass('script-after');
				this.bindEvents();
			};

			this.onPropertiesViewLoad = function ($props_el) {
				this.$props_el = $props_el;
				$props_el.find("select").each(function(item){
                    if($(this).find('option').length == 1){
                        $(this).prop('disabled','disabled');
                    }
                });
                this.$interestArea = $props_el.find('#wordAttack-interestArea-selector');
                var interestArea = this.getPreviousInterest();
                if ( this.hasInterestArea() && !interestArea ){
                    $props_el.find('.btn-copy-properties').prop('disabled','disabled');
                }

                this.imageUpload.init(this.CGS, $("#additionalInfoImagePlaceHolder"));

				this.bindPropsEvents();

                this.manageAdditionalInfoImage();
				//since CGS automatically enables all inputs we need to disabled unnecessary behavior of sound in words
				this.setMarkSoundDisabled();
			};

			this.setMarkSoundDisabled = function() {

				if(!this.isMarkSoundEnabled()) {
					$("#mark-sound", this.$props_el).attr('disabled', 'disabled');
				}
				$(".mark-sound-txt", this.$props_el).toggleClass('disabled', !this.isMarkSoundEnabled());

				if(!this.isSoundDropdownEnabled()) {
					$("#select-sound", this.$props_el).attr('disabled', 'disabled');
				}


			}

            /**
             * Handle call from CGS when a child element has been deleted.
             * This function re-inserts the "add image" element after an image viewer has been deleted
             * @param childId - the ID of the child element deleted
             */
            this.onChildDeleted = function(childId){
                this.CGS.externalApi.startTransaction({ appendToPrevious: true });
                this.CGS.model.saveProp({"propName" : 'hasImage' ,"value": false });
               // this.$after.append(this.CGS.RenderTemplate.render(addImageTemplate));
                this.CGS.externalApi.endTransaction()
            };

			this.isPractice = function () {
				return this.CGS.model.record.data.type == 'practice';
			};

            this.isDirection = function () {
                return this.CGS.model.record.data.type == 'direction';
            };

            this.isAdditionalInfo = function() {
                return this.CGS.model.record.data.type == 'additionalInfo';
            };

            this.hasImage = function(){
                return this.CGS.model.record.data.hasImage == true;
            };

            // does the script component have an interest area attached
            this.hasInterestArea = function(){
                return this.CGS.model.record.data.hasInterestArea;
            };

            /**
             *
             */
            this.getScriptDisplayName = function(){
                switch( this.CGS.model.record.data.type ){
                    case "practice":
                        return "Practice";
                        break;
                    case "direction":
                        return "Direction";
                        break;
                    case "additionalInfo":
                        return "Additional Info";
                        break;
                    default:
                        return "Script";
                        break;
                }
            };

            /**
             * Set the text that will be displayed in the interest area reference box in the script border
             */
            this.setInterestAreaRef = function(){
                var ref = "";
                var valid = this.isValid();
                if( this.CGS.model.record.data.hasInterestArea && valid ){
                    var list = this.getListIndexById(this.CGS.model.record.data.interestList);
                    var item = this.getListItemIndexById(list, this.CGS.model.record.data.interestItem);
                    ref = 'C' + list + 'W' + item;

                    if(this.isSoundInWordsActive() && this.isMarkSoundSelected() && this.isItemInterestAreaValid()) {
                    	var sound = this.CGS.model.record.data.interestSoundIndex;
                        if(sound) {
                        	if(sound == "Manual") {
                        		ref += " " + sound
                        	} else {
                        		ref += 'S' + sound
                        	}
                        }
                    }
                }


                this.CGS.model.saveProp({"propName" : 'contentValid' ,"value": valid});
                this.CGS.model.saveProp({"propName" : 'interestAreaRef' ,"value": ref, "triggerChanged" : true });
                //this.manageAdditionalInfoImage("interestListChanged");
                // update view
                this.toggleInterestAreaRefView();
            };

            this.getInterestAreaRef = function(){
                return this.CGS.model.record.data.interestAreaRef;
            };

            this.soundInWordsChanged = function(itemId) {
            	if(this.CGS.model.record.data.interestItem == itemId) {
            		this.restInterestSound();
            	}
            };

            this.resetSoundInWordsByList = function(listId) {
            	if(listId == this.CGS.model.record.data.interestList) {
            		this.restInterestSound();
            	}
            }

            this.getType = function() {
                return this.CGS.model.record.data.type;
            };

            this.onSelected = function(){
                var path = [{
                    action :"parent",
                    args : {
                        type : "example:wordAttack:scriptContainer"
                    }
                }];
                this.CGS.externalApi.activate(path,'scriptContainer.sectionConstraints',[this.CGS.model.record.id]);
            };

            this.isScriptContainerIndividual = function (){
                var path = [{
                     action: "parent",
                        args: {
                            type: "example:wordAttack:element",
                            index: 0
                        }
                    },
                    {
                       action : "getRecordProperty",
                       args    : {
                          name : "data.activeScriptContainer"
                      }
                    }];
                    return this.CGS.externalApi.activate(path) == 1;
            };

            /**
             * This function returns the interest area of the script in form of
             * {interestList : UUID, interestItem : UUID }
             * If no interest area exists, or the values are not valid, then undefined is returned
             * @returns {Object|undefined} - the interest area object
             */
            this.getInterestArea = function(){
                var interestArea;
                if(this.hasInterestArea() && this.isValid()){
                    interestArea = {};
                    interestArea.interestList = this.CGS.model.record.data.interestList;
                    interestArea.interestItem = this.CGS.model.record.data.interestItem;
                    interestArea.interestSoundIndex = this.CGS.model.record.data.interestSoundIndex;
                    interestArea.markSound          = this.CGS.model.record.data.markSound;
                }

                return interestArea;
            };

            /**
             * Get array of lists in student component
             * @returns array
             */
            this.getListArray = function(){
                // path to student plugin
                var path = [
                    {
                        action : "parent",
                        args : {
                            type : "example:wordAttack:teacher"
                        }
                    },
                    {
                        action : "next"
                    }];
                var result = this.CGS.externalApi.activate(path, "student.getListArray");
                result = _.map(result,function(item){
                    return {
                        listNum : item.index,
                        listId : item.id ,
                        listSelected : item.id == this.CGS.model.record.data.interestList
                    };
                },this);

                var defaultList = {
                    listNum : "None",
                    listId : "none",
                    listSelected : "none" == this.CGS.model.record.data.interestList
                };
                // add default item to start of list
                result.unshift(defaultList);
                return result;


            };

            /**
             * Get array of list items for the list with the given index.
             * Indexes start from 1. Index 0 means no list, amd a default item 'none' is returned
             * @param index (number)
             * @returns array
             */

            this.getListItemArrayForList = function(index){
                var defaultItem = {
                    itemNum : "None",
                    itemId : "none",
                    ItemSelected : "none" == this.CGS.model.record.data.interestItem
                };
                if( index == 0 ){
                    return [defaultItem];
                }

                // path to list in student plugin
                var path = [
                    {
                        action : "parent",
                        args : {
                            type : "example:wordAttack:teacher"
                        }
                    },
                    {
                        action : "next"
                    },
                    {
                        action : "child",
                        args : {
                            type : "example:wordAttack:list",
                            index : index-1
                        }

                    }];
                var result = this.CGS.externalApi.activate(path, "list.getItemArray");
                result = _.map(result,function(item){
                    return {
                        itemNum : item.index,
                        itemId : item.id ,
                        itemSelected : item.id == this.CGS.model.record.data.interestItem
                    };
                },this);
                // add default item to start of list
                result.unshift(defaultItem);
                return result;

            };

            /**
             * Get correction list defined for this activity
             * @returns array
             */
			this.getCorrectionScriptList = function (){

				var path = [
						{
							action : "parent",
							args : {
									type : "example:wordAttack:teacher"
								}
						},
						{
							action : "parent",
							args : {
									type : "example:wordAttack:element"
								}
						},
						{
							action : "getRecordProperty",
							args 	: {
								name : "data.correctionDataList"
							}
						}];
			 	var result = this.CGS.externalApi.activate(path);
			 	result = _.map(result,function(item){
						return {
							name : item.name ,
							id : item.id ,
							correctionSelected : item.id == this.CGS.model.record.data.correctionScript
						};
					},this);

			 	return result;
			};

			this.onStartEdit = function () {
				var pathTeacher = [{
					action :"parent",
					args : {
						type : "example:wordAttack:teacher"
					}
				}];
              var pathScriptContainer = [{
                    action :"parent",
                    args : {
                        type : "example:wordAttack:scriptContainer"
                    }
                }];
				this.CGS.externalApi.activate( pathTeacher, "teacher.initMenu");
                this.CGS.externalApi.activate(pathScriptContainer,'scriptContainer.sectionConstraints',[this.CGS.model.record.id]);
				//this.displayStudentContent(this.CGS.model.record.data.displayStudentContent);
			};

			this.onEndEdit = function () {
                this.manageAdditionalInfoImage(true);
				//this.disposePropsEvents();
				//this.disposeEvents();
			};

			this.onDispose = function () {
				//console.log('WordAttackScriptElement onDispose');
				this.disposeEvents();
				this.disposePropsEvents();
				this.CGS.events.unregister('deleteCorrectionScriptElement');
				this.CGS.events.unregister('soundInWordsChanged');
				this.CGS.events.unregister('resetSoundInWordsByList');
				this.CGS.events.unregister('resetScriptInterestArea');
                this.unregisterListChangeEvents();
			};

            this.registerListChangeEvents = function(){
                this.CGS.events.register('deleteWordAttackList',this.deleteWordAttackList,this);
                this.CGS.events.register('deleteWordAttackListItem',this.deleteWordAttackListItem,this);
            };

            this.unregisterListChangeEvents = function(){
                this.CGS.events.unregister('deleteWordAttackList',this.deleteWordAttackList,this);
                this.CGS.events.unregister('deleteWordAttackListItem',this.deleteWordAttackListItem,this);
            };


			this.bindEvents = function (){
               // this.$content.parent().on('click',"button.btn-editor-addImage", this.addImageViewer.bind(this));
				this.$content.on('change','.ribbon select',this.changeScriptType.bind(this));
			};

			this.bindPropsEvents = function(){
				if(!this.$props_el){
					return;
				}
				this.$props_el.find('.props_editor').on('change.prop','input[type=text],select,input[type=checkbox]',function(e){
					this.propertyItemChange(e);
				}.bind(this));
                this.$props_el.find('#word-attack-copy-properties-button').on('click.prop','button',function(e){
                    this.copyFromPrevious(e);
                }.bind(this));
			};

            this.copyFromPrevious = function(){
                this.CGS.externalApi.startTransaction();
                var interestArea = this.getPreviousInterest();
                this.CGS.model.saveProp({"propName" : "interestList" ,"value": interestArea.interestList });
                this.CGS.model.saveProp({"propName" : "interestItem" ,"value": interestArea.interestItem });
                this.CGS.model.saveProp({"propName" : "interestSoundIndex" ,"value": interestArea.interestSoundIndex });
                this.CGS.model.saveProp({"propName" : "markSound" ,"value": interestArea.markSound });
                this.updateListArray();
                this.updateItemList();
                this.updateSoundList();
                this.setInterestAreaRef();
                this.CGS.externalApi.endTransaction();

            };

            this.getPreviousInterest = function(){
                var path = [{
                    action :"prev"
                }];

				var recordPath = [{
					action : "getRecordProperty",
					args 	: {
						name : "data.name"
					}
				}];

				var prevType = this.CGS.externalApi.activate( path.concat(recordPath));
				if( prevType == "section"){
					return this.CGS.externalApi.activate( path, "section.getInterestArea");
				} else {
					return this.CGS.externalApi.activate( path, "script.getInterestArea");
				}


            };

			this.disposeEvents = function(){
				this.$content.off('change','.ribbon select',this.changeScriptType.bind(this));
			};

			this.disposePropsEvents = function(){
				if(!this.$props_el){
					return;
				}
				this.$props_el.find('.props_editor').off('change.prop');
                this.$props_el.find('#word-attack-copy-properties-button').off('click.prop');
			};

			this.getContentStageView = function () {
				return stageTemplate;
			};

            /**
             * Render the item list template with the relevant item list
             */
            this.updateItemList = function(){

                var hasItem = this.CGS.model.record.data.interestItem && this.CGS.model.record.data.interestItem !="none";
                // get index of interest list
                var listIndex = this.getListIndexById(this.CGS.model.record.data.interestList);
                var itemArray  = this.getListItemArrayForList(listIndex);
                var template = this.CGS.RenderTemplate.render(itemListTemplate,
                    {   'itemArray' : itemArray,
                        'hasItem'   : hasItem
                    }
                );
                var container = this.$props_el.find('#wordAttack-script-properties-itemList');

                container.empty();
                container.append(template);
                container.find("select").each(function(item){
                    if($(this).find('option').length == 1){
                        $(this).prop('disabled','disabled');
                    }
                });

                //refresh sounds template on list change !!!!!
                this.updateSoundList();
            };

            /**
            * function manageAdditionalInfoImage
            * managing the images for scripts and call the lists to handle the image for additional info
            * @param clearAll (boolean) if need to clear all images on lists
            */
            this.manageAdditionalInfoImage = function(clearAll){
                var isAdditionalInfo = this.isAdditionalInfo();
                var hasImage = this.hasImage();
                var data = {"scriptImageUpload":this.imageUpload};
                if(!clearAll && isAdditionalInfo && hasImage){
                    var assets = this.CGS.model.record.data.assets;
                    if(this.CGS.model.record.data.interestAreaRef != ""){
                        data.id = this.CGS.model.record.data.interestList;
                    }
                   data.url = (assets && assets.backgroundImage) ? assets.backgroundImage : undefined;
                }
                this.CGS.events.fire('wordAttack_list_handleAdditionalInfoImage', data);
            };


            this.getListItemSoundsByItemId = function(listIndex, itemId) {
            	var soundArray = [];

            	if(listIndex && itemId) {
	                // path to list in student plugin
	                var path = [
	                    {
	                        action : "parent",
	                        args : {
	                            type : "example:wordAttack:teacher"
	                        }
	                    },
	                    {
	                        action : "next"
	                    },
	                    {
	                        action : "child",
	                        args : {
	                            type : "example:wordAttack:list",
	                            index : listIndex-1
	                        }

	                    }];
	                var index = 0;
	                soundArray = this.CGS.externalApi.activate(path, "list.getListItemSoundsByItemId", [itemId]);
	            	soundArray = _.map(soundArray, function(sound) {
	            		index++;
	            		var soundSelected = (this.CGS.model.record.data.interestSoundIndex == index) ? index : undefined;
	            		return {index: index, sound: index + ". " + sound, soundSelected: soundSelected};
	            	}.bind(this));
            	}

                var defaultSound = {
                		index : "none",
                		sound : "None",
                		soundSelected : "None" == this.CGS.model.record.data.interestSoundIndex
                };
                soundArray.unshift(defaultSound);

                var manualSelection = {
                		index : "Manual",
                		sound : "Manual Selection",
                		soundSelected : "Manual" == this.CGS.model.record.data.interestSoundIndex
                };
                soundArray.push(manualSelection);

            	return soundArray;
            }

            this.updateSoundList = function() {
            	var container = this.$props_el.find('#wordAttack-script-properties-soundList');
            	container.empty();
            	if(!this.isSoundInWordsActive()) {
            		return;
            	}

                var hasItem = this.CGS.model.record.data.interestItem && this.CGS.model.record.data.interestItem !="none";
                // get index of interest list
                var listIndex = this.getListIndexById(this.CGS.model.record.data.interestList);
                var itemArray  = this.getListItemArrayForList(listIndex);
                var selectedItem = _.filter(itemArray, function(item) {
                	return (item.itemSelected === true) ? true : false;
                })

                var template = "";
                var soundItems = [];
                var wordId = undefined;
                if(selectedItem.length > 0) {
                	wordId = selectedItem[0].itemId;
                }
                soundItems = this.getListItemSoundsByItemId(listIndex, wordId);

                template = this.CGS.RenderTemplate.render(soundListTemplate,
                        {
                			'soundArray' : soundItems,
                            'hasItem'   : hasItem,
                            'isMarkSoundSelected': this.isMarkSoundSelected.bind(this),
                            'isSoundInWordsActive': this.isSoundInWordsActive.bind(this),
                            'hasInterestItem' : this.hasInterestItem.bind(this),
                            'isItemInterestAreaValid': this.isItemInterestAreaValid.bind(this),
                            'isMarkSoundEnabled'   : this.isMarkSoundEnabled.bind(this),
                            'isSoundDropdownEnabled': this.isSoundDropdownEnabled.bind(this)
                        }
                    );




                container.append(template);
                container.find("select").each(function(item){
                    if($(this).find('option').length == 1){
                        $(this).prop('disabled','disabled');
                    }
                });
            }


            /**
             * Render the list array template with the relevant list of lists
             */
            this.updateListArray = function(){

                var hasList = this.CGS.model.record.data.interestList && this.CGS.model.record.data.interestList !="none";
                // get index of interest list
                var listArray = this.getListArray();
                var template = this.CGS.RenderTemplate.render(listArrayTemplate,
                    {   'listArray' : listArray,
                        'hasList'   : hasList
                    }
                );
                var container = this.$props_el.find('#wordAttack-script-properties-listArray');

                container.empty();
                container.append(template);


            };

            this.renderCopyButton = function(){

                var template = this.CGS.RenderTemplate.render(copyPropsTemplate);

                var container = this.$props_el.find('#word-attack-copy-properties-button');

                container.empty();
                container.append(template);
                var interestArea = this.getPreviousInterest();
                if ( !interestArea ){
                    container.find('.btn-copy-properties').prop('disabled','disabled');
                }
            };

            /**
             * Toggles the interest area selection state on/off
             * Removes the html select elements as well as resets the data record for interest area
             * @param toggleState - true to add interest area properties, false to remove
             */
            this.toggleInterestArea = function(toggleState){
                var container;
                this.resetInterestList();
                if( toggleState )
                {
                    this.$props_el.find('.interestArea-title').removeClass('hide');
                    this.registerListChangeEvents();
                   this.updateListArray();
                   this.updateItemList();
                    this.renderCopyButton();
                } else {
                    this.$props_el.find('.interestArea-title').addClass('hide');
                    this.unregisterListChangeEvents();
                    container = this.$props_el.find('#wordAttack-script-properties-listArray');
                    container.empty();
                    container = this.$props_el.find('#wordAttack-script-properties-itemList');
                    container.empty();
                    container = this.$props_el.find('#word-attack-copy-properties-button');
                    container.empty();

                }
            };

            this.resetScriptInterestArea = function(listId) {
            	if(listId === this.CGS.model.record.data.interestList) {
            		this.resetInterestList();
            	}
            };

            this.resetInterestList = function(){
                this.CGS.model.saveProp({"propName" : 'interestList' ,"value": 'none' });
                this.resetInterestItem();
            };

            this.resetInterestItem = function(){
                this.CGS.model.saveProp({"propName" : 'interestItem' ,"value": 'none', "triggerChanged" : true });
                this.restInterestSound();
            };

            this.restInterestSound = function() {
            	this.CGS.model.saveProp({"propName" : 'interestSoundIndex' ,"value": 'none', "triggerChanged" : true  });

            	this.setInterestAreaRef();
            };


            this.isMarkSoundEnabled = function() {
            	return (this.hasInterestItem() && this.isItemInterestAreaValid());
            }

            this.isSoundDropdownEnabled = function() {
            	return (this.isMarkSoundEnabled() && this.isMarkSoundSelected()) ? true : false;
            }


            this.isItemInterestAreaValid = function() {
            	if(this.CGS.model.record.data.interestItem && this.CGS.model.record.data.interestItem != 'none') {
            		//go to list, and validate child

            		var listIndex = this.getListIndexById(this.CGS.model.record.data.interestList);

                    var path = [
                                {
                                    action : "parent",
                                    args : {
                                        type : "example:wordAttack:teacher"
                                    }
                                },
                                {
                                    action : "next"
                                },
                                {
                                    action : "child",
                                    args : {
                                        type : "example:wordAttack:list",
                                        index : listIndex-1
                                    }

                                }];

                  return this.CGS.externalApi.activate(path, "list.isListItemChildValid", [this.CGS.model.record.data.interestItem]);
            	}
            	return false;
            }

            this.isMarkSoundSelected = function() {
            	return this.CGS.model.record.data.markSound;
            };

            this.isSoundInWordsActive = function() {

            	if(this.CGS.model.record.data.interestList && this.CGS.model.record.data.interestList != 'none') {

            		var listIndex = this.getListIndexById(this.CGS.model.record.data.interestList);

                    // path to list in student plugin
                    var path = [
                        {
                            action : "parent",
                            args : {
                                type : "example:wordAttack:teacher"
                            }
                        },
                        {
                            action : "next"
                        },
                        {
                            action : "child",
                            args : {
                                type : "example:wordAttack:list",
                                index : listIndex-1
                            }

                        }];
                    return this.CGS.externalApi.activate( path, "list.isSoundInWords",[]);
            	}

            	return false;

            };

            /**
             * Check whether the script element is valid:
             * If the element has an interest area, it must be set to a list item in order to be valid
             * @returns {boolean} - the validity of the script content
             */
            this.isValid = function(){
                var isValid = true;
                if( this.hasInterestArea()){
                    var hasItem  = (this.CGS.model.record.data.interestItem && this.CGS.model.record.data.interestItem != 'none');
                    var hasList  = (this.CGS.model.record.data.interestList && this.CGS.model.record.data.interestList != 'none');
                    isValid = hasList && hasItem;

                    if(isValid) {
                    	//this.CGS.model.record.data.markSound
                    	if(this.isSoundInWordsActive() && this.isMarkSoundSelected()) {
                    		if(this.isItemInterestAreaValid()) {
                    			return (this.CGS.model.record.data.interestSoundIndex && this.CGS.model.record.data.interestSoundIndex != 'none'); //if sound exists its valid else not valid
                    		} else {
                    			return false;
                    		}
                    	}
                    }

                }

                return isValid;
            };

            /**
             * Toggles the display of the interest area reference box in the script frame
             * This function checks the state of the scripts validity and updates the view accordingly:
             * 1. If the script has no interest area, the reference box is removed
             * 2. If the script has an interest area and is not valid, then a warning icon is displayed in the reference box
             * 3. If the script has an interest area and is valid, the list and item index are displayed in the reference box
             */
            this.toggleInterestAreaRefView = function(){
                var container = this.$content.find('.ribbon');
                var interestRef = container.find('#wordAttack-script-interest-ref');
                var validRef = container.find('#wordAttack-script-validity');
                var scriptTitle = container.find(".script-name");

                if( this.hasInterestArea() ){
                    if( this.isValid() ){
                        validRef.addClass("hide");
                        scriptTitle.removeClass('invalid-content');
                        interestRef.html(this.getInterestAreaRef());
                        interestRef.removeClass("hide");
                    } else{
                        interestRef.addClass('hide');
                        validRef.removeClass("hide");
                        scriptTitle.addClass('invalid-content');
                    }
                } else {
                    validRef.addClass("hide");
                    interestRef.addClass('hide');
                    scriptTitle.removeClass('invalid-content');

                }

            };

            this.hasInterestItem = function() {
            	return this.CGS.model.record.data.interestItem != 'none' ? true : false;
            }

            // returns the property view for the plugin
			this.getPropertiesView = function () {
				//return propertiesTemplate;
				var template = this.CGS.RenderTemplate.render(propertiesTemplate,
					this.getViewModel()
					);
				return template;
			};

            // copied from vocabulary script, currently not in use
            // TODO: revisit functionality
			this.changeScriptType = function (e) {
				this.CGS.model.saveProp({"propName" : "type","value": $(e.target).val() });
				this.CGS.startEditing(this.CGS.model.record.id);
			};

            /**
             * Get the index of a list item from it's list
             * @param listIndex - the list index in the student editor plug-in
             * @param id - the id of the item in the list
             * @returns index of the item in list
             */
            this.getListItemIndexById = function(listIndex, id){
                // path to list in student plugin
                var path = [
                    {
                        action : "parent",
                        args : {
                            type : "example:wordAttack:teacher"
                        }
                    },
                    {
                        action : "next"
                    },
                    {
                        action : "child",
                        args : {
                            type : "example:wordAttack:list",
                            index : listIndex-1
                        }

                    }];
                var index = this.CGS.externalApi.activate( path, "list.getListItemIndex",[id]);
                return index;
            };

            // get the index of a list in student plugin by it's id
            this.getListIndexById = function(id){
                if(!id || id =="none"){
                    return 0;
                }
                //path to student
                var path = [{
                    action : 'parent',
                    args : {type:"example:wordAttack:teacher"}
                },{
                    action 	: 'next',
                    args 	: {type : 'example:wordAttack:student'}
                }];
                var index = this.CGS.externalApi.activate( path, "student.getListIndex",[id]);
                return index;
            };

			this.getViewModel = function (){
				var correctionList = {};
                var listArray = {}, itemArray = {}, soundArray = {};
                var listIndex = 0;
				if(this.isPractice()) {
                    correctionList = this.getCorrectionScriptList();
				}
                listArray = this.getListArray();
                // get index of interest list
                listIndex = this.getListIndexById(this.CGS.model.record.data.interestList);

                itemArray  = this.getListItemArrayForList(listIndex);

                var soundItems = [];
                if(this.CGS.model.record.data.interestItem) {

                    var selectedItems = _.filter(itemArray, function(item) {
                    	if(item.itemSelected == true) {
                    		return item;
                    	}
                    });

                    if(this.isSoundInWordsActive()) {
	                    var wordId = undefined;
	                    if(selectedItems.length > 0) {
	                    	wordId = selectedItems[0].itemId;
	                    }
	                	soundArray = this.getListItemSoundsByItemId(listIndex, wordId);
                    }
                }
                var  isIndividual = this.isScriptContainerIndividual();
				var result = _.merge({},
						this.CGS.model.record,
						{
                            'scriptDisplayName' : this.getScriptDisplayName(),
							'isPractice' : this.isPractice(),
                            'isDirection' : this.isDirection(),
                            'isAdditionalInfo' : this.isAdditionalInfo(),
                            'hasInterestArea' : this.hasInterestArea(),
							'correctionList'	: correctionList,
                            'listArray'         : listArray,
                            'itemArray'         : itemArray,
                            'soundArray'        : soundArray,
                            'interestAreaRef'  : this.getInterestAreaRef(),
                            'isValid'           : this.CGS.model.record.data.contentValid, //this.isValid(),
                            'isSoundInWordsActive': this.isSoundInWordsActive(),
                            'isMarkSoundSelected' : this.isMarkSoundSelected(),
                            'isMarkSoundEnabled'   : this.isMarkSoundEnabled(),
                            'hasInterestItem'     : this.hasInterestItem(),
                            'isIndividual'          :isIndividual,
                            'hasImage'              :this.hasImage(),
                            'isSoundDropdownEnabled': this.isSoundDropdownEnabled.bind(this),
                            'hasSound'      : this.CGS.model.record.data.interestSoundIndex && this.CGS.model.record.data.interestSoundIndex !="none",
                            'hasItem'       : this.CGS.model.record.data.interestItem && this.CGS.model.record.data.interestItem !="none",
                            'hasList'       : this.CGS.model.record.data.interestList && this.CGS.model.record.data.interestList !="none"
						});
                return result;
			};

            /**
             * Called when a property has been changed in the properties tab of the editor.
             * @param e - property change event on element.
             */
			this.propertyItemChange = function(e) {

				this.CGS.externalApi.startTransaction();

				var name = e.target.dataset['recordValue'],
					value = e.target.type == 'checkbox' ? e.target.checked : e.target.value ;

				this.CGS.model.saveProp({"propName" : name ,"value": value });

                switch(name)
                {
                    case 'interestList':
                        // update properties tab if interest area changed with 'none' as selected item
                        this.resetInterestItem();
                        this.updateItemList();
                        this.manageAdditionalInfoImage();
                        break;
                    case 'interestItem':
                        this.restInterestSound();
                        this.updateSoundList();
                        this.setInterestAreaRef();
                        this.manageAdditionalInfoImage();
                        break;
                    case 'interestSoundIndex':
                    	this.setInterestAreaRef();
                    	break;
                    case 'hasInterestArea':
                        // add / remove interest area
                        this.toggleInterestArea(value);
                        break;
                    case 'markSound':
                    	this.updateSoundList();
                    	this.setInterestAreaRef();
                		break;
                    case 'hasImage':
                            this.showHideImagePlaceHolder();
                            this.manageAdditionalInfoImage();
                        break;

                }
                this.CGS.externalApi.endTransaction(value);


			};

            this.showHideImagePlaceHolder = function(){
                var $imageEditor = $("#additionalInfoImagePlaceHolder");
                this.hasImage() ? $imageEditor.show() : $imageEditor.hide();
            }

            // Taken from vocabulary activity, might be needed in wordAttack in the future.
            // TODO: revisit functionality
			this.displayStudentContent = function (value){
				var path = [{
					action : 'parent',
					args : {type:"example:wordAttack:teacher"}
				},{
					action 	: 'next',
					args 	: {type : 'example:wordAttack:student'}
				}];
				this.CGS.externalApi.activate(path,'student.DisplayStudentContent',[value]);
			};

            /**
             * Action on deletion of correction script
             * @param id - string representing deleted correction
             */
			this.deleteCorrectionScriptElement = function(id){
				if (this.CGS.model.record.data.correctionScript == id){
                    this.CGS.externalApi.startTransaction();
                    this.CGS.model.saveProp({"propName" : 'correctionScript' ,"value": 'default_correction_script' });
                    this.CGS.externalApi.endTransaction();
				}
			};

            /**
             * Action on deletion of list
             * @param id - string representing deleted list
             */
            this.deleteWordAttackList = function(id){
                this.CGS.externalApi.startTransaction({ appendToPrevious: true });
                if (this.CGS.model.record.data.interestList == id){
                    this.resetInterestList();
                }
                this.setInterestAreaRef();
                this.CGS.externalApi.endTransaction();
            };

            /**
             * Action on deletion of list item
             * @param id - string representing deleted list item
             */
            this.deleteWordAttackListItem = function(id){
                this.CGS.externalApi.startTransaction({ appendToPrevious: true });
                if (this.CGS.model.record.data.interestItem == id){
                    this.resetInterestItem();
                }
                this.setInterestAreaRef();
                this.CGS.externalApi.endTransaction();
            };

		};

		return WordAttackScriptElement;
});