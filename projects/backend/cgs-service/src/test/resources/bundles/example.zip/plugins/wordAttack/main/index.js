define(['text!plugins/wordAttack/main/templates/properties.html',
	'text!plugins/wordAttack/main/templates/stage.html'],
	function (propertiesTemplate, stageTemplate) {
	var ActivityWordAttack = function() {
		this.onInitialize = function (details) {
		};

		this.onRenderComplete = function (cfg) {

		};

		this.onPropertiesViewLoad = function ($el) {
			var self = this;
			this.$props_el = $el;
			this.bindPropertiesEvents();

		};

		this.onStartEdit = function () {
			//console.log("Plugin Start Editing")
		};

		this.onEndEdit = function () {
			//console.log("Plugin End Editing")
			this.unbindPropertiesEvents();
		};

		this.onDispose = function () {
			this.$props_el = null;

		};

		this.getContentStageView = function () {
			//return stageTemplate;
		};

		this.getPropertiesView = function () {
			return propertiesTemplate;
		}

		this.bindPropertiesEvents = function (){
			var self = this;
			if(!this.$props_el){
				return ;
			}
			this.$props_el.find('#field_title').on('change', function () {
				var rec = self.CGS.model.record;

				self.CGS.model.saveProp({
					propName: "title",
					value: $(this).val(),
					triggerChange: true
				});

			});
		}
		this.unbindPropertiesEvents = function (){
			if(!this.$props_el){
				return;
			}
			this.$props_el.find('#field_title').off('change');
		}
	}

	return ActivityWordAttack;
});