define(['text!plugins/wordAttack/section/templates/stage.html',
		'plugins/core/basePlugin/index'],

	function (stageTemplate,BasePlugin) {

		var sectionPlugin = BasePlugin.extend({
			onInitialize : function(){
				this.CGS.externalApi.register('section.getInterestArea', this.getInterestArea);
			},
			onRenderComplete : function (config) {
				var path = [{
                    action :"parent",
                    args : {
                        type : "example:wordAttack:scriptContainer"
                    }
                }];
                config.$content.closest('.element_preview_wrapper').addClass('plugin-section');
                var index = this.CGS.externalApi.activate(path,'scriptContainer.getSectionIndex',[this.CGS.model.record.id]);
				config.$content.append(this.CGS.RenderTemplate.render(stageTemplate,{
				 	color 		: 'color'+ index % 12,
				 	count 		: index,
				 	icon 	: (this.isSectionStart() ? 'Start' : 'End')
				 }));

			},
			hasInterestArea : function () {
				return {};
			},

			isSectionStart : function (){
				return this.CGS.model.record.data.section_type == 'start';
			},

			onStartEdit : function(){
				var pathTeacher = [{
					action :"parent",
					args : {
						type : "example:wordAttack:teacher"
					}
				}];
				var pathScriptContainer = [{
					action :"parent",
					args : {
						type : "example:wordAttack:scriptContainer"
					}
				}];
				this.CGS.externalApi.activate( pathTeacher, "teacher.initMenu");
				this.CGS.externalApi.activate( pathScriptContainer, "scriptContainer.sectionConstraints",[this.CGS.model.record.id]);

			},

            /**
             * Consistency function : sections are sibling components of the script in the CGS repository,
             * and this component needs to mimic the call to get the previous interest area (for the "same as previous"
             * feature) used by script elements.
             * This function returns the interest area of the preceding script in form of
             * {interestList : UUID, interestItem : UUID }
             * If no interest area exists, or the values are not valid, then undefined is returned
             * @returns {Object|undefined} - the interest area object
             */
            getInterestArea : function(){

                var path = [{
                    action :"prev"
                }];
				var recordPath = [{
					action : "getRecordProperty",
					args 	: {
						name : "data.name"
					}
				}];

				var prevType = this.CGS.externalApi.activate( path.concat(recordPath));
				if( prevType == "section"){
					return this.CGS.externalApi.activate( path, "section.getInterestArea");
				} else {
					return this.CGS.externalApi.activate( path, "script.getInterestArea");
				}
            },

            isValid : function (){
            	return false;
            }
		});
			return sectionPlugin;
});


