define([], 
	function () {
		var wordSoundUtil = function(){
			this.replaceNbsp = /&(nbsp|amp|quot|lt|gt);/g;
			
			this.isWordSoundValid = function(word) {
				//Extract the words first, since there could be only commas in the string
				return this._extractWordSounds(word, true).length > 0 ? true : false;
			};
			
			this.extractWordSounds = function(word) {
				return this._extractWordSounds(word, true);
			};
			
			
			this._extractWordSounds = function(word, trim) {
				if(word.indexOf(",") >= 0) {
					var sounds = word.replace(this.replaceNbsp,'').split(',');
					var result = [];
					for(var i in sounds) {
						var sound = sounds[i];
						if(trim === true) {
							sound = sound.trim();
						}
						if(sound.length > 0) {
							result.push(sound);
						} 
					}
					return result;
				}  
				return [];
			};
			
			
			this.soundsSize = function(word) {
				return this._extractWordSounds(word, true).length;
			};
			
			this.concatAllSounds = function(word) {
				var sounds = this._extractWordSounds(word, false);
				var result = "";
				for(var i in sounds) {
					result += sounds[i];
				}
				return result;
			}
		};

	return new wordSoundUtil();
});