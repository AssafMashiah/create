//scriptContainer
define(['text!plugins/wordAttack/scriptContainer/templates/properties.html',
		'text!plugins/wordAttack/scriptContainer/templates/stage.html',
		'plugins/core/basePlugin/index'],
	function (propertiesTemplate, stageTemplate, BasePlugin) {
		var wordAttackScriptContainer = BasePlugin.extend({

		  	propertiesTemplate: propertiesTemplate,

         	stageTemplate: stageTemplate,

			onInitialize : function (details) {
				this.CGS.externalApi.register('scriptContainer.sectionConstraints',this.sectionConstraints);
				this.CGS.externalApi.register('scriptContainer.getSectionIndex',this.getSectionIndex);
				this.CGS.externalApi.register('scriptContainer.addScriptItem',this.addScriptItem);
				this.CGS.externalApi.register('scriptContainer.addSectionStartItem',this.addSectionStartItem);
				this.CGS.externalApi.register('scriptContainer.addSectionEndItem',this.addSectionEndItem);
				this.CGS.externalApi.register('scriptContainer.deleteAllChildren',this.deleteAllChildren);
			},

			onRenderComplete : function (cfg) {
                this.$content = cfg.$content;
                this.state = cfg.state;
				return this.state === 'edit' ?  this.$content.append(stageTemplate) : this.$content.append(stageTemplate);
			},

			onStartEdit : function () {
				this.sectionConstraints();
			},

			onChildDeleted : function(deletedItemId,index){
				this.CGS.externalApi.startTransaction({ appendToPrevious: true });
				var indexFocusFactor = 1;
				for(var i = 0;i<this.CGS.model.record.children.length ;i++)
				{
					var item  = this.CGS.model.getItem({id :this.CGS.model.record.children[i]});
					if(item.data.type == 'section' && item.data.referenceId == deletedItemId){
						this.CGS.model.deleteItem({id : item.id });
						indexFocusFactor++;
						break;
					}
				}
				this.CGS.externalApi.endTransaction();

				// focusedElementId represents which element will be focused
				var focusedElementId;
				if (index - indexFocusFactor >= 0)
				{
					focusedElementId = this.CGS.model.record.children[index - indexFocusFactor];
				}
				else
				{
					var path = [
						{
							action: "parent",
							args : {
								type : "example:wordAttack:element"
							}
						},
						{
							action: "getRecordProperty",
							args: {
								name: "id"
							}
						}
					];

					// "getRecordProperty" must be called inside path because it wasn't declared by us
					focusedElementId = this.CGS.externalApi.activate(path);
				}

				this.CGS.render();
				this.CGS.startEditing(focusedElementId);

			},

			onChildrenSorted : function(id){
				this.sectionConstraints(id);
			},

			onSubMenuOpen : function(){
				if(this.state == 'preview'){
					return;
				}
				var selectedEditorId = this.CGS.externalApi.getSelectedEditorId();
				//if(selectedEditorId && this.CGS.model.record.children.indexOf(selectedEditorId) > -1){
				this.sectionConstraints(selectedEditorId);
				//}

			},

			 /**
             * @param {string} childId
             * @param {ingeger} newIndex
             */
			onChildrenSorting : function (childId,newIndex){
				var sortedElement = this.CGS.model.getItem({id : childId});
				var sectionPairs = this.getSectionPairs();
				var valid = true;
				if(sortedElement.data.type =='section'){
					valid = this.draggingSectionConstraints(sortedElement,newIndex,sectionPairs);
				}
				return { cancel : !valid};
			},


			addScriptItem : function (type,menu_object){
                var hasInterestArea = false;
                var contentValid = true;
                if(type == 'practice' || type == 'additionalInfo'){
                    hasInterestArea = true;
                    contentValid = false;
                }
				var elementId = this.CGS.model.saveItem({
					"data" : {
						"type" : "plugin:example:wordAttack:script",
						"data" : {
							"displayStudentContent" : false,
							"type" : type,
                            "hasInterestArea" : hasInterestArea,
                            "contentValid" : contentValid,
                            "interestAreaRef" : "",
							"correctionScript" : 'default_correction_script',
							"markSound"        : true

						},
						children : [{
							"type" : "sys:textViewer",
							"data" : {
								"mode":"custom",
								"settings" : {"groups" : ["styles","effects","font","paragraph"]},
								"deletable" : false,
								"autoWidth" : true,
                                "showNarrationType" : false,
                                "width" : "100%"
							},
							"children" :[]
						}]
					}
				});
				this.CGS.render();
				this.CGS.startEditing(elementId)
			},

			addSectionStartItem : function (menu_object){
				var elementId = this.createSectionItem('start' );
				this.CGS.render();
				this.CGS.startEditing(elementId);
			},

			addSectionEndItem : function (menu_object){
				var sectionPairs = this.getSectionPairs();
				var sectionOpenIndex = _.findIndex(sectionPairs,{end : undefined});
				var startItemId = sectionPairs[sectionOpenIndex].start;
				this.CGS.externalApi.startTransaction();
				var elementId  = this.createSectionItem('end',startItemId);
				var path = [
                  {
                     action: "child",
                     args: {
                        type: "example:wordAttack:section",
                        index : sectionPairs[sectionOpenIndex].start_index
                     }
                  },
                  {
                     action: "setRecordProperty",
                     args: {
                        name: "data.referenceId",
                        value: elementId
                     }
                  }];

                  this.CGS.externalApi.activate(path);
                  this.CGS.externalApi.endTransaction();
				this.CGS.render();
				this.CGS.startEditing(elementId)
			},

			/**
			 * [ description]
			 * @param  {string} type the type of the section (start | end)
			 * @return {uuid} the created element id
			 */
			createSectionItem : function(section_type,referenceId){
				var index = this.getFocusedScriptIndex();

				if(index !== undefined ){
					if( section_type == "end" ){
						index++;
					}else if (section_type == 'start' ){
						//very rare case when the focus is on section end , we want the item to be palced below and not above
						if (this.CGS.model.getItem({id : this.CGS.model.record.children[index]}).data.section_type == 'end'){
							index++;
						}
					}
				}

				var data = {
							"data" : {
								"type" : "plugin:example:wordAttack:section",
								"insertAt" : index,
								"data" : {
									"type" : "section",
		                        	"oposite_section_ref" : null,
		                        	"section_type" : section_type,
		                        	"referenceId" : referenceId
		                        }

							}
						};

				var elementId = this.CGS.model.saveItem(data);


				return elementId
			},

			toggleSectionMenuState : function(activity){
				var state = {
					start 	: "enable",
					end 	: "disable"
 				};
 				if(activity == 'start'){
 					state.start	= 'disable',
 					state.end = 'enable'
 				}
				this.CGS.menu.setMenuItemState({
					id : 'menu-button-wordAttack-section-start',
					state : state.start
				});

				this.CGS.menu.setMenuItemState({
					id : 'menu-button-wordAttack-section-end',
					state : state.end
				})
			},

			disableBothSectionButtons : function() {
				this.CGS.menu.setMenuItemState({
					id : 'menu-button-wordAttack-section-start',
					state : 'disable'
				});

				this.CGS.menu.setMenuItemState({
					id : 'menu-button-wordAttack-section-end',
					state : 'disable'
				})
			},

			getSectionIndex : function(itemid){
				var sectionPairs = this.getSectionPairs();
				for(var i =0;i<sectionPairs.length ; i++){
					if(sectionPairs[i].start == itemid || sectionPairs[i].end == itemid){
						return i + 1;
					}
				}
				return;
			},

			/**
			 * [ description]
			 * @return {[number | undefined]} returns the index of the
			 * current focused element or undefined if none selected
			 */
			getFocusedScriptIndex : function () {
				var selectedEditorId = this.CGS.externalApi.getSelectedEditorId();
				if(!selectedEditorId){
					return;
				}

				var selectedEditorLocation =  this.CGS.model.record.children.indexOf(selectedEditorId);

				//in case the textviewer is selected
				if(selectedEditorLocation == -1){
					try{
						var parent = this.CGS.model.getItem({id : selectedEditorId}).parent;
						selectedEditorLocation = this.CGS.model.record.children.indexOf(parent);
					}catch(ex){
						//if the parent is not from type "Element" the getItem returns error
					}
				}

			 	if(selectedEditorLocation != -1) {
					return selectedEditorLocation
				}
				return;
			},

			getSectionPairs : function(){

				var children = this.CGS.model.record.children;
				var sectionPairs = [];
				_.each(children,function(child_id,index){
					var child = this.CGS.model.getItem({id : child_id});
					if(child.data.type != 'section'){
						return;
					}
					if(child.data.section_type == 'start'){
						sectionPairs.push({start:child.id,start_index : index });
					}else{
						if(sectionPairs[sectionPairs.length - 1]){
							sectionPairs[sectionPairs.length - 1].end = child_id;
							sectionPairs[sectionPairs.length - 1].end_index = index;
						}
					}
				},this);

				return sectionPairs;
			},

			sectionConstraints : function(id){
				var childrenLength = this.CGS.model.record.children.length;
				var elementIndex = id ? this.CGS.model.record.children.indexOf(id) :  childrenLength - 1;
				var sectionPairs = this.getSectionPairs();
				var result = this.checkSectionConstraints(elementIndex,childrenLength,sectionPairs);
				this.constraintsDisplay(result);
			},

			constraintsDisplay : function(result){
				var isIndividualType = this.CGS.model.record.data.type == "individual";
				if(result.end && !isIndividualType){
					this.toggleSectionMenuState('end');
				}
				else if(result.start && !isIndividualType){
					this.toggleSectionMenuState('start');
				}
				else{
					this.disableBothSectionButtons();
				}
			},

			/**
			 * check what menu item need to be disabled/enabled
			 * according to the position of the current focused element
			 *
			 * @param  {int} elementIndex [description]
			 * @param {int} childrenLength
			 * @param {array} sectionPairs
			 *
			 * @return {object} literal object with three options disabled.start | disabled.end | disabled.both
			 * one is true and the other are false
			 */
			checkSectionConstraints : function(elementIndex,childrenLength,sectionPairs) {
				var sectionOpenIndex = _.findIndex(sectionPairs,{end : undefined});
				var disabled =  { start : false, end : false,both : false }
				//there is no script items or sections
				if(!childrenLength){
					disabled.end = true;
					return disabled;
				}


				if(!sectionPairs){
					disabled.end = true;
					return disabled;
				}

				//there is no single section (start without end)
				if(sectionOpenIndex === -1){
					var flag = false;
					for(var i = 0 ;i< sectionPairs.length;i++)
					{

						//if he is inside section then disable both menu items
						if(elementIndex < sectionPairs[i].end_index && elementIndex > sectionPairs[i].start_index ){
							flag = true;
							disabled.both = true;
							return disabled;
						}
					}

					//the element is not inside any section
					if(!flag){
						disabled.end = true;
						return disabled;
					}
				}
				else {
					//if the focused element is the start item
					if(elementIndex === sectionPairs[sectionOpenIndex].start_index){
						disabled.start = true;
						return disabled;

					}

					//I am trying to locate the open section and the position of the focus input
					//if the element is before the open section both disabled because I need to close the start section
					//first
					if(elementIndex < sectionPairs[sectionOpenIndex].start_index){
						disabled.both =true;
						return disabled;

					}

					//the open section is last in the sections
					//the end section is required now
					if(sectionOpenIndex == sectionPairs.length -1 ){
						disabled.start = true;
						return disabled;
					}
					//there is closed section after the start secction we only let the user add section end
					//between the open section and the "start section tag" right after him
					else{
						var pairAfterOpendSection = sectionPairs[sectionOpenIndex + 1];
						if(pairAfterOpendSection.start_index > elementIndex && elementIndex > sectionPairs[sectionOpenIndex].start_index ) {
							disabled.start = true;
							return disabled;
						}
					}
				}
				disabled.both = true;
				return disabled;
			},

			/**
			 * checks if the dropping location is valid location (for section start and section end)
			 * @param  {[type]} element      the element we want to remove
			 * @param  {[type]} position     the dropped position
			 * @param  {[type]} sectionPairs sectionPairsList (it easy to test with this value as parameter)
			 * @return {boolean}   			  either the dropped location is valid or not
			 */
			draggingSectionConstraints : function (element,droppedPosition,sectionPairs) {

				var type = element.data.section_type;
				var	sectionPairItem = type == 'start' ?  _.find(sectionPairs,{ 'start':element.id}) : _.find(sectionPairs,{ 'end':element.id});
				var isSectionOpen = !(sectionPairItem.end || false);

				//if we are moving full section item (including start and end )
				//we only allow to move to a location between the section sorrounds you
				//  [index -1] < droppedPosition > [index +1]
				if(!isSectionOpen){
					var sectionsIndexes = [];

					_.each(sectionPairs,function(item){
							sectionsIndexes.push(item.start_index);
							if(item.end_index){
								sectionsIndexes.push(item.end_index);
							}
					});

					var elementIndex = sectionsIndexes.indexOf(sectionPairItem[type + "_index"]);

					if(elementIndex > 0 && sectionsIndexes[elementIndex -1] >= droppedPosition){
						return false;
					}

					if(elementIndex < sectionsIndexes.length && sectionsIndexes[elementIndex + 1] <= droppedPosition){
						return false;
					}

				}
				//if the element has no closing section item(only start)
				//we allow him to move him anywhere that not inside another section
				else{
					for(var i = 0;i < sectionPairs.length;i++){
						if(sectionPairs[i][type] != element.id ) {

							if(droppedPosition >= sectionPairs[i].start_index && droppedPosition <= sectionPairs[i].end_index){
									return false;
							}

						}
					}
				}
				return true;
			},

			deleteAllChildren : function(){
				this.CGS.externalApi.startTransaction({ appendToPrevious: true });
				this.CGS.model.record.children.forEach( function(id){
					this.CGS.model.deleteItem({id : id });
				}.bind(this));
				this.CGS.externalApi.endTransaction();
			}



		});

	return wordAttackScriptContainer;
});