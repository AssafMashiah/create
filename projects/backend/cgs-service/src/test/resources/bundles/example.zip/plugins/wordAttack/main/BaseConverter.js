define([], function () {
    var BaseConverter = function( data ){

        if( data ) this.init( data );

    };

    BaseConverter.prototype.init = function( data ){

        this.setOriginalData( data );

    };

    BaseConverter.prototype.setOriginalData = function( data ){

        this.originalData = data;

    };

    BaseConverter.prototype.getOriginalData = function(){

        return this.originalData;

    };

    BaseConverter.prototype.findEntryPoint = function(){

        if( !this.originalData ) return false;

        for( var i in this.originalData ){

            if( this.originalData[ i ].data &&
                this.originalData[ i ].data.path &&
                ~this.originalData[ i ].data.path.indexOf( "main" ) ){

                return i;

            }

        }

        return false;

    };

    BaseConverter.prototype.setConverter = function( converter ){

        return typeof converter.convert === "function" &&
            typeof converter.setBase === "function" &&
            ( this.converter = converter.setBase( this ) );

    };

    BaseConverter.prototype.convert = function(){

        var result = null;

        try{
            result = this.converter && this.converter.convert();
        }
        catch( e ){
            console.error( e );
        }

        return result;

    };

    /**
     * Removes the style attribute from a string representing an html div
     * @param data - string representing html element from CGS
     * @returns string - the input returned with the style attribute removed
     */
    BaseConverter.prototype.clearTextViewerStyle = function(data){
        var result = data;

        var dataAsHtml = $(data).removeAttr('style');
        if( dataAsHtml[0] ){
            result = dataAsHtml[0].outerHTML;
        }

        return result;

    };

    BaseConverter.prototype.getChildrenComponents = function( id ){

        if( !this.originalData ) return false;

        var types = {
            "textViewer" : "html" ,
            "imageViewer" : "image"
        };

        var format = {
            "textViewer" : true ,
            "imageViewer" : false
        };

        var result = [];

        this.originalData[ id ].children.forEach( function( item ){

            item = this.originalData[ item ];

            types[ item.type ] &&
            result.push( {
                id : item.id,
                type : types[ item.type ] ,
                data : {

                    "content" : format[ item.type ] ? encodeURIComponent( item.data.title ) : item.data.title,
                    // only add image data if the child component is an image
                    "imageData" : format[ item.type ] ? {} : {
                        src : item.data.image,
                        width : item.data.imgWidth,
                        height : item.data.imgHeight
                    }
                }
            } );

        }.bind( this ) );

        return result;

    };

    return BaseConverter;


});