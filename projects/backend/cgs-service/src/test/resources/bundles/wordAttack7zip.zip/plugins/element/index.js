define(['text!plugin_template_path/wordAttack/plugins/element/templates/properties.html',
		'text!plugin_template_path/wordAttack/plugins/element/templates/stage.html'],
	function (propertiesTemplate, stageTemplate) {
		var wordAttackElement = function() {
			
			this.onInitialize = function (details) {
			};
			
			this.onRenderComplete = function ($el, state) {
				this.$el = $el;
				this.$el.parent().addClass('plugin-content');
				var template = this.CGS.RenderTemplate.render(stageTemplate,_.merge({},{is_edit : state === 'edit'}));
					$el.append(template);
			};

			this.onPropertiesViewLoad = function ($el) {
				this.$props_el = $el;
				this.bindPropertiesEvents();
			};

			this.onStartEdit = function () {
			};

			this.onEndEdit = function () {
			};

			this.onDispose = function () {
				this.unbindPropertiesEvents();
				this.$props_el = null;
				this.$el = null;
			};

			this.getPropertiesView = function () {
				
				template =   this.CGS.RenderTemplate.render(propertiesTemplate,
						_.merge({},
						this.CGS.model.record.data)
					);
				return template;
			};

			this.bindPropertiesEvents = function(){
				
				this.$props_el.find('.main-title').on('change',function(e){
					var path = [
						{
							action : "parent",
							args : {
									type : "vocabulary:main"
								}
						},
						{
							action : "setRecordProperty",
							args 	: {
								name : "data.title",
								value : e.target.value
							}
						}];
					 this.CGS.externalApi.activate(path);		
				}.bind(this));
				
			};

			this.unbindPropertiesEvents = function (){
				if(!this.$props_el){
					return;
				}
			};
		} 

		return wordAttackElement;
	});