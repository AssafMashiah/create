define(['text!plugin_template_path/wordAttack/plugins/list/templates/properties.html',
		'text!plugin_template_path/wordAttack/plugins/list/templates/stage.html'],
	function (propertiesTemplate, stageTemplate) {
		var ListEditor = function() {
			
			this.onInitialize = function (details) {
				
			};
			
			this.onRenderComplete = function ($el, state) {
				//console.log('onRenderComplete');
				this.$el = $el;
				state === 'edit' ?  $el.append(stageTemplate) : $el.append(stageTemplate);
				//this.toggleEyesOnTheTeacherView(true);
			};

			this.onPropertiesViewLoad = function ($el) {
				this.$props_el  = $el;
				//console.log("onPropertiesViewLoad")
			}

			this.onStartEdit = function () {
				//console.log("onStartEdit")
			}

			this.onEndEdit = function () {
				//console.log("onEndEdit")
			}

			this.onDispose = function () {
				//console.log('onDispose');
				this.$el = null;
				this.$props_el = null;
			}

			

			this.getPropertiesView = function () {
				//console.log("getPropertiesView");
				return propertiesTemplate;
			}
		} 

		return ListEditor;
});