define(['js/plugins/vocabulary/plugins/main/BaseConverter.js', 
	'js/plugins/wordAttack/plugins/main/PluginConverter.js'], function (BaseConverter, VocabularyConverter) {
	return function (data) {
		console.log(data);

        var baseConverter = new BaseConverter(data);
        //var wordAttackConverter = new [BUNDLE_NAME_UPPERCASE]Converter(baseConverter);
        //return wordAttackConverter.convert();

	};
});