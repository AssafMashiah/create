define([], function () {
    var PluginConverter  = function( base ){

        if( base ) this.setBase( base );

    };

    PluginConverter.prototype.setBase = function( base ){

        if( base ) this.base = base;

        return this;

    };

    PluginConverter.prototype.convert = function(){

        if( !( this.base && typeof this.base.findEntryPoint === "function" ) ) return false;

        var result = {

            data_version : "" ,

            activity : {
                type : "wordAttack"
            } ,

            content : {
                teacher : this.buildTeacherContent() ,
                student : this.buildStudentContent()
            }

        };

        return result;

    };

    PluginConverter.prototype.buildTeacherContent = function(){
    };

    PluginConverter.prototype.buildStudentContent = function(){

    };

    return PluginConverter;


});