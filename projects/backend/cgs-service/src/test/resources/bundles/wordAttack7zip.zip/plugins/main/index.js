define(['text!plugin_template_path/wordAttack/plugins/main/templates/properties.html',
	'text!plugin_template_path/wordAttack/plugins/main/templates/stage.html'],
	function (propertiesTemplate, stageTemplate) {
	var ActivityWordAttack = function() {
		this.onInitialize = function (details) {
			//console.log("Activity wordAttack onInitialize");
			
			this.CGS.menu.loadMenu({
				'menuInitFocusId': 'menu-button-wordAttack-task',
				'label' : '((Activity))',
				'id':'menu-button-wordAttack-task',
				'type':'button',
				'icon':'',
				'canBeDisabled':false,
				subMenuItems:[]
			});
		
		};

		this.onRenderComplete = function ($el, state) {
			
		};

		this.onPropertiesViewLoad = function ($el) {
			var self = this;
			this.$props_el = $el;
			this.bindPropertiesEvents();
			
		};

		this.onStartEdit = function () {
			//console.log("Plugin Start Editing")
		};

		this.onEndEdit = function () {
			//console.log("Plugin End Editing")
			this.unbindPropertiesEvents();
		};

		this.onDispose = function () {
			this.$props_el = null;

		};

		this.getContentStageView = function () {
			//return stageTemplate;
		};

		this.getPropertiesView = function () {
			return propertiesTemplate;
		}
		
		this.bindPropertiesEvents = function (){
			if(!this.$props_el){
				return ;
			}
			this.$props_el.find('#field_title').on('change', function () {
				var rec = self.CGS.model.record;

				self.CGS.model.saveProp({
					propName: "title",
					value: $(this).val(),
					triggerChange: true
				});

			});
		}
		this.unbindPropertiesEvents = function (){
			if(!this.$props_el){
				return;
			}
			this.$props_el.find('#field_title').off('change');
		}
	} 

	return ActivityWordAttack;
});