define(['text!plugins/wordAttack/teacher/templates/properties.html',
		'text!plugins/wordAttack/teacher/templates/stage.html',
		'plugins/core/baseTeacher/index'],
	function (propertiesTemplate, stageTemplate, BaseTeacher) {
		var wordAttackTeacherEditor = BaseTeacher.extend({

            propertiesTemplate: propertiesTemplate,

            stageTemplate: stageTemplate,

			onInitialize : function (details) {
				if(  typeof this.getWordAttackElementData().activeScriptContainer === "undefined"){
					this.setActiveScriptContainer(0);
				}
				//console.log('onInitalize')
				this.registerEvents();

			},

			registerEvents : function(){
				this.CGS.externalApi.register('teacher.initMenu', this.initMenu);
				this.CGS.externalApi.register('teacher.showHideIndividual', this.showHideIndividual);
			},

			onRenderComplete : function (cfg) {
                this.$content = cfg.$content;
                this.state = cfg.state;
				var menu_height = 260 ,//document.querySelectorAll('.screen-header')[0].offsetHeight;
					height  = document.body.offsetHeight - menu_height;
				if(this.state === 'edit') {
                    this.$content.closest('.script-pane').css({
						'height' : height ,
						'min-height' : height
					});
				}
			 	var propertyData = this.getWordAttackElementData();
			 	var templateData = {"showIndividual" : propertyData.hasIndividualStage && !propertyData.isIndividualAutomatic,
			 						"readingIsActive" : propertyData.activeScriptContainer == 0}
				var template  = this.CGS.RenderTemplate.render(stageTemplate, templateData);
				this.state === 'edit' ?  this.$content.append(template) : this.$content.append(template);
				this.$content.find(".toggle-script-container").on('click',this.toggleSectionContainer.bind(this));
				return this.$content;
			},

			showHideIndividual : function(){
				var propertyData = this.getWordAttackElementData();
				var displayIndividual = propertyData.hasIndividualStage && !propertyData.isIndividualAutomatic;
				if(!displayIndividual){
						this.CGS.externalApi.activate( this.getScriptContainerPath(1), "scriptContainer.deleteAllChildren");
						this.setActiveScriptContainer(0);
				}
				this.CGS.render();
				this.CGS.startEditing(this.CGS.model.record.parent);

			},

			onStartEdit : function () {
				this.initMenu();
			},

			initMenu : function() {
				this.CGS.menu.loadMenu({
				'menuInitFocusId': 'menu-button-wordAttack-task',
				'label' : '((Word Attack))',
				'id':'menu-button-wordAttack-task',
				'type':'button',
				'icon':'',
				'canBeDisabled':false,
				subMenuItems:[
					{
						'id':'menu-button-wordAttack-task-group', // id in DOM
						'icon':'text-height',
						'type': 'btn-group-title',
						'label' : '((Script))',
						'canBeDisabled':true,
						'subMenuItems': [{
								'id':'menu-button-wordAttack-direction', // id in DOM
								'icon':'text-height',
								'label' : '((Direction))',
								'event': this.addScriptItem.bind(this,'direction'),
								'canBeDisabled':true,
								"subMenuItems" : []
							},{
								'id':'menu-button-wordAttack-practice', // id in DOM
								'icon':'text-height',
								'label' : '((Practice))',
								'event': this.addScriptItem.bind(this,'practice'),
								'canBeDisabled':true
							},{
								  'id':'menu-button-wordAttack-additionalInfo', // id in DOM
								  'icon':'text-height',
								  'label' : '((Additional Info))',
								  'event': this.addScriptItem.bind(this,'additionalInfo'),
								  'canBeDisabled':true,
								  "subMenuItems" : []
							 }
						]
					},
					{
						'id':'menu-button-wordAttack-section-group', // id in DOM
						'icon':'text-height',
						'type': 'btn-group-title',
						'label' : '((Script Section))',
						'canBeDisabled':true,
						'subMenuItems' : [
							{
								'id':'menu-button-wordAttack-section-start', // id in DOM
								'icon':'text-height',
								'label' : '((Section Start))',
								'event': this.addSectionStartItem.bind(this),
								'canBeDisabled':true
							},
							{
								'id':'menu-button-wordAttack-section-end', // id in DOM
								'icon':'text-height',
								'label' : '((Section End))',
								'event': this.addSectionEndItem.bind(this),
								'canBeDisabled':true
							}
						]
					}

					]
				});
			},

			toggleSectionContainer : function(e){
				var $target = $(e.target).closest(".toggle-script-container");
				var $activeScriptContainer = $target.closest(".script-container");
				if ( !$target.hasClass("active") ) {
					$(".toggle-script-container.active .menu-circle").removeClass("hidden");
					$(".toggle-script-container.active").removeClass("active");
					$(".script-container.active").removeClass("active");
					$activeScriptContainer.addClass("active");
					$target.addClass("active");
					$activeScriptContainer.find(".menu-circle").addClass("hidden");
					this.setActiveScriptContainer( Number($activeScriptContainer.attr("data-container-index")));
					this.CGS.externalApi.activate( this.getScriptContainerPath(), "scriptContainer.sectionConstraints");
				}


			},

			getScriptContainerPath : function(id){
				return [
                    {
                    action :"child",
                    args : {
                        	type : "example:wordAttack:scriptContainer",
                        	index : id || this.getWordAttackElementData().activeScriptContainer
                        }
                    }
                ];
			},

			getWordAttackElementData : function(){
				var path = [
				{
					action : "parent",
					args : {
							type : "example:wordAttack:element"
						}
				},
				{
					action : "getRecordProperty",
					args 	: {
						name : "data"
					}
				}];
				return this.CGS.externalApi.activate(path);
			},

			setActiveScriptContainer : function(value){

				var path = [
				{
					action : "parent",
					args : {
							type : "example:wordAttack:element"
						}
				},
				{
					action : "setRecordProperty",
					args 	: {
						name : "data.activeScriptContainer",
						value : value
					}
				}];
				this.CGS.externalApi.activate(path);
			},

			addScriptItem : function(type,menu_object){
				this.CGS.externalApi.activate( this.getScriptContainerPath(), "scriptContainer.addScriptItem",[type, menu_object]);
			},

			addSectionStartItem : function(menu_object){
				this.CGS.externalApi.activate( this.getScriptContainerPath(), "scriptContainer.addSectionStartItem",[menu_object]);
			},

			addSectionEndItem : function(menu_object){

				this.CGS.externalApi.activate( this.getScriptContainerPath(), "scriptContainer.addSectionEndItem",[menu_object]);

			}



		});

	return wordAttackTeacherEditor;
});