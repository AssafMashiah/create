define([], function (BaseConverter, VocabularyConverter) {
	return function (data) {
		console.log(data);
		return {};

	};
});