define(['plugins/core/basePlugin/index'],

   function (BasePlugin) {
      var BaseStudent = BasePlugin.extend({
         //onStartEdit: function () {
         //   //console.log("onStartEdit")
         //},
         //onEndEdit: function () {
         //   //console.log("onEndEdit")
         //},
         getPropertiesView: function () {
            //console.log("getPropertiesView");
            return this.propertiesTemplate;
         }

      });

      return BaseStudent;
   });