define([], function () {
    var WordAttackConverter = function (base) {

        if (base) this.setBase(base);

    };

    var createUUID = function () {
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
        return uuid;
    };

    var calculatePositionAspercent = function (position, imageSize) {
        var calculatedPosition = {};
        if (imageSize && position) {
            calculatedPosition.top = String((position.top / imageSize.height) * 100) + "%";
            calculatedPosition.left = String((position.left / imageSize.width) * 100) + "%";
        }
        return calculatedPosition;

    }

    WordAttackConverter.prototype.setBase = function (base) {

        if (base) this.base = base;

        return this;

    };

    WordAttackConverter.prototype.convert = function () {
        var mainId = 0;
        var data = {};
        var activityData = {};

        if (this.base) {
            mainId = this.base.findEntryPoint();
            data = this.base.getOriginalData();

            activityData = data[data[mainId].children[0]].data;//main : element object
        }

        if (!( this.base && typeof this.base.findEntryPoint === "function" )) return false;

        var result = {

            data_version: "",

            activity: {
                type: "wordAttack",
                hasSummaryStage: activityData.hasSummaryStage,
                hasIndividualStage: activityData.hasIndividualStage,
                isIndividualAutomatic: activityData.isIndividualAutomatic,
                defaultSummaryScript: activityData.defaultSummaryScript,
                defaultIndividualScript: activityData.defaultIndividualScript
            },

            content: {
                teacher: {},
                student: {},
                assets: {}
            }

        };
        result.content.student = this.buildStudentContent(result.content.assets);
        result.content.teacher = this.buildTeacherContent(result.content.assets);

        return result;

    };

    /**
     * Builds the teacher content from script data, and adds image objects for each script into the asset
     * object of the returned conversion.
     * @param assetsRef - reference to the returned assets object
     * @returns {*}
     */
    WordAttackConverter.prototype.buildTeacherContent = function (assetsRef) {

        if (!this.base) return false;

        var mainId = this.base.findEntryPoint();
        var data = this.base.getOriginalData();
        var result = {};

        if (data[mainId].children && data[mainId].children.length != 1) {

            throw "Original data is corrupted: 'main' (ID: " + mainId + ") must have one child only. ";

        }

        var element = data[data[mainId].children[0]];

        var convertedCorrectionList = {};

        // get correction list data
        Object.keys(element.data.correctionDataList).forEach(function (key) {
            var correction = element.data.correctionDataList[key];

            if (typeof(correction) === "object") {
                var value = "";
                if (correction.modalId) {
                    var container = data[correction.modalId];
                    if (container.children[0]) {
                        value = '<div>' + data[container.children[0]].data.title + '</div>';
                        $(value).prop('style', '');
                    }
                }

                convertedCorrectionList[correction.id] =
                {
                    id: correction.id,
                    type: "html",
                    data: {
                        content: encodeURIComponent(value)
                    }
                };

                convertedCorrectionList["defaultIndividual"] = {
                    id: "defaultIndividual",
                    type: "html",
                    data: {
                        content: encodeURIComponent(element.data.defaultIndividualScript)
                    }
                }

                convertedCorrectionList["defaultSummary"] = {
                    id: "defaultSummaryScript",
                    type: "html",
                    data: {
                        content: encodeURIComponent(element.data.defaultSummaryScript)
                    }
                }
            }

        });
        result = {
            scripts: {},
            scriptsMapping: [],
            individualScriptsMapping: [],
            correctionList: convertedCorrectionList
        };

        var teacher = null;

        // get all teacher elements
        element.children.forEach(function (item) {

            if (teacher) return;
            if (data[item].data.path && ~data[item].data.path.indexOf(":teacher")) {
                teacher = data[item];
            }

        });

        if (!teacher) throw "'teacher' element not found.";

        var scripts = [];
        var sectionParent = sectionStatus = undefined;
        teacher.children.forEach(function (container) {

            var forIndividual = data[container].data.type == "individual";

            data[container].children.forEach(function (item) {

                if (data[item].data.type == 'section') {
                    if (data[item].data.section_type == 'start') {
                        sectionStatus = 'start';
                    } else {
                        sectionParent = undefined;
                        sectionStatus = 'end';
                    }
                }
                if (data[item].data.path && ~data[item].data.path.indexOf(":script")) {
                    if (sectionStatus == 'start') {
                        sectionParent = data[item].id;
                        sectionStatus = 'in_progress';
                    }

                    //scripts.push( data[ item ] ); //TODO: remove
                    // reference to model inner record data
                    var recordData = data[item].data;
                    if (!forIndividual) {

                        result.scriptsMapping.push(data[item].id);
                    }
                    else {

                        result.individualScriptsMapping.push(data[item].id);
                    }

                    result.scripts[data[item].id] = {

                        id: data[item].id,
                        type: recordData.type,
                        hasInterestArea: recordData.hasInterestArea,
                        interestAreaRef: recordData.interestAreaRef,
                        interestArea: recordData.interestItem,
                        interestSoundIndex: recordData.interestSoundIndex,
                        isManualSound: recordData.interestSoundIndex === "Manual",
                        contentValid: recordData.contentValid,
                        hasImage: recordData.hasImage,
                        sectionParent: sectionParent,
                        markSound: recordData.markSound,
                        forIndividual: forIndividual,
                        studentContent: [],
                        data: {
                            base: {},
                            extra: {}
                        },
                        content_components: [],
                        correction_ref: {"id": data[item].data.correctionScript || "default_correction_script"},
                        assetRef: {
                            infoImage: 0
                        }
                    };
                    if(data[item].data.assets &&  data[item].data.assets.backgroundImage){
                        var uuid = createUUID();
                        result.scripts[data[item].id].assetRef.infoImage = uuid;
                        assetsRef[uuid] = {
                            id: uuid,
                            type: "image",
                            data: {
                                "src": data[item].data.assets.backgroundImage,
                            }
                        };
                    }


                    var childrenComponents = this.base.getChildrenComponents(data[item].id);
                    // add images as image refs, and other items (text) as content_components
                    for (var comp in childrenComponents) {
                        result.scripts[data[item].id].content_components.push(childrenComponents[comp]);
                    }
                }

            }.bind(this))
        }.bind(this));

        return result;
    };

    WordAttackConverter.prototype.buildStudentContent = function (assetsRef) {
        if (!this.base) return false;

        var mainId = this.base.findEntryPoint();
        var data = this.base.getOriginalData();

        if (data[mainId].children && data[mainId].children.length != 1) {

            throw "Original data is corrupted: 'main' (ID: " + mainId + ") must have one child only. ";

        }

        var element = data[data[mainId].children[0]];

        var result = {
            content: {
                components: {
                    wordsList: {
                        columnsMapping: [],
                        columns: {},
                        words: {},
                        horizontalLists: []

                    }
                }
            }
        };

        var wordsList = result.content.components.wordsList;

        var student = null;

        element.children.forEach(function (item) {

            if (student) return;
            if (data[item].data.path && ~data[item].data.path.indexOf(":student")) {
                student = data[item];
            }

        });

        student.children.forEach(function (item) {
            var assetRef = {};
            // find all lists, but not listItems
            if (data[item].data.path && ~data[item].data.path.indexOf(":list") && data[item].data.path.indexOf(":listItem")) {

                // map lists for indexing
                wordsList.columnsMapping.push(data[item].id);

                // add horizontally oriented lists to horizontalLists array
                if (data[item].data.orientation == 'horizontal' || data[item].data.orientation == 'manual') {
                    wordsList.horizontalLists.push(data[item].id);
                }


                if (data[item].data.assets && data[item].data.assets.backgroundImage) {
                    var uuid = createUUID();
                    var imageSize = data[item].data.imageSize;
                    assetRef.backgroundImage = uuid;
                    assetsRef[uuid] = {
                        "type": "image",
                        "data": {
                            "src": data[item].data.assets.backgroundImage,
                            "imgWidth": imageSize ? imageSize.width : imageSize,
                            "imgHeight": imageSize ? imageSize.height : imageSize
                        }
                    };
                }


                // add list as column
                var itemData = {
                    id: data[item].id,
                    backgroundSize: data[item].data.backgroundSize,
                    orientation: data[item].data.orientation,
                    type: data[item].data.listType,
                    children: data[item].children,
                    item_numbering: data[item].data.item_numbering,
                    soundInWord: data[item].data.soundInWord
                };

                if (!$.isEmptyObject(assetRef)) {
                    itemData.assetRef = assetRef;
                }

                wordsList.columns[data[item].id] = itemData;

                // scan through words in column and add them to data
                data[item].children.forEach(function (word) {
                    if (data[word].data.path && ~data[word].data.path.indexOf(":listItem")) {

                        var itemElement = data[data[word].children[0]];
                        var itemType = "html";
                        var itemContent = encodeURIComponent(this.base.clearTextViewerStyle(itemElement.data.title));

                        if (itemElement.type == "imageViewer") {
                            itemType = "image";
                            itemContent = itemElement.data.image;
                        }

                        // find all listItems and add them as words in data
                        wordsList.words[data[word].id] = {
                            id: data[word].id,
                            type: itemType,
                            position: calculatePositionAspercent(data[word].data.position, data[item].data.backgroundSize),
                            data: {
                                // get title of child text viewer
                                content: itemContent
                            },
                            parent: data[word].parent
                        }
                    }
                }.bind(this));

            }

        }.bind(this));


        return result;

    };

    return WordAttackConverter;


});