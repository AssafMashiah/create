define(['plugins/core/main/growing-list','plugins/core/basePlugin/index'],

   function (GrowingList, BasePlugin) {

      var BaseElement = BasePlugin.extend({
         type: "",
         stageTemplate:"<div>STAGE TEMPLATE IS NOT IMPLEMENTED YET</div>",
         propertiesTemplate:"<div>PROPERTIES TEMPLATE IS NOT IMPLEMENTED YET</div>",

         onInitialize: function () {
            this.loadCorrectionList();
         },
         loadCorrectionList: function () {
            if (!this.correction) {
               this.correction = Object.create(GrowingList, {list: {value: {}, writable: true}});
               var list_length = 0;

               if (this.CGS.model.record.data.correctionDataList) {
                  list_length = this.CGS.model.record.data.correctionDataList.length + 1;
               }
               this.correction.init(this.CGS, this.CGS.model.record.data.correctionDataList, this.isReadOnly, this.correctionDataChange.bind(this), list_length);
            }
         },
         onRenderComplete: function (config) {
            this.$content = config.$content;
            this.isReadOnly = config.readOnly;
			var parent = this.$content.parent();

            parent.addClass('plugin-content');
			 parent.parent().css("overflow-y","hidden"); // remove CGS scrolling
            var template = this.CGS.RenderTemplate.render(this.stageTemplate, _.merge({}, {
               is_edit: config.state === 'edit'
            }));
            config.$content.append(template);
         },
         onPropertiesViewLoad: function (el) {
            this.$props_el = el;
            this.loadCorrectionList();
            if (this.$props_el) {
               this.$props_el.find('.correction-wrapper').append(this.correction.render());
               this.correction.bindEvents();
            }
            this.bindPropertiesEvents();
         },
         onStartEdit: function () {
            var path = [{
               action: "child",
               args: {
                  type: "example:" +this.type + ":teacher",
                  index: 0
               }
            }];
            this.CGS.externalApi.activate(path, "teacher.initMenu");
         },

         onEndEdit: function () {
         },

         getPropertiesView: function () {

            // update title from main and if has summary stage and individual turns stage
            var path = [{
                 action: "parent",
                 args: {
                    type: this.type + ":main"
                 }
              },{
                 action: "getRecordProperty",
                 args: {
                    name: "data.title"
                 }
              }];

            var main_title = this.CGS.externalApi.activate(path);
            var template = this.CGS.RenderTemplate.render(this.propertiesTemplate,
                     _.merge({
                         "main_title": main_title,
                         "isIndividualAutomatic": this.CGS.model.record.data.individualStageMode == "automatic"
                     },
                     this.CGS.model.record.data)
            );

            return template;
         },
         bindPropertiesEvents: function () {
            // bind title changes to properties
            this.$props_el.find('.main-title').on('change', function (e) {
               var path = [
                  {
                     action: "parent",
                     args: {
                        type: this.type + ":main"
                     }
                  },
                  {
                     action: "setRecordProperty",
                     args: {
                        name: "data.title",
                        value: e.target.value
                     }
                  }];
               this.CGS.externalApi.activate(path);
            }.bind(this));
         },
         correctionDataChange: function (type, id) {
            switch (type) {
                case "new" :
                    this.CGS.externalApi.startTransaction({ appendToPrevious: true });
                    break;
                case "append" :
                    this.CGS.externalApi.startTransaction();
                    break;
               case "create" :
                  this.CGS.model.saveProp({"propName": 'correctionDataList', "value": this.correction.getData()});
                  this.CGS.externalApi.endTransaction();
                  break;
               case "delete" :

                  try {
                     this.CGS.externalApi.startTransaction();
                     this.CGS.model.saveProp({"propName": 'correctionDataList', "value": this.correction.getData()});
                     this.CGS.events.fire(this.CGS.model.record.data.path.split(':')[0] + '_script_deleteCorrectionScriptElement', id);
                     this.CGS.externalApi.endTransaction();
                  } catch (e) {
                      this.CGS.externalApi.endTransaction();
                  }
                  break;
            }
         },
         onDispose: function () {
            this.unbindPropertiesEvents();
            this.$props_el = null;
            if (this.correction) {
               this.correction.unbindEvents();
            }
         },
         unbindPropertiesEvents: function () {
            if (!this.$props_el) {
               return;
            }
            this.$props_el.find('.main-title').off('change');
         }

      });

      return BaseElement;
   });