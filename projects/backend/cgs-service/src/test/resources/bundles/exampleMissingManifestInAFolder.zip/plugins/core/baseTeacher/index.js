define(['plugins/core/basePlugin/index'],

   function (BasePlugin) {

      var BaseTeacher = BasePlugin.extend({

         onInitialize: function () {
            console.log('onInitalize BaseTeacher');
         },
         onRenderComplete: function () {
            console.log("onRenderComplete BaseTeacher");
         },
         onPropertiesViewLoad: function (el) {
            //console.log("onPropertiesViewLoad")
         },
         onStartEdit: function () {
            console.log("onStartEdit BaseTeacher")
         },
         onEndEdit: function () {
            console.log("onEndEdit BaseTeacher")
         },
         onDispose: function () {
            console.log('onDispose BaseTeacher');
         },
         getContentStageView: function () {
            console.log("getContentStageView");
         },
         getPropertiesView: function () {
            //console.log("getPropertiesView");
         }
      });

      return BaseTeacher;
   });