define([], function () { 
	return function (data) {
		console.log(data);
        return [];
	};
});