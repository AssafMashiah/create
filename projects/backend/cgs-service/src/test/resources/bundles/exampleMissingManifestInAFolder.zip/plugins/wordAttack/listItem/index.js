//listItem
define(['text!plugins/wordAttack/listItem/templates/properties.html',
		'text!plugins/wordAttack/listItem/templates/stage.html',
		'plugins/wordAttack/main/js/wordSoundUtil'],
	function (propertiesTemplate, stageTemplate, wordSoundUtil) {
		var listItemEditor = function() {

			this.onInitialize = function (details) {
				this.CGS.externalApi.register('listItem.enableNumbering', this.enableNumbering);
				this.CGS.externalApi.register('listItem.validateChildField', this.validateChildField);
			};

			this.onRenderComplete = function (cfg) {
				//console.log('onRenderComplete');
                this.readOnly = cfg.readOnly;
				this.$content = cfg.$content;
                var wrapper = this.$content.closest('.element_preview_wrapper');
                wrapper.addClass('list-item-wrapper');
                var templateView = this.CGS.RenderTemplate.render(stageTemplate,
                    _.merge({},
                        this.getViewModel(),
                        {"isEdit" : cfg.state === 'edit'}
                    )
                );
                cfg.$content.addClass("list-item");
                cfg.state === 'edit' ?  cfg.$content.append(templateView) : cfg.$content.append(templateView);



                if(this.getListType() == 'letter') {
                	var itemType = this.CGS.model.getItem({id: this.CGS.model.record.children[0]}).type;


                	var targetClass = "";
                	var iconClass= "";
                	if(itemType == "textViewer") {
                		//Text viewer switch image
                		targetClass = "list-item-letter-change";
                		iconClass = "di_icon-ChangeToImage";
                	} else {
                		//Image viewer switch image
                		targetClass = "list-item-image-change";
                		iconClass = "di_icon-ChangeToText";
                	}

                	wrapper.append(
            				$("<div>").addClass("list-item-letter-toggle").addClass(targetClass).append($("<span>").addClass(iconClass))
            		);

                	this.bindEvents();
                }
			};


            this.bindEvents = function(){
                this.$content.parent().on('click',".list-item-letter-change", this.onChangeItemLetterToImage.bind(this));
                this.$content.parent().on('click',".list-item-image-change", this.onChangeItemImageToLetter.bind(this));
            };

            this.unbindEvents = function(){
                this.$content.off('click',".list-item-letter-change");
                this.$content.off('click',".list-item-image-change");
            };

            this.onChangeItemLetterToImage = function() {
                var path = this.getParentPath();
                this.CGS.externalApi.activate( path, "list.toggleLetterType",[this.CGS.model.record.id, "imageViewer"]);
            }

            this.onChangeItemImageToLetter = function() {
                var path = this.getParentPath();
                this.CGS.externalApi.activate( path, "list.toggleLetterType",[this.CGS.model.record.id], "textViewer");
            }

			this.onPropertiesViewLoad = function ($el) {
				this.$props_el  = $el;
				//console.log("onPropertiesViewLoad")
			};

			this.onStartEdit = function () {
				//console.log("onStartEdit")
                // begin editing text editor child - unless in read only mode
                if( !this.readOnly ) {
                    var listItemId = this.CGS.model.record.children[0];
                    this.CGS.startEditing(listItemId);
                }
			};

			this.onEndEdit = function () {
				//console.log("onEndEdit")
			};

			this.onDispose = function () {
				//console.log('onDispose');
				this.unbindEvents();
				this.$content = null;
				this.$props_el = null;
			};

            this.getParentPath = function() {
                var path = [{
                    action :"parent",
                    args : {
                        type : "example:wordAttack:list"
                    }
                }];
                return path;
            };

            this.getListItemIndex = function(){
                var path = this.getParentPath();

                var index = this.CGS.externalApi.activate( path, "list.getListItemIndex",[this.CGS.model.record.id]);
                return index.toString();
            };



            this.isItemNumbering = function() {
                var path = [
                            {
                            action :"parent",
                            args : {
                                type : "example:wordAttack:list"
                                }
                            },
                            {
                            action : "getRecordProperty",
                            args 	: {
                                name : "data.item_numbering",
                            }
                        }];
                        return this.CGS.externalApi.activate(path);
            };


            this.getListType = function() {

                var path = [
                            {
                            action :"parent",
                            args : {
                                type : "example:wordAttack:list"
                                }
                            },
                            {
                            action : "getRecordProperty",
                            args 	: {
                                name : "data.listType",
                            }
                        }];
                        return this.CGS.externalApi.activate(path);

            }

            // Registering for mustache rendering
            this.getViewModel = function (){

                return _.merge({},
                    this.CGS.model.record,
                    //mustache function calls
                    {
                        'getListItemIndex' : this.getListItemIndex(),
                        'isItemNumbering'  : this.isItemNumbering()
                    });
            };


			this.getPropertiesView = function () {
				//console.log("getPropertiesView");
				return propertiesTemplate;
			};

			this.enableNumbering = function(enable) {
				$(".list-item-numbering", this.$content).toggleClass("dimmed", !enable);
			};

			this.validateChildField = function() {
				var elementItem = this.CGS.model.getItem({id: this.CGS.model.record.children[0]});
				this.CGS.validation.setValidation(this.validateChild(elementItem.id));
			}


			/**
			 *
			 * sound in word handling events from inner plugin (textEditor)
			 * 1) make sure to override validation and show invalid icon when sound in words are marked and there are no comma separator
			 * 2) on edit start, register sounds length inside of word
			 * 3) on edit stop, check if sounds length changed, id changed clead interest area from script
			 *
			 *
			 */

            this.isListSoundInWords = function() {
                var path = this.getParentPath();
                return this.CGS.externalApi.activate( path, "list.isSoundInWords",[]);
            }

			this.onChildStartEditing = function(childId){
				var lastItemContent = $(this.CGS.model.getItem({'id':childId}).data.title).text();

				if(this.isListSoundInWords()) {
					this.lastSoundsSize = wordSoundUtil.soundsSize(lastItemContent);
				}
            };

            this.onChildEndEditing = function(childId){

                this.CGS.validation.setValidation(this.validateChild(childId));

                this.CGS.externalApi.startTransaction({ appendToPrevious: true });

                if(this.isListSoundInWords()) {
                    var currentItemContent = $(this.CGS.model.getItem({'id':childId}).data.title).text();
                    var soundsSize = wordSoundUtil.soundsSize(currentItemContent);
                    if(soundsSize != this.lastSoundsSize && this.lastSoundsSize) {
                        // fire list item deleted event
                    	this.lastSoundsSize = undefined;
                        try {
                            this.CGS.events.fire('wordAttack_script_soundInWordsChanged', this.CGS.model.record.id);
                        } catch (e){
                            //do nothing
                        }
                    }
                }

                this.CGS.externalApi.endTransaction();

            };

            this.validateChild = function(childId){

                var TVEChild = this.CGS.model.getItem({'id':childId}),
                validationResponse ={
                    'id' : childId,
                    'valid': true,
                    'validationMessage': [],
                    'overrideDefaultValidation':false
                };

                var content = $(TVEChild.data.title).text();
            	if(this.isListSoundInWords() && content.trim().length > 0) {
                    if(TVEChild.data.title.indexOf(',') < 0 ){
                        validationResponse.valid = false;
                        validationResponse.validationMessage.push("There are no commas in the text object.<BR>Separate each individual sound or sound combination in the word with a comma.");
                        validationResponse.overrideDefaultValidation = true;
                    }
            	}

                return validationResponse;
            };

		};

		return listItemEditor;
});