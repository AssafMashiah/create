//////////////////////////////////////////////////////////////////////////
// navigation - start
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task = {} ;
LanguageUtil.strings.task.progress = {} ;
LanguageUtil.strings.task.progress.labels = {} ;
LanguageUtil.strings.task.progress.labels.check = "Check";
LanguageUtil.strings.task.progress.labels.tryagain = "Try Again";
LanguageUtil.strings.task.progress.labels.showanswer = "Show Answer";
LanguageUtil.strings.task.progress.labels.progress = "Continue";
LanguageUtil.strings.task.progress.labels.done = "Done";
LanguageUtil.strings.task.progress.labels.solvetask = "Solve Task";
LanguageUtil.strings.task.progress.labels.myanswer = "My Answer";
LanguageUtil.strings.task.progress.labels.progress_last_in_sequence = 'Send Results';
//////////////////////////////////////////////////////////////////////////
// navigation - assessment
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task.progress.labels.assessment_next = "Next";
LanguageUtil.strings.task.progress.labels.assessment_done = "Submit";
LanguageUtil.strings.task.progress.labels.assessment_show_correct = "Correct Answer";
//////////////////////////////////////////////////////////////////////////
// navigation - end
//////////////////////////////////////////////////////////////////////////

// task buttons
LanguageUtil.strings.tasktoolbar.feedback = "Feedback";
LanguageUtil.strings.tasktoolbar.hint = "Hint";
LanguageUtil.strings.tasktoolbar.attempts="Attempts";
LanguageUtil.strings.tasktoolbar.points="Points";
LanguageUtil.strings.tasktoolbar.instructions="Instructions";
// text area
LanguageUtil.strings.textarea.tooltips.bold = "Bold";
LanguageUtil.strings.textarea.tooltips.italic = "Italic";
LanguageUtil.strings.textarea.tooltips.underline = "Underline";
LanguageUtil.strings.textarea.tooltips.copy = "Copy";
LanguageUtil.strings.textarea.tooltips.cut = "Cut";
LanguageUtil.strings.textarea.tooltips.paste = "Paste";
LanguageUtil.strings.textarea.tooltips.undo = "Undo";
LanguageUtil.strings.textarea.tooltips.redo = "Redo";
LanguageUtil.strings.textarea.tooltips.lists = "Lists";
LanguageUtil.strings.textarea.tooltips.aligns = "Align Text";
LanguageUtil.strings.textarea.tooltips.indents = "Indent Text";
LanguageUtil.strings.textarea.tooltips.squareList = "Square Bullets";
LanguageUtil.strings.textarea.tooltips.discList = "Round Bullets";
LanguageUtil.strings.textarea.tooltips.numberList = "Numbered List";
LanguageUtil.strings.textarea.tooltips.justifyLeft = "Align Left";
LanguageUtil.strings.textarea.tooltips.justifyCenter = "Align Center";
LanguageUtil.strings.textarea.tooltips.justifyRight = "Align Right";
LanguageUtil.strings.textarea.tooltips.indent = "Increase Indent";
LanguageUtil.strings.textarea.tooltips.outdent = "Decrease Indent";
LanguageUtil.strings.textarea.tooltips.dirs = "Text Direction";
LanguageUtil.strings.textarea.tooltips.dirRightToLeft = "Right-to-Left Text Direction";
LanguageUtil.strings.textarea.tooltips.dirLeftToRight = "Left-to-Right Text Direction";
LanguageUtil.strings.textarea.tooltips.fontSize = "Font Size";

// Media Player
LanguageUtil.strings.mediaPlayer.tooltips.play = "Play";
LanguageUtil.strings.mediaPlayer.tooltips.pause = "Pause";
LanguageUtil.strings.mediaPlayer.tooltips.stop = "Stop";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreen = "Full Screen";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreenExit = "Exit Full Screen";
LanguageUtil.strings.mediaPlayer.messages.fullscreenExit = "Press Esc to exit Full Screen mode.";
LanguageUtil.strings.externalMediaPlayer.messages.fullscreenExit = "Tap Done to exit Full Screen mode.";

//Interactions
LanguageUtil.strings.interactions = {};
LanguageUtil.strings.interactions.downloadIcon = "Tap the icon to download";

