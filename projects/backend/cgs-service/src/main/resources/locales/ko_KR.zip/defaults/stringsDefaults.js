//////////////////////////////////////////////////////////////////////////
// navigation - start
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task = {} ;
LanguageUtil.strings.task.progress = {} ;
LanguageUtil.strings.task.progress.labels = {} ;
LanguageUtil.strings.task.progress.labels.check = "확인";
LanguageUtil.strings.task.progress.labels.tryagain = "다시 시도";
LanguageUtil.strings.task.progress.labels.showanswer = "답변 보기";
LanguageUtil.strings.task.progress.labels.progress = "계속";
LanguageUtil.strings.task.progress.labels.done = "완료";
LanguageUtil.strings.task.progress.labels.solvetask = "과제 해결";
LanguageUtil.strings.task.progress.labels.myanswer = "나의 정답";
LanguageUtil.strings.task.progress.labels.progress_last_in_sequence = '결과 보내기';
//////////////////////////////////////////////////////////////////////////
// navigation - assessment
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task.progress.labels.assessment_next = "다음";
LanguageUtil.strings.task.progress.labels.assessment_done = "제출";
LanguageUtil.strings.task.progress.labels.assessment_show_correct = "정답";
//////////////////////////////////////////////////////////////////////////
// navigation - end
//////////////////////////////////////////////////////////////////////////

// task buttons
LanguageUtil.strings.tasktoolbar.feedback = "피드백";
LanguageUtil.strings.tasktoolbar.hint = "힌트";
LanguageUtil.strings.tasktoolbar.attempts="시도";
LanguageUtil.strings.tasktoolbar.points="점수";
LanguageUtil.strings.tasktoolbar.instructions="교습";
// text area
LanguageUtil.strings.textarea.tooltips.bold = "굵게";
LanguageUtil.strings.textarea.tooltips.italic = "이탤릭";
LanguageUtil.strings.textarea.tooltips.underline = "밑줄";
LanguageUtil.strings.textarea.tooltips.copy = "복사";
LanguageUtil.strings.textarea.tooltips.cut = "자르기";
LanguageUtil.strings.textarea.tooltips.paste = "붙여넣기";
LanguageUtil.strings.textarea.tooltips.undo = "실행 취소";
LanguageUtil.strings.textarea.tooltips.redo = "재실행";
LanguageUtil.strings.textarea.tooltips.lists = "리스트";
LanguageUtil.strings.textarea.tooltips.aligns = "문장 정렬";
LanguageUtil.strings.textarea.tooltips.indents = "문장 들여 쓰기";
LanguageUtil.strings.textarea.tooltips.squareList = "사각형 글머리표 목록";
LanguageUtil.strings.textarea.tooltips.discList = "라운드 글 머리 기호 목록";
LanguageUtil.strings.textarea.tooltips.numberList = "번호가 매겨진 목록";
LanguageUtil.strings.textarea.tooltips.justifyLeft = "왼쪽 정렬";
LanguageUtil.strings.textarea.tooltips.justifyCenter = "가운데 정렬";
LanguageUtil.strings.textarea.tooltips.justifyRight = "오른쪽 정렬";
LanguageUtil.strings.textarea.tooltips.indent = "들여 쓰기 증가";
LanguageUtil.strings.textarea.tooltips.outdent = "들여 쓰기 감소";
LanguageUtil.strings.textarea.tooltips.dirs = "문장 방향";
LanguageUtil.strings.textarea.tooltips.dirRightToLeft = "오른쪽에서 왼쪽으로 문장 방향";
LanguageUtil.strings.textarea.tooltips.dirLeftToRight = "왼쪽에서 오른쪽으로 문장 방향";
LanguageUtil.strings.textarea.tooltips.fontSize = "서체 크기";

// Media Player
LanguageUtil.strings.mediaPlayer.tooltips.play = "재생";
LanguageUtil.strings.mediaPlayer.tooltips.pause = "일시 정지";
LanguageUtil.strings.mediaPlayer.tooltips.stop = "정지";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreen = "전체 화면";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreenExit = "전체 화면 종료";
LanguageUtil.strings.mediaPlayer.messages.fullscreenExit = "Esc 키를 눌러 전체 화면 모드를 종료합니다.";
LanguageUtil.strings.externalMediaPlayer.messages.fullscreenExit = "완료 키를 눌러 전체 화면 모드를 종료합니다.";

//Interactions
LanguageUtil.strings.interactions = {};
LanguageUtil.strings.interactions.downloadIcon = "다운로드 아이콘을 누릅니다";

