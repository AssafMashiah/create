//////////////////////////////////////////////////////////////////////////
// navigation - start
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task = {} ;
LanguageUtil.strings.task.progress = {} ;
LanguageUtil.strings.task.progress.labels = {} ;
LanguageUtil.strings.task.progress.labels.check = "Controleer antwoord";
LanguageUtil.strings.task.progress.labels.tryagain = "Probeer Opnieuw";
LanguageUtil.strings.task.progress.labels.showanswer = "Toon antwoord";
LanguageUtil.strings.task.progress.labels.progress = "Ga verder";
LanguageUtil.strings.task.progress.labels.done = "Klaar";
LanguageUtil.strings.task.progress.labels.solvetask = "Toon oplossing";
LanguageUtil.strings.task.progress.labels.myanswer = "Mijn antwoord";
LanguageUtil.strings.task.progress.labels.progress_last_in_sequence = 'Resultaten verzenden';
//////////////////////////////////////////////////////////////////////////
// navigation - assessment
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task.progress.labels.assessment_next = "Volgende";
LanguageUtil.strings.task.progress.labels.assessment_done = "Lever in";
LanguageUtil.strings.task.progress.labels.assessment_show_correct = "Juist antwoord";
//////////////////////////////////////////////////////////////////////////
// navigation - end
//////////////////////////////////////////////////////////////////////////

// task buttons
LanguageUtil.strings.tasktoolbar.feedback = "Feedback";
LanguageUtil.strings.tasktoolbar.hint = "Hint";
LanguageUtil.strings.tasktoolbar.attempts="Pogingen";
LanguageUtil.strings.tasktoolbar.points="Punten";
// text area
LanguageUtil.strings.textarea.tooltips.bold = "Vet";
LanguageUtil.strings.textarea.tooltips.italic = "Schuin";
LanguageUtil.strings.textarea.tooltips.underline = "Onderstreept";
LanguageUtil.strings.textarea.tooltips.copy = "Kopieer";
LanguageUtil.strings.textarea.tooltips.cut = "Knip";
LanguageUtil.strings.textarea.tooltips.paste = "Plak";
LanguageUtil.strings.textarea.tooltips.undo = "Maak ongedaan";
LanguageUtil.strings.textarea.tooltips.redo = "Opnieuw";
LanguageUtil.strings.textarea.tooltips.lists = "Opsomming";
LanguageUtil.strings.textarea.tooltips.aligns = "Lijn uit";
LanguageUtil.strings.textarea.tooltips.indents = "Spring in";
LanguageUtil.strings.textarea.tooltips.squareList = "Vierkante opsommingstekens";
LanguageUtil.strings.textarea.tooltips.discList = "Ronde opsommingstekens";
LanguageUtil.strings.textarea.tooltips.numberList = "Nummering";
LanguageUtil.strings.textarea.tooltips.justifyLeft = "Lijn links uit";
LanguageUtil.strings.textarea.tooltips.justifyCenter = "Lijn in het midden uit";
LanguageUtil.strings.textarea.tooltips.justifyRight = "Lijn recht uit";
LanguageUtil.strings.textarea.tooltips.indent = "Spring in";
LanguageUtil.strings.textarea.tooltips.outdent = "Spring terug";
LanguageUtil.strings.textarea.tooltips.dirs = "Tekstrichting";
LanguageUtil.strings.textarea.tooltips.dirRightToLeft = "Tekstrichting van rechts naar links";
LanguageUtil.strings.textarea.tooltips.dirLeftToRight = "Tekstrichting van links naar rechts";
LanguageUtil.strings.textarea.tooltips.fontSize = "Lettergrootte";

// Media Player
LanguageUtil.strings.mediaPlayer.tooltips.play = "Speel af";
LanguageUtil.strings.mediaPlayer.tooltips.pause = "Pauze";
LanguageUtil.strings.mediaPlayer.tooltips.stop = "Stop";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreen = "Volledig scherm";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreenExit = "Sluit volledig scherm af";
LanguageUtil.strings.mediaPlayer.messages.fullscreenExit = "Druk op Esc om het volledige scherm af te sluiten";
LanguageUtil.strings.externalMediaPlayer.messages.fullscreenExit = "Klik op 'Klaar' om het scherm te verlaten";
