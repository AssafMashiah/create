﻿//////////////////////////////////////////////////////////////////////////
// navigation - start
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task = {} ;
LanguageUtil.strings.task.progress = {} ;
LanguageUtil.strings.task.progress.labels = {} ;
LanguageUtil.strings.task.progress.labels.check = "Marcar";
LanguageUtil.strings.task.progress.labels.tryagain = "Tentar novamente";
LanguageUtil.strings.task.progress.labels.showanswer = "Mostrar Resposta";
LanguageUtil.strings.task.progress.labels.progress = "Continuar";
LanguageUtil.strings.task.progress.labels.done = "Concluído";
LanguageUtil.strings.task.progress.labels.solvetask = "Resolver Tarefa";
LanguageUtil.strings.task.progress.labels.myanswer = "Minha Resposta";
LanguageUtil.strings.task.progress.labels.progress_last_in_sequence = 'Enviar resultados';
//////////////////////////////////////////////////////////////////////////
// navigation - assessment
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task.progress.labels.assessment_next = "Avançar";
LanguageUtil.strings.task.progress.labels.assessment_done = "Enviar";
LanguageUtil.strings.task.progress.labels.assessment_show_correct = "Resposta Correta";
//////////////////////////////////////////////////////////////////////////
// navigation - end
//////////////////////////////////////////////////////////////////////////

// task buttons
LanguageUtil.strings.tasktoolbar.feedback = "Feedback";
LanguageUtil.strings.tasktoolbar.hint = "Dicas";
LanguageUtil.strings.tasktoolbar.attempts="Tentativas";
LanguageUtil.strings.tasktoolbar.points="Pontos";
// text area
LanguageUtil.strings.textarea.tooltips.bold = "Negrito";
LanguageUtil.strings.textarea.tooltips.italic = "Itálico";
LanguageUtil.strings.textarea.tooltips.underline = "Sublinhado";
LanguageUtil.strings.textarea.tooltips.copy = "Copiar";
LanguageUtil.strings.textarea.tooltips.cut = "Cortar";
LanguageUtil.strings.textarea.tooltips.paste = "Colar";
LanguageUtil.strings.textarea.tooltips.undo = "Desfazer";
LanguageUtil.strings.textarea.tooltips.redo = "Refazer";
LanguageUtil.strings.textarea.tooltips.lists = "Listas";
LanguageUtil.strings.textarea.tooltips.aligns = "Alinhar Texto";
LanguageUtil.strings.textarea.tooltips.indents = "Recuar Texto";
LanguageUtil.strings.textarea.tooltips.squareList = "Marcadores Quadrados";
LanguageUtil.strings.textarea.tooltips.discList = "Marcadores Redondos";
LanguageUtil.strings.textarea.tooltips.numberList = "Lista Numerada";
LanguageUtil.strings.textarea.tooltips.justifyLeft = "Alinhar à Esquerda";
LanguageUtil.strings.textarea.tooltips.justifyCenter = "Centralizar";
LanguageUtil.strings.textarea.tooltips.justifyRight = "Alinhar à Direita";
LanguageUtil.strings.textarea.tooltips.indent = "Aumentar Recuo";
LanguageUtil.strings.textarea.tooltips.outdent = "Decrease Indent";
LanguageUtil.strings.textarea.tooltips.dirs = "Direção do Texto";
LanguageUtil.strings.textarea.tooltips.dirRightToLeft = "Direção do Texto Direita para Esquerda";
LanguageUtil.strings.textarea.tooltips.dirLeftToRight = "Direção do Texto Esquerda para Direita";
LanguageUtil.strings.textarea.tooltips.fontSize = "Tamanho da Fonte";

// Media Player
LanguageUtil.strings.mediaPlayer.tooltips.play = "Reproduzir";
LanguageUtil.strings.mediaPlayer.tooltips.pause = "Pausar";
LanguageUtil.strings.mediaPlayer.tooltips.stop = "Parar";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreen = "Tela cheia";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreenExit = "Sair do modo tela cheia";
LanguageUtil.strings.mediaPlayer.messages.fullscreenExit = "Pressione Esc para sair do modo tela cheia.";
LanguageUtil.strings.externalMediaPlayer.messages.fullscreenExit = "Toque em Concluído para sair do modo tela cheia.";

