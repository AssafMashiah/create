//////////////////////////////////////////////////////////////////////////
// navigation - start
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task = {} ;
LanguageUtil.strings.task.progress = {} ;
LanguageUtil.strings.task.progress.labels = {} ;
LanguageUtil.strings.task.progress.labels.check = "檢查";
LanguageUtil.strings.task.progress.labels.tryagain = "再试一次";
LanguageUtil.strings.task.progress.labels.showanswer = "显示答案";
LanguageUtil.strings.task.progress.labels.progress = "继续";
LanguageUtil.strings.task.progress.labels.done = "做";
LanguageUtil.strings.task.progress.labels.solvetask = "解决任务";
LanguageUtil.strings.task.progress.labels.myanswer = "我的答案";
LanguageUtil.strings.task.progress.labels.progress_last_in_sequence = "发送结果";
//////////////////////////////////////////////////////////////////////////
// navigation - assessment
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task.progress.labels.assessment_next = "下一个";
LanguageUtil.strings.task.progress.labels.assessment_done = "提交";
LanguageUtil.strings.task.progress.labels.assessment_show_correct = "正确答案";
//////////////////////////////////////////////////////////////////////////
// navigation - end
//////////////////////////////////////////////////////////////////////////

// task buttons
LanguageUtil.strings.tasktoolbar.feedback = "意見";
LanguageUtil.strings.tasktoolbar.hint = "提示";
LanguageUtil.strings.tasktoolbar.attempts="尝试";
LanguageUtil.strings.tasktoolbar.points="分數";
LanguageUtil.strings.tasktoolbar.instructions="說明";
// text area
LanguageUtil.strings.textarea.tooltips.bold = "粗體";
LanguageUtil.strings.textarea.tooltips.italic = "斜體";
LanguageUtil.strings.textarea.tooltips.underline = "下劃線";
LanguageUtil.strings.textarea.tooltips.copy = "複製";
LanguageUtil.strings.textarea.tooltips.cut = "剪下";
LanguageUtil.strings.textarea.tooltips.paste = "貼上";
LanguageUtil.strings.textarea.tooltips.undo = "復原";
LanguageUtil.strings.textarea.tooltips.redo = "取消復原";
LanguageUtil.strings.textarea.tooltips.lists = "列表";
LanguageUtil.strings.textarea.tooltips.aligns = "文本对齐";
LanguageUtil.strings.textarea.tooltips.indents = "文本缩进";
LanguageUtil.strings.textarea.tooltips.squareList = "開始方形項目符號清單";
LanguageUtil.strings.textarea.tooltips.discList = "開始圓形項目符號清單";
LanguageUtil.strings.textarea.tooltips.numberList = "開始編號清單";
LanguageUtil.strings.textarea.tooltips.justifyLeft = "左對齊";
LanguageUtil.strings.textarea.tooltips.justifyCenter = "居中對齊";
LanguageUtil.strings.textarea.tooltips.justifyRight = "右對齊";
LanguageUtil.strings.textarea.tooltips.indent = "增加縮進";
LanguageUtil.strings.textarea.tooltips.outdent = "減少縮進";
LanguageUtil.strings.textarea.tooltips.dirs = "文字方向";
LanguageUtil.strings.textarea.tooltips.dirRightToLeft = "設定文字的方向為從右至左顯示";
LanguageUtil.strings.textarea.tooltips.dirLeftToRight = "設定文字的方向為從左至右顯示";
LanguageUtil.strings.textarea.tooltips.fontSize = "字型大小";

// Media Player
LanguageUtil.strings.mediaPlayer.tooltips.play = "播放";
LanguageUtil.strings.mediaPlayer.tooltips.pause = "暂停";
LanguageUtil.strings.mediaPlayer.tooltips.stop = "停止";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreen = "全螢幕";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreenExit = "退出全螢幕模式";
LanguageUtil.strings.mediaPlayer.messages.fullscreenExit = "按 Esc 以退出全屏模式";
LanguageUtil.strings.externalMediaPlayer.messages.fullscreenExit = "点击完成以退出全屏模式";

//Interactions
LanguageUtil.strings.interactions = {};
LanguageUtil.strings.interactions.downloadIcon = "点击图标以下载";

