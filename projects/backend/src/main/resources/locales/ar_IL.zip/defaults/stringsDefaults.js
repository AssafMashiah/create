﻿//////////////////////////////////////////////////////////////////////////
//config
//////////////////////////////////////////////////////////////////////////
LanguageUtil.config.direction = 'rtl';

//////////////////////////////////////////////////////////////////////////
//navigation - start
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task = {};
LanguageUtil.strings.task.progress = {};
LanguageUtil.strings.task.progress.labels = {};
LanguageUtil.strings.task.progress.labels.check = "التحقق";
LanguageUtil.strings.task.progress.labels.tryagain = "إعادة المحاولة";
LanguageUtil.strings.task.progress.labels.showanswer = "إظهار الإجابة";
LanguageUtil.strings.task.progress.labels.progress = "الاستمرار";
LanguageUtil.strings.task.progress.labels.done = "إنهاء";
LanguageUtil.strings.task.progress.labels.solvetask = "إظهار النتيجة";
LanguageUtil.strings.task.progress.labels.myanswer = "إجابتي";
LanguageUtil.strings.task.progress.labels.progress_last_in_sequence = 'إرسال نتائج';
//////////////////////////////////////////////////////////////////////////
//navigation - assessment
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task.progress.labels.assessment_next = "التالي";
LanguageUtil.strings.task.progress.labels.assessment_done = "إرسال";
LanguageUtil.strings.task.progress.labels.assessment_show_correct = "الإجابة الصحيحة";
//////////////////////////////////////////////////////////////////////////
// navigation - end
//////////////////////////////////////////////////////////////////////////

// task buttons
LanguageUtil.strings.tasktoolbar.feedback = "التعليق";
LanguageUtil.strings.tasktoolbar.hint = "تلميح";
LanguageUtil.strings.tasktoolbar.attempts="محاولات";
LanguageUtil.strings.tasktoolbar.points="نقاط";
// text area
LanguageUtil.strings.textarea.tooltips.bold = "سميك";
LanguageUtil.strings.textarea.tooltips.italic = "مائل";
LanguageUtil.strings.textarea.tooltips.underline = "وضع خط بالأسفل";
LanguageUtil.strings.textarea.tooltips.copy = "نسخ";
LanguageUtil.strings.textarea.tooltips.cut = "قص";
LanguageUtil.strings.textarea.tooltips.paste = "لصق";
LanguageUtil.strings.textarea.tooltips.undo = "التراجع";
LanguageUtil.strings.textarea.tooltips.redo = "استعادة";
LanguageUtil.strings.textarea.tooltips.lists = "القوائم";
LanguageUtil.strings.textarea.tooltips.aligns = "محاذاة النص";
LanguageUtil.strings.textarea.tooltips.indents = "المسافات البادئة";
LanguageUtil.strings.textarea.tooltips.squareList = "نقطة مربعة";
LanguageUtil.strings.textarea.tooltips.discList = "نقطة دائرية";
LanguageUtil.strings.textarea.tooltips.numberList = "قائمة مرقمة";
LanguageUtil.strings.textarea.tooltips.justifyLeft = "محاذاة إلى اليسار";
LanguageUtil.strings.textarea.tooltips.justifyCenter = "محاذاة إلى الوسط";
LanguageUtil.strings.textarea.tooltips.justifyRight = "محاذاة إلى اليمين";
LanguageUtil.strings.textarea.tooltips.indent = "مسافة بادئة للداخل";
LanguageUtil.strings.textarea.tooltips.outdent = "مسافة بادئة للخارج";
LanguageUtil.strings.textarea.tooltips.dirs = "اتجاه الكتابة";
LanguageUtil.strings.textarea.tooltips.dirRightToLeft = "اتجاه الكتابة من اليمين لليسار";
LanguageUtil.strings.textarea.tooltips.dirLeftToRight = "اتجاه الكتابة من اليسار لليمين";
LanguageUtil.strings.textarea.tooltips.fontSize = "حجم الخط";

// Media Player
LanguageUtil.strings.mediaPlayer.tooltips.play = "تشغيل";
LanguageUtil.strings.mediaPlayer.tooltips.pause = "انتظار";
LanguageUtil.strings.mediaPlayer.tooltips.stop = "إيقاف";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreen = "كامل الشاشة";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreenExit = "الخروج من وضع كامل الشاشة";
LanguageUtil.strings.mediaPlayer.messages.fullscreenExit = "للخروج من كامل الشاشة اضغط \"Esc\"";
LanguageUtil.strings.externalMediaPlayer.messages.fullscreenExit ="للخروج من وضع كامل الشاشة اضغط \"Esc\"";
