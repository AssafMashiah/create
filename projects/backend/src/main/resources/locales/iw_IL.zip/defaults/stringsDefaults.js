﻿//////////////////////////////////////////////////////////////////////////
//config
//////////////////////////////////////////////////////////////////////////
LanguageUtil.config.direction = 'rtl';

//////////////////////////////////////////////////////////////////////////
//navigation - start
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task = {};
LanguageUtil.strings.task.progress = {};
LanguageUtil.strings.task.progress.labels = {};
LanguageUtil.strings.task.progress.labels.check = "בדיקה";
LanguageUtil.strings.task.progress.labels.tryagain = "ניסיון חוזר";
LanguageUtil.strings.task.progress.labels.showanswer = "הצגת תשובה";
LanguageUtil.strings.task.progress.labels.progress = "המשך";
LanguageUtil.strings.task.progress.labels.done = "סיים";
LanguageUtil.strings.task.progress.labels.solvetask = "הצג פתרון";
LanguageUtil.strings.task.progress.labels.myanswer = "התשובה שלי";
LanguageUtil.strings.task.progress.labels.progress_last_in_sequence = 'המשך';
//////////////////////////////////////////////////////////////////////////
//navigation - assessment
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task.progress.labels.assessment_next = "הבא";
LanguageUtil.strings.task.progress.labels.assessment_done = "שלח";
LanguageUtil.strings.task.progress.labels.assessment_show_correct = "תשובה נכונה";
//////////////////////////////////////////////////////////////////////////
// navigation - end
//////////////////////////////////////////////////////////////////////////

// task buttons
LanguageUtil.strings.tasktoolbar.feedback = "משוב";
LanguageUtil.strings.tasktoolbar.hint = "רמז";
LanguageUtil.strings.tasktoolbar.attempts="ניסיונות";
LanguageUtil.strings.tasktoolbar.points="נקודות";
// text area
LanguageUtil.strings.textarea.tooltips.bold = "הדגשה";
LanguageUtil.strings.textarea.tooltips.italic = "נטוי";
LanguageUtil.strings.textarea.tooltips.underline = "קו תחתון";
LanguageUtil.strings.textarea.tooltips.copy = "העתק";
LanguageUtil.strings.textarea.tooltips.cut = "גזירה";
LanguageUtil.strings.textarea.tooltips.paste = "הדבקה";
LanguageUtil.strings.textarea.tooltips.undo = "ביטול";
LanguageUtil.strings.textarea.tooltips.redo = "שיחזור";
LanguageUtil.strings.textarea.tooltips.lists = "רשימות";
LanguageUtil.strings.textarea.tooltips.aligns = "יישור טקסט";
LanguageUtil.strings.textarea.tooltips.indents = "הזחות";
LanguageUtil.strings.textarea.tooltips.squareList = "תבליטים - ריבוע";
LanguageUtil.strings.textarea.tooltips.discList = "תבליטים - עיגול";
LanguageUtil.strings.textarea.tooltips.numberList = "רשימה ממוספרת";
LanguageUtil.strings.textarea.tooltips.justifyLeft = "יישור לשמאל";
LanguageUtil.strings.textarea.tooltips.justifyCenter = "יישור למרכז";
LanguageUtil.strings.textarea.tooltips.justifyRight = "יישור לימין";
LanguageUtil.strings.textarea.tooltips.indent = "הזחה פנימה";
LanguageUtil.strings.textarea.tooltips.outdent = "הזחה החוצה";
LanguageUtil.strings.textarea.tooltips.dirs = "כיוון כתיבה";
LanguageUtil.strings.textarea.tooltips.dirRightToLeft = "כתיבה מימין לשמאל";
LanguageUtil.strings.textarea.tooltips.dirLeftToRight = "כתיבה משמאל לימין";
LanguageUtil.strings.textarea.tooltips.fontSize = "גודל גופן";

// Media Player
LanguageUtil.strings.mediaPlayer.tooltips.play = "נגן";
LanguageUtil.strings.mediaPlayer.tooltips.pause = "הפסק";
LanguageUtil.strings.mediaPlayer.tooltips.stop = "עצור";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreen = "מסך מלא";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreenExit = "יציאה ממסך מלא";
LanguageUtil.strings.mediaPlayer.messages.fullscreenExit = "Esc -כדי לצאת ממסך מלא לחצו על";
LanguageUtil.strings.externalMediaPlayer.messages.fullscreenExit ="כדי לצאת ממצב מסך מלא לחצו על סיום";
