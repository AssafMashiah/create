﻿//////////////////////////////////////////////////////////////////////////
//navigation - start
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task = {};
LanguageUtil.strings.task.progress = {};
LanguageUtil.strings.task.progress.labels = {};
LanguageUtil.strings.task.progress.labels.check = "Valider";
LanguageUtil.strings.task.progress.labels.tryagain = "Réessayer";
LanguageUtil.strings.task.progress.labels.showanswer = "Corriger";
LanguageUtil.strings.task.progress.labels.progress = "Continuer";
LanguageUtil.strings.task.progress.labels.done = "Terminé";
LanguageUtil.strings.task.progress.labels.skiptask = "Passer";
LanguageUtil.strings.task.progress.labels.solvetask = "Montrer la correction";
LanguageUtil.strings.task.progress.labels.restarttask = "Recommencer";
LanguageUtil.strings.task.progress.labels.myanswer = "Ma Réponse";
LanguageUtil.strings.task.progress.labels.progress_last_in_sequence = 'Terminer';
//////////////////////////////////////////////////////////////////////////
//navigation - assessment
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.task.progress.labels.assessment_next = "Suivant";
LanguageUtil.strings.task.progress.labels.assessment_done = "Valider";
LanguageUtil.strings.task.progress.labels.assessment_show_correct = "Réponse correcte";
//////////////////////////////////////////////////////////////////////////
//navigation bar
//////////////////////////////////////////////////////////////////////////
LanguageUtil.strings.progressbar.tasks = "Tâches:";
LanguageUtil.strings.progressbar.of = "de";
LanguageUtil.strings.progressbar.next = "next";
LanguageUtil.strings.progressbar.prev = "prev";
//////////////////////////////////////////////////////////////////////////
//navigation - end
//////////////////////////////////////////////////////////////////////////

//task buttons
LanguageUtil.strings.tasktoolbar.feedback = "Commentaires";
LanguageUtil.strings.tasktoolbar.hint = "Indice";
LanguageUtil.strings.tasktoolbar.attempts="Tentatives";
LanguageUtil.strings.tasktoolbar.points="Points:";
//text area
LanguageUtil.strings.textarea.tooltips.bold = "Gras";
LanguageUtil.strings.textarea.tooltips.italic = "Italique";
LanguageUtil.strings.textarea.tooltips.underline = "Souligner";
LanguageUtil.strings.textarea.tooltips.copy = "Copier";
LanguageUtil.strings.textarea.tooltips.cut = "Couper";
LanguageUtil.strings.textarea.tooltips.paste = "Coller";
LanguageUtil.strings.textarea.tooltips.undo = "Annuler";
LanguageUtil.strings.textarea.tooltips.redo = "Refaire";
LanguageUtil.strings.textarea.tooltips.lists = "Listes";
LanguageUtil.strings.textarea.tooltips.aligns = "Alignement";
LanguageUtil.strings.textarea.tooltips.indents = "Retraits";
LanguageUtil.strings.textarea.tooltips.squareList = "Puces carrées";
LanguageUtil.strings.textarea.tooltips.discList = "Puces rondes";
LanguageUtil.strings.textarea.tooltips.numberList = "Numérotation";
LanguageUtil.strings.textarea.tooltips.justifyLeft = "Justifier à gauche";
LanguageUtil.strings.textarea.tooltips.justifyCenter = "Centrer";
LanguageUtil.strings.textarea.tooltips.justifyRight = "Justifier à droite";
LanguageUtil.strings.textarea.tooltips.indent = "Augmenter le retrait";
LanguageUtil.strings.textarea.tooltips.outdent = "Diminuer le retrait";
LanguageUtil.strings.textarea.tooltips.dirs = "Orientation";
LanguageUtil.strings.textarea.tooltips.dirRightToLeft = "De droite à gauche";
LanguageUtil.strings.textarea.tooltips.dirLeftToRight = "De gauche à droite";
LanguageUtil.strings.textarea.tooltips.fontSize = "Taille de police";

//Media Player
LanguageUtil.strings.mediaPlayer.tooltips.play = "Lecture";
LanguageUtil.strings.mediaPlayer.tooltips.pause = "Pause";
LanguageUtil.strings.mediaPlayer.tooltips.stop = "Arrêt";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreen = "Plein écran";
LanguageUtil.strings.mediaPlayer.tooltips.fullscreenExit = "Quitter le mode plein écran";
LanguageUtil.strings.mediaPlayer.messages.fullscreenExit = "Appuyez sur Echap pour quitter le mode plein écran";
LanguageUtil.strings.externalMediaPlayer.messages.fullscreenExit = "Tapez 'Terminer' pour refermer le mode plein écran.";

//Interactions
LanguageUtil.strings.interactions = {};
LanguageUtil.strings.interactions.downloadIcon = "Cliquez ici pour télécharger le fichier";

