define(['text!plugins/vocabulary/plugins/main/templates/properties.html', 
	'text!plugins/vocabulary/plugins/main/templates/stage.html'], 
	function (propertiesTemplate, stageTemplate) {
	var ActivityVocabulary = function() {
		this.onInitialize = function (details) {
			//console.log("Activity Vocabulary onInitialize");
			
			this.CGS.menu.loadMenu({
				'menuInitFocusId': 'menu-button-vocabulary-task',
				'label' : '((Activity))',
				'id':'menu-button-vocabulary-task',
				'type':'button',
				'icon':'',
				'canBeDisabled':false,
				subMenuItems:[]
			});
		
		};

		this.onRenderComplete = function ($el, state) {
			
		};

		this.onPropertiesViewLoad = function ($el) {
			var self = this;
			this.$props_el = $el;
			this.$props_el.find('#field_title').on('change', function () {
				var rec = self.CGS.model.record;

				self.CGS.model.saveProp({
					propName: "title",
					value: $(this).val(),
					triggerChange: true
				});

			})
		};

		this.onStartEdit = function () {
			//console.log("Plugin Start Editing")
		};

		this.onEndEdit = function () {
			//console.log("Plugin End Editing")
		};

		this.onDispose = function () {
			//this.propsEl.find('#field_title').off('change');
			this.$props_el = null;

		};

		this.getContentStageView = function () {
			//return stageTemplate;
		};

		this.getPropertiesView = function () {
			return propertiesTemplate;
		}

	} 

	return ActivityVocabulary;
});