define(['text!plugins/vocabulary/plugins/script/templates/properties.html?v=1', 
		'text!plugins/vocabulary/plugins/script/templates/stage.html'], 
	function (propertiesTemplate, stageTemplate) {
		var VocabularyScriptElement = function() {
			
			this.onInitialize = function (details) {
				//console.log("VocabularyElement onInitialize");
				if(this.isPractice()){
					this.CGS.events.register('deleteCorrectionScriptElement',this.deleteCorrectionScriptElement,this);
				}
			};
			
			this.onRenderComplete = function ($el, state) {
				//console.log("VocabularyElement onRenderComplete");
				this.$el = $el;
				this.$el.closest('.element_preview_wrapper').addClass('plugin-script');
				var templateView = this.CGS.RenderTemplate.render(stageTemplate,
					_.merge({},
						this.getViewModel(),
						{"isEdit" : state === 'edit'}
					)
					);
				
				state === 'edit' ?  $el.append(templateView) : $el.append(templateView);
				this.bindEvents();
			};

			this.onPropertiesViewLoad = function ($props_el) {
				this.$props_el = $props_el;
				this.bindPropsEvents();
			};

			this.isPractice = function () {
				return this.CGS.model.record.data.type == 'practice';
			};

			this.getCorrectionScriptList = function (){
				var path = [
						{
							action : "parent",
							args : {
									type : "vocabulary:teacher"
								}
						},
						{
							action : "parent",
							args : {
									type : "vocabulary:element"
								}
						},
						{
							action : "getRecordProperty",
							args 	: {
								name : "data.correctionDataList"
							}
						}];
			 	var result = this.CGS.externalApi.activate(path);	
			 	result = _.map(result,function(item){
						return {
							name : item.name ,
							id : item.id ,
							selected : item.id == this.CGS.model.record.data.correctionScript 
						};
					},this);
			 	return result;
			};

			this.onStartEdit = function () {
				var path = [{
					action :"parent",	
					args : {
						type : "vocabulary:teacher"
					}
				}];
				this.CGS.externalApi.activate( path, "teacher.initMenu"); 
				this.displayStudentContent(this.CGS.model.record.data.displayStudentContent);
			};

			this.onEndEdit = function () {
				this.disposePropsEvents();
				//this.disposeEvents();
			};

			this.onDispose = function () {
				//console.log('VocabularyElement onDispose');
				this.disposeEvents();
				this.disposePropsEvents();
				this.CGS.events.unregister('deleteCorrectionScriptElement');
			};

			this.bindEvents = function (){
				this.$el.on('change','.ribbon select',this.changeScriptType.bind(this));
			};

			this.bindPropsEvents = function(){
				if(!this.$props_el){
					return;
				}
				this.$props_el.on('change.prop','input[type=text],select,input[type=checkbox]',function(e){
					this.propertyItemChange(e);
				}.bind(this));
			};

			this.disposeEvents = function(){
				this.$el.off('change','.ribbon select',this.changeScriptType.bind(this));
			};

			this.disposePropsEvents = function(){
				if(!this.$props_el){
					return;
				}
				this.$props_el.off('change.prop');
			};

			this.getContentStageView = function () {
				return stageTemplate;
			};

			this.getPropertiesView = function () {
				//return propertiesTemplate;
				var template = this.CGS.RenderTemplate.render(propertiesTemplate,
					this.getViewModel()
					);
				return template;
			};

			this.changeScriptType = function (e) {
				this.CGS.model.saveProp({"propName" : "type","value": $(e.target).val() })
				this.CGS.startEditing(this.CGS.model.record.id);
			};

			this.getViewModel = function (){
				var list = {};
				if(this.isPractice()) {
					list = this.getCorrectionScriptList();
				}
				return _.merge({},
						this.CGS.model.record,
						{
							'isPractice' : this.isPractice(),
							'list'	: list
						});
			};

			this.propertyItemChange = function(e) {
				
				var name = e.target.dataset['recordValue'],
					value = e.target.type == 'checkbox' ? e.target.checked : e.target.value ;
				this.CGS.model.saveProp({"propName" : name ,"value": value });
				if(name == 'displayStudentContent'){
					this.displayStudentContent(value);	
					this.CGS.render();		
				}
			};

			this.displayStudentContent = function (value){
				var path = [{
					action : 'parent',
					args : {type:"vocabulary:teacher"}
				},{
					action 	: 'next',
					args 	: {type : 'vocabulary:student'}	
				}];
				this.CGS.externalApi.activate(path,'student.DisplayStudentContent',[value]);	
			};

			this.deleteCorrectionScriptElement = function(id){
				if (this.CGS.model.record.data.correctionScript == id){
					this.CGS.model.record.data.correctionScript  = 'default';
				}
			}
		} 

		return VocabularyScriptElement;
});