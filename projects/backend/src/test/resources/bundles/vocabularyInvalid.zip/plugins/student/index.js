define(['text!plugins/vocabulary/plugins/student/templates/properties.html', 
		'text!plugins/vocabulary/plugins/student/templates/stage.html'], 
	function (propertiesTemplate, stageTemplate) {
		var vocabularyStudentEditor = function() {
			
			this.onInitialize = function (details) {
				//console.log('onInitalize')
				this.CGS.externalApi.register('student.DisplayStudentContent',this.toggleEyesOnTheTeacherView.bind(this))
			};
			
			this.onRenderComplete = function ($el, state) {
				//console.log('onRenderComplete');
				this.$el = $el;
				state === 'edit' ?  $el.append(stageTemplate) : $el.append(stageTemplate);
				//this.toggleEyesOnTheTeacherView(true);
			};

			this.onPropertiesViewLoad = function ($el) {
				//console.log("onPropertiesViewLoad")
			}

			this.onStartEdit = function () {
				//console.log("onStartEdit")
			}

			this.onEndEdit = function () {
				//console.log("onEndEdit")
			}

			this.onDispose = function () {
				//console.log('onDispose');
			}

			this.getContentStageView = function () {
				//console.log("getContentStageView");
			}

			this.getPropertiesView = function () {
				//console.log("getPropertiesView");
				return propertiesTemplate;
			}

			this.toggleEyesOnTheTeacherView = function(display){
				if(!display){
					this.$el.find('.element_preview_wrapper').hide();
					this.$el.find('.eyes-on-the-teacher').show();
				}else{
					this.$el.find('.element_preview_wrapper').show();	
					this.$el.find('.eyes-on-the-teacher').hide();
				}
			}
		} 

		return vocabularyStudentEditor;
});