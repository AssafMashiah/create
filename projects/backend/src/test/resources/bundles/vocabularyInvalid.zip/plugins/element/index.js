define(['text!plugins/vocabulary/plugins/element/templates/properties.html', 
		'text!plugins/vocabulary/plugins/element/templates/stage.html'], 
	function (propertiesTemplate, stageTemplate) {
		var VocabularyElement = function() {
			
			this.onInitialize = function (details) {
				this.correction = Object.create(GrowingList);
				this.correction.init(this.CGS,this.CGS.model.record.data.correctionDataList,this.correctionDataChange.bind(this));
				if(this.$props_el){
					this.$props_el.find('.correction-wrapper').append(this.correction.render());
					this.correction.bindEvents();
				}
			};
			
			this.onRenderComplete = function ($el, state) {
				$el.parent().addClass('plugin-content');
				var template = this.CGS.RenderTemplate.render(stageTemplate,_.merge({},{is_edit : state === 'edit'}));
					$el.append(template);
			};

			this.onPropertiesViewLoad = function ($el) {
				this.$props_el = $el;
				this.bindPropertiesEvents();
			};

			this.onStartEdit = function () {
				var path = [{
					action :"child",	
					args : {
						type : "vocabulary:teacher", 
						index : 0 
					}
				}];
				this.CGS.externalApi.activate( path, "teacher.initMenu");
			};

			this.onEndEdit = function () {
			};

			this.onDispose = function () {
				this.unbindPropertiesEvents();
				this.$props_el = null;
				this.correction.unbindEvents();
			};

			this.getPropertiesView = function () {
				var path = [
					{
						action : "parent",
						args : {
								type : "vocabulary:main"
							}
					},
					{
						action : "getRecordProperty",
						args 	: {
							name : "data.title"
						}
					}],
 					main_title = this.CGS.externalApi.activate(path),
					template =   this.CGS.RenderTemplate.render(propertiesTemplate,
						_.merge({
							"main_title" : main_title
						},
						this.CGS.model.record.data)
					);
				return template;
			};

			this.bindPropertiesEvents = function(){
				this.$props_el.find('.main-title').on('change',function(e){
					var path = [
						{
							action : "parent",
							args : {
									type : "vocabulary:main"
								}
						},
						{
							action : "setRecordProperty",
							args 	: {
								name : "data.title",
								value : e.target.value
							}
						}];
					 this.CGS.externalApi.activate(path);		
				}.bind(this));
			};

			this.unbindPropertiesEvents = function (){
				if(!this.$props_el){
					return;
				}
				this.$props_el.find('.main-title').off('change');
			};

			this.correctionDataChange = function (type,id){
				switch(type){
					case "create" : 
						this.CGS.model.saveProp({"propName" : 'correctionDataList' ,"value": this.correction.getData()});
						break;
					case "delete" : 
						this.CGS.events.fire('vocabulary_script_deleteCorrectionScriptElement',id);	
						break;	 
				}
			};
		} 

		return VocabularyElement;
	});


	var GrowingList  = {
	
		id : "default",

		api : undefined,

		list : {},
		
		defaultText : 'Not Implemented Yet',

		template : "<div class='growing-list'></div>",
		
		rowsTemplate : "<div class='growing-list-rows' >{{#items}}{{> row}}{{/items}}</div>",
		
		rowTemplate :  "<div class='growing-list-row'  data-item-index='{{index}}' data-item-id='{{id}}'><input type='text' class='growing-list-input' value='{{name}}' {{#disabled}}disabled{{/disabled}}></input>{{#index}}<button class='growing-list-edit'><span class='base-icon icon-cog'></span></button><button class='growing-list-delete '><span class='base-icon icon-trash'></span></button>{{/index}}</div>",

		buttonTemplate : "<div><button class='growing-list-add '><span class='base-icon icon-plus'></span></button></div>",

		init : function(api,list,notifyFunction) {
			if(!api){
				throw new Error('Missing api');
			}
			this.api = api;
			this.notify = notifyFunction;
			
			this.setList(list);
			if(!this.list.length){
				//get this data from somewhere
				this.createItem('default',this.defaultText,true);
			}
		},

		bindEvents : function () {
			$(".growing-list")
				.on('click','.growing-list-add',this.addItemHtml.bind(this))
				.on('mouseover','.growing-list-row',this.toggleControlButtons.bind(this))
				.on('mouseout','.growing-list-row',this.toggleControlButtons.bind(this))
				.on('change','.growing-list-row input',this.editItem.bind(this))
				.on('click','.growing-list-delete',this.removeItem.bind(this))
				.on('click','.growing-list-edit',this.addValue.bind(this));

		},

		unbindEvents : function (){
			$(".growing-list").off('click','.growing-list-add')
			.off('mouseover','.growing-list-row')
			.off('mouseout','.growing-list-row')
			.off('change','.growing-list-row input')
			.off('click','.growing-list-delete')
			.off('click','.growing-list-edit');

		},
			
		addItemHtml : function (e) {
			var $growingListRows = $(e.target).closest('.growing-list').find('.growing-list-rows'),
			 	template = this.api.RenderTemplate.render(this.rowTemplate,{index : this.list.length});
			if($growingListRows.find('.growing-list-row').last().find('input').val() != ""){ 	 	
				$(template).appendTo($growingListRows).focus();
			}
		},

		addValue : function (e){
			alert('to be implemented by cgs team');
		},

		createItem : function (name,value,isDefault){
			//@todo check if exists
			Array.prototype.push.call(this.list , {
				"id" : this.formatId(name),
				"name" : name,
	//			"value" : value,
				"isDefault" : isDefault
			});
			this.notify('create',this.list);
			return this.list[this.list.length -1 ];
		},

		toggleControlButtons : function(e){
			var $row_element = this.getRowElement(e);
			if(e.type == 'mouseover'){
				$row_element.find('button').show();
			}else{
				$row_element.find('button').hide();
			}
		},

		editItem : function (e) {
			var rowElement = this.getRowElement(e),
				id = rowElement.data('item-id'),
				index = rowElement.data('item-index'),
				name = e.target.value,
				value = this.defaultText;

			if(this.getRowItem(id)){
				this.list[index] = _.merge({},this.list[index],{name : name,value:value});
				this.notify('create',this.list);
			}else{
				var newItem = this.createItem(name,value,false);
				rowElement.data('item-id',newItem.id) ;
			} 
			
		},

		removeItem : function (e) {
			var rowElement = this.getRowElement(e),
				index = rowElement.data('item-index');
			//need to notify all other objects
			if(this.list[index]){
				Array.prototype.splice.call(this.list,index,1);
			}
			this.notify('delete',rowElement.data('item-id'));
			rowElement.remove();
		},

		getRowItem : function (id){
			var result = false;
			if(id){
				result = _.first(_.compact(_.map(this.list,function(item){
						if(item.id == id){
							return item;
						}
						return false;
				})));
			}
			return result; 
		},

		getData : function (){
			return this.list;
		},

		setList : function (list){
			if(!list){
				return;
			}
			this.list = list;
		},

		render : function() {
			var $result = $(this.template),
				 items = _.map(this.getData(),function(item,index){ return _.merge({},item,{index:index})});
			$result.append(this.api.RenderTemplate.render(this.rowsTemplate,{items: items},{row: this.rowTemplate}));
			$result.append(this.buttonTemplate);
			return $result;
		},

		formatId : function (name) {
			var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    						var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
    						return v.toString(16);
						});
			return uuid;
		},

		getRowElement : function (e){
			if(e.target.classList.contains('growing-list-row')){
				$row_element =  $(e.target);
			}else{
				$row_element = $(e.target).closest('.growing-list-row');
			}
			return $row_element;
		}
	}	
