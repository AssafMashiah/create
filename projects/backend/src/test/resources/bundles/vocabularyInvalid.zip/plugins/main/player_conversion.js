define(['js/plugins/vocabulary/plugins/main/BaseConverter.js', 'js/plugins/vocabulary/plugins/main/VocabularyConverter.js'], function (BaseConverter, VocabularyConverter) {
	return function (data) {
		console.log(data);

        var baseConverter = new BaseConverter(data);
        var vocabularyConverter = new VocabularyConverter(baseConverter);
        return vocabularyConverter.convert();

	};
});