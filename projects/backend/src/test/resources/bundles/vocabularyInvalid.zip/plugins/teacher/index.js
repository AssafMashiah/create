define(['text!plugins/vocabulary/plugins/teacher/templates/properties.html', 
		'text!plugins/vocabulary/plugins/teacher/templates/stage.html'], 
	function (propertiesTemplate, stageTemplate) {
		var vocabularyStudentEditor = function() {
			
			this.onInitialize = function (details) {
				//console.log('onInitalize')
				this.CGS.externalApi.register('teacher.initMenu', this.initMenu);
			};
			
			this.onRenderComplete = function ($el, state) {
				var menu_height = 213 ;//document.querySelectorAll('.screen-header')[0].offsetHeight;
				if(state === 'edit') {
					$el.closest('.script-pane').css('min-height',document.body.offsetHeight - menu_height);
				}
				return state === 'edit' ?  $el.append(stageTemplate) : $el.append(stageTemplate);
			};

			this.onPropertiesViewLoad = function ($el) {
				//console.log("onPropertiesViewLoad")
			}

			this.onStartEdit = function () {
				//console.log("onStartEdit")
				this.initMenu();
			}

			this.onEndEdit = function () {

				//console.log("onEndEdit")
			}

			this.onDispose = function () {
				//console.log('onDispose');
			}

			this.getContentStageView = function () {
				//console.log("getContentStageView");
				
			}

			this.getPropertiesView = function () {
				//console.log("getPropertiesView");
			}

			this.initMenu = function() {
				this.CGS.menu.loadMenu({
				'menuInitFocusId': 'menu-button-vocabulary-task',
				'label' : '((Vocabulary))',
				'id':'menu-button-vocabulary-task',
				'type':'button',
				'icon':'',
				'canBeDisabled':false,
				subMenuItems:[
					{
						'id':'menu-button-vocabulary-task-group', // id in DOM
						'icon':'text-height',
						'type': 'btn-group-title',
						'label' : '((Vocabulary))',
						'canBeDisabled':true,
						'subMenuItems': [
							{
								'id':'menu-button-vocabulary-practice', // id in DOM
								'icon':'text-height',
								'label' : '((Practice))',
								'event': this.addScriptItem.bind(this,'practice'),
								'canBeDisabled':true
							},
							{
								'id':'menu-button-vocabulary-direction', // id in DOM
								'icon':'text-height',
								'label' : '((Direction))',
								'event': this.addScriptItem.bind(this,'direction'),
								'canBeDisabled':true,
								"subMenuItems" : []
							}
						]
					}]
				});
			}

			this.addScriptItem = function (type,menu_object){
				var elementId = this.CGS.model.saveItem({
					"data" : {
						"type" : "plugin:vocabulary:script",
						"data" : {
							"displayStudentContent" : true,
							"type" : type,
							'correctionScript' : 'default'
						},
						children : [{
							"type" : "sys:textViewer",
							"data" : {
								"mode":"custom",
								"settings" : {"groups" : ["styles","effects","font","paragraph"]},
								"deletable" : false,
								"autoWidth" : true,
							},
							"children" :[]
						}]
					}
				});
				this.CGS.render();
				this.CGS.startEditing(elementId)
			}
		} 

		return vocabularyStudentEditor;
});