define([], function () {
    var VocabularyConverter = function( base ){

        if( base ) this.setBase( base );

    };

    VocabularyConverter.prototype.setBase = function( base ){

        if( base ) this.base = base;

        return this;

    };

    VocabularyConverter.prototype.convert = function(){

        if( !( this.base && typeof this.base.findEntryPoint === "function" ) ) return false;

        var result = {

            data_version : "" ,

            activity : {
                type : "vocabulary"
            } ,

            content : {
                teacher : this.buildTeacherContent() ,
                student : this.buildStudentContent()
            }

        };

        this.relateStudentContentToTeacher( result.content );

        return result;

    };

    VocabularyConverter.prototype.relateStudentContentToTeacher = function( orgObject ){

        var studentContentIDs = Object.keys( orgObject.student.content.components );

        for( var i in orgObject.teacher.scripts ){

            if( !orgObject.teacher.scripts[ i ].eyesOnTheTeacher ){

                orgObject.teacher.scripts[ i ].studentContent = studentContentIDs;

            }

        }

    };

    VocabularyConverter.prototype.buildTeacherContent = function(){

        if( !this.base ) return false;

        var mainId = this.base.findEntryPoint();
        var data = this.base.getOriginalData();
        var result = {};

        if( data[ mainId ].children && data[ mainId ].children.length != 1 ){

            throw "Original data is corrupted: 'main' (ID: " + mainId + ") must have one child only. ";

        }

        var element = data[ data[ mainId ].children[ 0 ] ];

        result = {
            scripts : {} ,
            scriptsMapping : [] ,
            correctionDataList : element.correctionDataList || {}
        };

        var teacher = null;

        element.children.forEach( function( item ){

            if( teacher ) return;
            if( data[ item ].data.path && ~data[ item ].data.path.indexOf( ":teacher" ) ){
                teacher = data[ item ];
            }

        } );

        if( !teacher ) throw "'teacher' element not found.";

        var scripts = [];

        teacher.children.forEach( function( item ){

            if( data[ item ].data.path && ~data[ item ].data.path.indexOf( ":script" ) ){

                scripts.push( data[ item ] );

                result.scriptsMapping.push( data[ item ].id );

                result.scripts[ data[ item ].id ] = {

                    id : data[ item ].id ,
                    type : data[ item ].data.type ,
                    eyesOnTheTeacher : !data[ item ].data.displayStudentContent ,
                    studentContent : [] ,
                    data : {
                        base : {} ,
                        extra : {}
                    } ,
                    content_components : this.base.getChildrenComponents( data[ item ].id ) ,
                    correctionReference : data[ item ].data.correctionScript || "default"
                };
            }

        }.bind( this ) );

        /*

         script.forEach( function( script ){

         result.teacher.scripts[ script.id ] = {

         id : script.id ,
         type : script.type ,
         eyesOnTheTeacher : script.data.eyesOnTheTheacher || false ,
         studentContent : [] ,
         data : {
         base : {} ,
         extra : {}
         } ,
         content_components : this.base.getChildrenComponents( script.id )

         };

         }.bind( this ) );

         */

        return result;

    };

    VocabularyConverter.prototype.buildStudentContent = function(){

        if( !this.base ) return false;

        var mainId = this.base.findEntryPoint();
        var data = this.base.getOriginalData();

        var types = {
            "textViewer" : "text" ,
            "imageViewer" : "image"
        };
        var src = {
            "textViewer" : "content" ,
            "imageViewer" : "src"
        };

        var result = {
            content : {
                components : {}
            }
        };

        for( var i in data ){

            if( data[ i ].data.path && ~data[ i ].data.path.indexOf( ":student" ) ){

                data[ i ].children.forEach( function( item ){

                    result.content.components[ data[ item ].id ] = {

                        id : data[ item ].id ,
                        type : types[ data[ item ].type ] ,
                        data : {}

                    };

                    result.content.components[ data[ item ].id ].data[ src[ data[ item ].type ] ] = data[ item ].data.src || data[ item ].data.title;

                }.bind( this ) );

            }

        }

        return result;

    };

    return VocabularyConverter;


});